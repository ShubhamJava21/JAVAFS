package com.exponent.bankAppl.validation;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Validations 
{
	public static String validateAccountHolderName() {

		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR NAME :- ");
		String name = sc.next();
		char[] ch = name.toCharArray();
		boolean flag = true;
		for (int i = 0; i < ch.length; i++) {
			if (!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z')
					&& !(name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {

				flag = false;
			}
		}

		if (!flag) {
			System.out.println("Invalid I/p");
			return validateAccountHolderName();
		}

		return name;

	}
	public static String validatePanCardno() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR PANCARD NO :- ");
		String Pancard = sc.next();
		boolean flag=true;
		if(Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", Pancard)) 
			{
				flag=false;
			}
		if(!flag)
		{
			System.out.println("Invalid Input");
			return validatePanCardno();
		}
		return Pancard;
	
}
	public static String validateAadharCardno() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR ADHARCARD NO :- ");
		String Aadhar=sc.next();
		if(Pattern.matches("[0-9]+", Aadhar)&& Aadhar.length()==12) 
			{
			   return Aadhar;
			}
		   else
		   {
			System.out.println("INVALID INPUT");
			return validateAadharCardno();
		   }
		
	}
	public static String validateContactno() 
	{
//		String Contact="2625426181l";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Contact No :- ");
		String Contact = sc.next();   	
		if(Pattern.matches("[0-9]{10}", Contact)) 
			{
				System.out.println("Valid");
			}else
			{
				System.out.println("Invalid");
				return validateContactno();
			}
		return Contact;
	}
	

}
