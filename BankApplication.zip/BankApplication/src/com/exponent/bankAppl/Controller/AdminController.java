package com.exponent.bankAppl.Controller;

import java.util.Scanner;

import com.exponent.bankAppl.Service.RBI;
import com.exponent.bankAppl.ServiceImp.SBI;

public class AdminController 
{
 public static void main(String[] args)
 {
	System.out.println("********WELCOME TO SBI********");
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	RBI rbi=new SBI();
	while(flag)
	{
		System.out.println("------------------------");
		System.out.println("------------------------");
		System.out.println("1: CREATE BANK ACCOUNT        |");
		System.out.println("2: SHOW ACCOUNT DETAILS       |");
		System.out.println("3: SHOW ACCOUNT BALANCE       |");
		System.out.println("4: WITHDRAW MONEY             |");
		System.out.println("5: DEPOSITE MONEY             |");
		System.out.println("6: UPDATE ACCOUNT DETAILS     |");
		System.out.println("7: DISPLAY SINGLE ACCOUNT     |");
		System.out.println("8: EXIT                       |");
		System.out.println("------------------------");
		System.out.println("------------------------");
		
		System.out.println("Please Enter your choice between 1 to 8");
		int ch=sc.nextInt();
		getValidChoice();
		switch(ch)
		{
		case 1:
			rbi.creatAccount();
			break;
		case 2:
			rbi.showAccountDetails();
			break;
		case 3:
			rbi.showAccountBalance();
			break;
		case 4:
			rbi.withdrawMoney();
			break;
		case 5:
			rbi.depositeMoney();
			break;
		case 6:
			rbi.updateAccountDetails();
			break;
		case 7:
			rbi.singleAccountDetails();
			break;
		case 8:
			flag=false;
			break;
		default:
			System.out.println("You entered invalid choice please correct choice");
			break;
			
		}
		
		
	}
}
   public static int getValidChoice()
{
	  Scanner sc=new Scanner(System.in);
	  System.out.println("ENTER THE CHOICE:- ");
	  
	  int ch;
	  try {
		  ch=sc.nextInt();
	} catch (Exception e)
	  {
//		e.printStackTrace();
		System.out.println("EXCEPTION HANDLED HERE");
		return getValidChoice();
	}
	  return ch;
}
//   public static int getValidAccNo()
//   {
//   	  Scanner sc=new Scanner(System.in);
//   	  System.out.println("ENTER THE CHOICE:- ");
//   	  
//   	  int accNo;
//   	  try {
//   		  accNo=sc.nextInt();
//   	} catch (Exception e)
//   	  {
////   		e.printStackTrace();
//   		System.out.println("EXCEPTION HANDLED HERE");
//   		return getValidAccNo();
//   	}
//   	  return accNo;
//   }
}
   
