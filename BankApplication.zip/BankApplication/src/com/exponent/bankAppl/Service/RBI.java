package com.exponent.bankAppl.Service;

public interface RBI 
{
 public void creatAccount();
 public void showAccountDetails();
 public void showAccountBalance();
 public void depositeMoney();
 public void withdrawMoney();
 public void updateAccountDetails();
public void singleAccountDetails();
}
