package com.exponent.bankAppl.ServiceImp;

import java.util.Scanner;

import com.exponent.bankAppl.Controller.AdminController;
import com.exponent.bankAppl.Model.Account;
import com.exponent.bankAppl.Service.RBI;
import com.exponent.bankAppl.validation.Validations;

public class SBI implements RBI
{
	Scanner sc=new Scanner(System.in);
//	Account ac=new Account();
	Account a[] =new Account[5];

	@Override
	public void creatAccount() 
	{
		System.out.println("ENTER HOW MANY ACCOUNTS DO YOU WANT TO ADD:");
		int n=sc.nextInt();
		for(int i=0; i<n;i++) {
			Account ac=new Account();
	
//		System.out.println("ENTER YOUR ACCOUNT NO:  ");
//		int accNo=sc.nextInt();
//		ac.setAccountNo(accNo);
		ac.setAccountNo(getValidAccNo());
//		System.out.println("ENTER YOUR NAME: ");
		ac.setAccountName(Validations.validateAccountHolderName());
//		System.out.println("ENTER AADHARCARD NO:  ");
		ac.setAadharCard(Validations.validateAadharCardno());
//		System.out.println("ENTER PANCARD NO:   ");
		ac.setPancard(Validations.validatePanCardno());
		System.out.println("ENTER EMAIL ID:   ");
		ac.setMail(sc.next());
//		System.out.println("ENTER YOUR CONTACT:  ");
		ac.setContact(Validations.validateContactno());
//		System.out.println("ENTER ACCOUNT OPENING BALANCE:  ");
		ac.setAccountBalance(getValidBalance());
		System.out.println("*****ACCOUNT CREATION SUCCESSFUL*****");
		
		a[i]=ac;
		
		System.out.println("Account Added Successfully!!!1");
	}
	}
	@Override
	public void showAccountDetails() 
	{
//		System.out.println("ENTER YOUR ACCOUNT: ");
//		int accNO=sc.nextInt();
//		if(ac.getAccountNo() == accNO)
//		{
//			System.out.println(ac);
//		}
//		else
//		{
//			System.out.println("ACCOUNT DOESNT EXIT");
//		}
		
	}

	@Override
	public void showAccountBalance()
	{
//		System.out.println("ENTER YOUR ACCOUNT ");
//		int accNo=sc.nextInt();
//		if(ac.getAccountNo() == accNo)
//		{
//			System.out.println("CURRENT ACCOUNT BALANCE "+ac.getAccountBalance());
//		}
//		else
//		{
//			System.out.println("ACCOUNT DOESNT EXITS ");
//		}
	}

	@Override
	public void depositeMoney() 
	{
//		System.out.println("ENTER YOUR ACCOUNT NO ");
//		int accNo=sc.nextInt();
//		if(ac.getAccountNo()==accNo)
//		{
//		System.out.println("ENTER MONEY YOU WISH TO DEPOSITE ");
//		double dp=sc.nextDouble();
//		double updateAccountBalance=ac.getAccountBalance()+dp;
//		ac.setAccountBalance(updateAccountBalance);
//		System.out.println("DEPOSITE SUCCESSFUL \n CURRENT BALANCE IS: "+ac.getAccountBalance());
//	     }
//		else
//		{
//			System.out.println("PLEASE VERIFY YOUR ACCOUNT NO \n NO RECORD FOUND");
//		}
	}

	@Override
	public void withdrawMoney() 
	{
//		System.out.println("ENTER YOUR ACCOUNT NO ");
//		int accNo=sc.nextInt();
//		if(ac.getAccountNo()==accNo)
//		{
//		System.out.println("ENTER MONEY YOU WISH TO WITHDRAW ");
//		double wd=sc.nextDouble();
//		if(ac.getAccountBalance()>wd)
//		{
//		double updateAccountBalance= ac.getAccountBalance()-wd;
//		ac.setAccountBalance(updateAccountBalance);
//		System.out.println("WITHDRAWAL SUCCESSFUL \n CURRENT BALANCE IS: "+ac.getAccountBalance());
//	     }
//		else 
//		{
//		 System.out.println("INSUFFICIENT BALANCE \n YOUR BALANCE IS "+ac.getAccountBalance());	
//		}
//		}
//		else
//		{
//			System.out.println("PLEASE VERIFY YOUR ACCOUNT NO \n NO RECORD FOUND");
//		}
	 }

	@Override
	public void updateAccountDetails() 
	{
//		System.out.println("ENTER YOUR ACCOUNT NO");
//		int accNo=sc.nextInt();
//		boolean flag=true;
//		while(flag)
//		{
//			System.out.println("1: ENTER NEW NAME");
//			System.out.println("2: ENTER NEW MOBILE");
//			System.out.println("3: ENTER NEW MAIL-ID");
//			System.out.println("ENTER CHOICE BETWEEN 1 TO 3 ");
//			System.out.println("UPDATE ACCOUNT DETAILS");
//			int i1=sc.nextInt();
//		switch(i1)
//		{
//		case 1:
//			   System.out.println("ENTER YOUR NEW NAME");
//			   String newName=sc.next();
//			  this.ac.setAccountName(newName);
//			  System.out.println("YOUR UPDATED NAME= "+" "+newName);
//			  break;
//		case 2:
//			 System.out.println("ENTER YOUR NEW MOBILE NO");
//			 String newMoNo=sc.next();
//			 this.ac.setContact(newMoNo);
//			 System.out.println("YOUR UPDATED MOBILE NO= "+" "+newMoNo);
//			  break;
//		case 3:
//			System.out.println("ENTER YOUR NEW MAIL-ID");
//			String newMail=sc.next();
//			this.ac.setMail(newMail);
//			System.out.println("YOUR UPDATED MAIL ID= "+" "+newMail);
//			  break;
//		case 4:
//			flag=false;
//			break;
//		default:
//			System.out.println("You entered invalid choice please correct choice");
//			break;
//		}
//		}
	}
//	private void updateName() 
//	{
//		System.out.println("ENTER NEW NAME ");
//		String newName=sc.next();
//		ac.setAccountName(newName);
//	}
//	private void updateMobileNo() 
//	{
//		System.out.println("ENTER NEW MOBILE NO ");
//		String newMobileNo=sc.next();
//		ac.setContact(newMobileNo);
//	}
//	private void updateMailId() 
//	{
//		System.out.println("ENTER NEW MAIL-ID ");
//		String newMailId=sc.next();
//		ac.setMail(newMailId);
//	}
	@Override
	public void singleAccountDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE ACCOUNT NO: ");
		long an=sc.nextLong();
		for (Account acn : a) 
		{
			if(acn!= null && acn.getAccountNo()==an)
			{
				System.out.println(acn);
			}
		}
	}
	public static int getValidAccNo()
	   {
	   	  Scanner sc=new Scanner(System.in);
	   	  System.out.println("ENTER YOUR ACCOUNT NO:- ");
	   	  
	   	  int accNo;
	   	  try {
	   		  accNo=sc.nextInt();
	   	} catch (Exception e)
	   	  {
	   		System.out.println("EXCEPTION HANDLED HERE : PLEASE PROVIDE CORRECT ACCOUNT NO.");
	   		return getValidAccNo();
	   	}
	   	  return accNo;
	   }
	public static double getValidBalance()
	   {
	   	  Scanner sc=new Scanner(System.in);
	   	  System.out.println("ENTER YOUR ACCOUNT OPENEING BALANCE:- ");
	   	  
	   	  double acBal;
	   	  try {
	   		acBal=sc.nextInt();
	   	} catch (Exception e)
	   	  {
	   		System.out.println("EXCEPTION HANDLED HERE : PLEASE PROVIDE CORRECT ACCOUNT BALANCE.");
	   		return getValidBalance();
	   	}
	   	  return acBal;
	   }

}
