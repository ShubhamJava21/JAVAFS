package serializationDeserializationex;

import java.io.Serializable;

public class Employee implements Serializable
{
	private int eid;
	  private String ename;
	  private String eaddress;
	  private String eAcno;
	  private String epassword;
	  private String eDesignation;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEaddress() {
		return eaddress;
	}
	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}
	public String geteAcno() {
		return eAcno;
	}
	public void seteAcno(String eAcno) {
		this.eAcno = eAcno;
	}
	public String getEpassword() {
		return epassword;
	}
	public void setEpassword(String epassword) {
		this.epassword = epassword;
	}
	public String geteDesignation() {
		return eDesignation;
	}
	public void seteDesignation(String eDesignation) {
		this.eDesignation = eDesignation;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eaddress=" + eaddress + ", eAcno=" + eAcno
				+ ", epassword=" + epassword + ", eDesignation=" + eDesignation + "]";
	}
	
}
