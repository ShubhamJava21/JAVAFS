package serializationDeserializationex;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestDeserliazation 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException 
	 {
		FileInputStream File=new FileInputStream("Empl.txt");
		ObjectInputStream obj=new ObjectInputStream(File);
		Compony cm=(Compony)obj.readObject(); 
		Empl em=(Empl) obj.readObject(); 
		System.out.println(cm);
		System.out.println(em);
		
	 }
}
