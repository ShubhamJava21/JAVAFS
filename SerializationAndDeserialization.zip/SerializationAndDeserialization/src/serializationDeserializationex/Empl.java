package serializationDeserializationex;

public class Empl extends Compony
{ 
	private int eid;
	private String Ename;
	private transient String Eadd;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public String getEadd() {
		return Eadd;
	}
	public void setEadd(String eadd) {
		Eadd = eadd;
	}
	@Override
	public String toString() {
		return "Empl [eid=" + eid + ", Ename=" + Ename + ", Eadd=" + Eadd + "]";
	}
	

}
