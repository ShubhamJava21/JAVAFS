package serializationDeserializationex;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeTest 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException 
	 {
		FileInputStream File=new FileInputStream("ManagerD.txt");
		ObjectInputStream obj=new ObjectInputStream(File);
		Manager m=(Manager)obj.readObject(); 
		Compony com=(Compony)obj.readObject();
		System.out.println(m);
		System.out.println(com);
	
	 }
}
