package serializationDeserializationex;

import java.io.Serializable;

public class Manager implements Serializable
{
 private int Mid;
 private String Mname;
 private String MAdd;
  Compony com;
public int getMid() {
	return Mid;
}
public void setMid(int mid) {
	Mid = mid;
}
public String getMname() {
	return Mname;
}
public void setMname(String mname) {
	Mname = mname;
}
public String getMAdd() {
	return MAdd;
}
public void setMAdd(String mAdd) {
	MAdd = mAdd;
}
@Override
public String toString() {
	return "Manager [Mid=" + Mid + ", Mname=" + Mname + ", MAdd=" + MAdd + "]";
}
 
}
