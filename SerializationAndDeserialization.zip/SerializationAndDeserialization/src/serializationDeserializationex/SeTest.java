package serializationDeserializationex;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SeTest 
{
	public static void main(String[] args) throws IOException 
	 {
		Manager m=new Manager();
		m.setMid(111);
		m.setMname("NILESH");
		m.setMAdd("PIMPRI");
		Compony com=new Compony();
		com.setCid(1011);
		com.setCname("INFOBEANS");
		com.setCAddress("HINJEWADI");
//		m.com.setCid(1012);
//		m.com.setCname("YASHTECH");
//		m.com.setCAddress("BANER");
		
		FileOutputStream File=new FileOutputStream("ManagerD.txt");
		ObjectOutputStream obj1=new ObjectOutputStream(File);
		obj1.writeObject(m);
		System.out.println("Object Serialized");
	 }
}
