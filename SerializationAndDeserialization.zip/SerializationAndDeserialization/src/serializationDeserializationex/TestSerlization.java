package serializationDeserializationex;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestSerlization 
{
	public static void main(String[] args) throws IOException 
	 {
		Compony c=new Compony();
		c.setCid(101);
		c.setCname("INFO");
		c.setCAddress("PUNE");
		
		Empl em=new Empl();
		em.setEid(1);
		em.setEname("SHUBHAM");
		em.setEadd("PIMPRI");
		
		FileOutputStream File=new FileOutputStream("Empl.txt");
		ObjectOutputStream obj=new ObjectOutputStream(File);
		obj.writeObject(c);
		obj.writeObject(em);
		System.out.println("Object Serialized");
	 }
}
