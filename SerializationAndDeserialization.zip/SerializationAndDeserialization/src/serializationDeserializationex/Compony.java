package serializationDeserializationex;

import java.io.Serializable;

public class Compony implements Serializable
{
  private int Cid;
  private String Cname;
  private String CAddress;
//  Employee em;
public int getCid() {
	return Cid;
}
public void setCid(int cid) {
	Cid = cid;
}
public String getCname() {
	return Cname;
}
public void setCname(String cname) {
	Cname = cname;
}
public String getCAddress() {
	return CAddress;
}
public void setCAddress(String cAddress) {
	CAddress = cAddress;
}
@Override
public String toString() {
	return "Compony [Cid=" + Cid + ", Cname=" + Cname + ", CAddress=" + CAddress + "]";
}
  
}
