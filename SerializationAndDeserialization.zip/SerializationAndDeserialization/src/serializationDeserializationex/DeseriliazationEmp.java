package serializationDeserializationex;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeseriliazationEmp 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException 
	 {
		FileInputStream File=new FileInputStream("EmployeeDetails.txt");
		ObjectInputStream obj=new ObjectInputStream(File);
		Employee emp=(Employee) obj.readObject(); 
		System.out.println(emp);
	 }
}
