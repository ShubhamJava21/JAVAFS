package Course.IMPLService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import Course.Model.Batch;
import Course.Model.Course;
import Course.Model.Faculty;
import Course.Model.Student;
import Course.Service.CMSService;

public class CMSServiceIMPL implements CMSService
{
	List<Course> Clist=new ArrayList<Course>();
	List<Faculty> Flist=new ArrayList<Faculty>();
	List<Batch> Blist=new ArrayList<Batch>();
	List<Student> Slist=new ArrayList<Student>();

	@Override
	public void addCourse()
	{
	 Scanner sc=new Scanner(System.in);
	 System.out.println("ENTER HOW MANY COURSE YOU WANT TO ADD:- ");
	 int n=sc.nextInt();
	 for(int i=1;i<=n;i++)
	 {
		 Course course=new Course();
		 System.out.println("ENTER THE COURSE ID:- ");
		 course.setCid(sc.nextInt());
		 System.out.println("ENTER THE COURSE NAME:- ");
		 course.setCName(sc.next());
		 
		 Clist.add(course);
		 System.out.println("COURSE ADDED SUCCESSFULLY");
		 
	 }
	}

	@Override
	public void displayCourse() 
	{
		for (Course course : Clist) 
		{
			System.out.println(course.getCid());
			System.out.println(course.getCName());
		}
		
	}
	public int getValidCId()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE COURSE ID YOU WANT TO ATTACH:- ");
		int Cid=sc.nextInt();
		boolean flag=true;
		for (Course c : Clist) 
		{
			if(c!=null && c.getCid()==Cid )
			{
				flag=false;
				break;
			}
		}
		if(flag) 
		{
			System.out.println("INVALID COURSE ID PLESE RE-ENTER CORRECT ID:- ");
			return getValidCId();
			
		}
		return Cid;
	}


	@Override
	public void addFaculty() 
	{
		Scanner sc=new Scanner(System.in);
		 System.out.println("ENTER HOW MANY FACULTY YOU WANT TO ADD:- ");
		 int n=sc.nextInt();
		 for(int i=1;i<=n;i++)
		 {
			 Faculty faculty=new Faculty();
			System.out.println("ENTER THE FACULTY ID:- "); 
			faculty.setFid(sc.nextInt());
			System.out.println("ENTER THE FACULTY NAME:- "); 
			faculty.setFName(sc.next());
			
			int ValidCid=getValidCId();
			
			for (Course c : Clist) 
			{
				if(c !=null && c.getCid()== ValidCid)
				{
					faculty.setCourse(c);
				}
			}
			Flist.add(faculty);
			System.out.println("FACULTY ADDED SUCCESFULLY..");
		 }
			 
	}

	@Override
	public void displayFaculty() 
	{
		 for (Faculty faculty: Flist) 
		 {
//			System.out.println(faculty.getFid());
//			System.out.println(faculty.getFName());
			 System.out.println(faculty);
		}
		
	}
	public int getValidFId()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE FACULTY ID YOU WANT TO ATTACH:- ");
		int Fid=sc.nextInt();
		boolean flag=true;
		for (Faculty f : Flist) 
		{
			if(f!=null && f.getFid()==Fid)
			{
				flag=false;
				break;
			}
		}
		if(flag) 
		{
			System.out.println("INVALID FACULTY ID RE-ENTER CORRECT ID:- ");
			return getValidFId();
			
		}
		return Fid;
	}

	@Override
	public void addBatch() 
	{
		
		Scanner sc=new Scanner(System.in);
		 System.out.println("ENTER HOW MANY BATCH YOU WANT TO ADD:- ");
		 int n=sc.nextInt();
		 for(int i=1;i<=n;i++)
		 {
			Batch batch=new Batch();
			System.out.println("ENTER THE BATCH ID:- "); 
			batch.setBid(sc.nextInt());
			System.out.println("ENTER THE BATCH NAME:- "); 
			batch.setBName(sc.next());
			
			int ValidFid=getValidFId();
			
			for (Faculty f : Flist) 
			{
				if(f !=null && f.getFid()==ValidFid)
				{
					batch.setFaculty(f);
				}
			}
			Blist.add(batch);
			System.out.println("BATCH ADDED SUCCESFULLY..");
		 }
		
	}

	@Override
	public void displayBatch()
	{
		for (Batch batch : Blist) 
		{
		  System.out.println(batch);	
		}
		
	}
	public int getValidBId()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE BATCH ID YOU WANT TO ATTACH:- ");
		int Bid=sc.nextInt();
		boolean flag=true;
		for (Batch b : Blist) 
		{
			if(b!=null && b.getBid()==Bid)
			{
				flag=false;
				break;
			}
		}
		if(flag) 
		{
			System.out.println("INVALID STUDENT ID RE-ENTER CORRECT ID:- ");
			return getValidBId();
			
		}
		return Bid;
	}

	@Override
	public void addStudent()
	{
		Scanner sc=new Scanner(System.in);
		 System.out.println("ENTER HOW MANY STUDENT YOU WANT TO ADD:- ");
		 int n=sc.nextInt();
		 for(int i=1;i<=n;i++)
		 {
			Student student=new Student();
			System.out.println("ENTER THE STUDENT ID:- "); 
			student.setSid(sc.nextInt());
			System.out.println("ENTER THE STUDENT NAME:- "); 
			student.setSName(sc.next());
			
			int ValidBid=getValidBId();
			
			for (Batch b : Blist) 
			{
				if(b !=null && b.getBid()==ValidBid)
				{
					student.setBatch(b);
				}
			}
			Slist.add(student);
			System.out.println("STUDENT ADDED SUCCESFULLY..");
		 }
		
	}

	@Override
	public void displayStudent() 
	{
		for (Student student : Slist) 
		{
			System.out.println(student);
		}
		
	}

	@Override
	public void updateAllDetails() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("PLESE SELECT CHOICE TO UPDATE DETAILS:");
        System.out.println("1. Course\n2. Faculty\n3. Batch\n4. Student");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
            	boolean flag=true;
                System.out.print("Enter Course ID to update: ");
                int cId = sc.nextInt();
                for (Course c : Clist) {
                    if (c.getCid() == cId) {
                    	flag=false;
                        System.out.print("Enter new Course Name: ");
                        c.setCName(sc.next());
                        System.out.println("Course updated successfully.");
                        System.out.println(c);
                    }
                }
                if(flag) 
                {
                		System.out.println("Course not found.");
                }
                break;
	       case 2:
	    	   boolean flag1=true;
            System.out.print("Enter Faculty ID to update: ");
           int fId = sc.nextInt();
           for (Faculty f : Flist) {
            if (f.getFid() == fId) {
            	flag1=false;
                System.out.print("Enter new Faculty Name: ");
                f.setFName(sc.next());
                System.out.println("Faculty updated successfully.");
                System.out.println(f);
            }
        }
           if(flag1) 
           {
           		System.out.println("Course not found.");
           }
           break;
	       case 3:
	    	   boolean flag2=true;
               System.out.print("Enter Batch ID to update: ");
               int bId = sc.nextInt();
               for (Batch b : Blist) {
                   if (b.getBid() == bId) {
                	   flag2=false;
                       System.out.print("Enter new Batch Name: ");
                       b.setBName(sc.next());
                       System.out.println("Batch updated successfully.");
                       System.out.println(b);
                   }
               }
               if(flag2) 
               {
               		System.out.println("Course not found.");
               }
               break;
               
	       case 4:
	    	   boolean flag3=true;
               System.out.print("Enter Student ID to update: ");
               int sId = sc.nextInt();
               for (Student s : Slist) {
                   if (s.getSid() == sId) {
                	   flag3=false;
                       System.out.print("Enter new Student Name: ");
                       s.setSName(sc.next());
                       System.out.println("Student updated successfully.");
                       System.out.println(s);
                   }
               }
               if(flag3) 
               {
               		System.out.println("Course not found.");
               }
               break;
               
	       default:
               System.out.println("Invalid option.");
               
	}
	}
     	@Override
	public void deleteDetails() 
    {
     Scanner sc = new Scanner(System.in);
     System.out.println("PLEASE SELECT CHOICE TO DELETE DETAILS:");
     System.out.println("1. Course\n2. Faculty\n3. Batch\n4. Student");
     int choice = sc.nextInt(); 
             switch (choice) {
                 case 1:
                	 boolean flag=true;
                     System.out.print("Enter Course ID to delete: ");
                     int cId = sc.nextInt();
                     for (int i = 0; i < Clist.size(); i++) {
                         if (Clist.get(i).getCid() == cId) 
                         {
                        	 flag=false;
                             Clist.remove(i);
                             System.out.println("Course deleted successfully.");
                             break;
                         }
                     }
                     if(flag) {
                     System.out.println("Course not found.");
                     }
                     break;
                 case 2:
                	 boolean flag1=true;
                     System.out.print("Enter Faculty ID to delete: ");
                     int fId = sc.nextInt();
                     for (int i = 0; i < Flist.size(); i++) {
                         if (Flist.get(i).getFid() == fId) {
                        	 flag1=false;
                             Flist.remove(i);
                             System.out.println("Faculty deleted successfully.");
                             break;
                         }
                     }
                     if(flag1) {
                         System.out.println("Course not found.");
                         }
                         break;
                 
                 case 3:
                	 boolean flag2=true;
                     System.out.print("Enter Batch ID to delete: ");
                     int bId = sc.nextInt();
                     for (int i = 0; i < Blist.size(); i++) {
                         if (Blist.get(i).getBid() == bId) {
                        	 flag2=false;
                             Blist.remove(i);
                             System.out.println("Batch deleted successfully.");
                             break;
                         }
                     }
                     if(flag2) {
                         System.out.println("Course not found.");
                         }
                         break;
                 
                 case 4:
                	 boolean flag3=true;
                     System.out.print("Enter Student ID to delete: ");
                     int sId = sc.nextInt();
                     for (int i = 0; i < Slist.size(); i++) {
                         if (Slist.get(i).getSid() == sId) {
                        	 flag3=false;
                             Slist.remove(i);
                             System.out.println("Student deleted successfully.");
                             break;
                         }
                     }
                     if(flag3) {
                         System.out.println("Course not found.");
                         }
                         break;
                 
                 default:
                     System.out.println("Invalid option.");
             }
         }
}
