package Course.Controller;

import java.util.Scanner;

import Course.IMPLService.CMSServiceIMPL;

public class CMSController 
{
 public static void main(String[] args) 
 {
	System.out.println("********WELCOME TO C.M.S********");
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	CMSServiceIMPL cms=new CMSServiceIMPL();
	while(flag)
	{
		System.out.println("------------------------");
		System.out.println("------------------------");
		System.out.println("1: ADD COURSE            |");
		System.out.println("2: DISPLAY ALL COURSE    |");
		System.out.println("3: ADD FAULTY            |");
		System.out.println("4: DISPLAY FACULTY       |");
		System.out.println("5: ADD BATCH             |");
		System.out.println("6: DISPLAY BATCH         |");
		System.out.println("7: ADD STUDENT           |");
		System.out.println("8: DISPLAY STUDENT       |");
		System.out.println("9: UPDATE DETAILS        |");
		System.out.println("10: DELETE DETAILS        |");
		System.out.println("------------------------");
		System.out.println("------------------------");
		
		System.out.println("Please Enter your choice between 1 to 10");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			cms.addCourse();
			break;
		case 2:
			cms.displayCourse();
			break;
		case 3:
			cms.addFaculty();
			break;
		case 4:
			cms.displayFaculty();
			break;
		case 5:
			cms.addBatch();
			break;
		case 6:
			cms.displayBatch();
			break;
		case 7:
			cms.addStudent();
			break;
		case 8:
			cms.displayStudent();
			break;
		case 9:
			cms.updateAllDetails();
			break;
		case 10:
			cms.deleteDetails();
			break;
		case 11:
			flag=false;
			break;
		default:
			System.out.println("You entered invalid choice please correct choice");
			break;
	
		}	
     }
}}
