package Course.Service;

public interface CMSService 
{
	public void addCourse();
	public void displayCourse();
	public void addFaculty();
	public void displayFaculty();
	public void addBatch();
    public void displayBatch();
    public void addStudent();
    public void displayStudent();
    public void updateAllDetails();
    public void deleteDetails();
}
