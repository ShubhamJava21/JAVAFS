package Course.Model;

public class Course 
{
  private int Cid;
  private String CName;
public int getCid() {
	return Cid;
}
public void setCid(int cid) {
	Cid = cid;
}
public String getCName() {
	return CName;
}
public void setCName(String cName) {
	CName = cName;
}
@Override
public String toString() {
	return "Course [Cid=" + Cid + ", CName=" + CName + "]";
}
  
  
}
