package Course.Model;

public class Batch
{
  private int Bid;
  private String BName;
  private Faculty faculty;
public int getBid() {
	return Bid;
}
public void setBid(int bid) {
	Bid = bid;
}
public String getBName() {
	return BName;
}
public void setBName(String bName) {
	BName = bName;
}
public Faculty getFaculty() {
	return faculty;
}
public void setFaculty(Faculty faculty) {
	this.faculty = faculty;
}
@Override
public String toString() {
	return "Batch [Bid=" + Bid + ", BName=" + BName + ", faculty=" + faculty + "]";
}
  
}
