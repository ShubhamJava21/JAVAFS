package Course.Model;

public class Student 
{
 private int Sid;
 private String SName;
 private Batch batch;
public int getSid() {
	return Sid;
}
public void setSid(int sid) {
	Sid = sid;
}
public String getSName() {
	return SName;
}
public void setSName(String sName) {
	SName = sName;
}
public Batch getBatch() {
	return batch;
}
public void setBatch(Batch batch) {
	this.batch = batch;
}
@Override
public String toString() {
	return "Student [Sid=" + Sid + ", SName=" + SName + ", batch=" + batch + "]";
}
 
}
