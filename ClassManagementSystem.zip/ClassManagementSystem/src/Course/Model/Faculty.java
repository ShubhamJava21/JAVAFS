package Course.Model;

public class Faculty 
{
 private int Fid;
 private String FName;
 private Course course;
public int getFid() {
	return Fid;
}
public void setFid(int fid) {
	Fid = fid;
}
public String getFName() {
	return FName;
}
public void setFName(String fName) {
	FName = fName;
}
public Course getCourse() {
	return course;
}
public void setCourse(Course course) {
	this.course = course;
}
@Override
public String toString() {
	return "Faculty [Fid=" + Fid + ", FName=" + FName + ", course=" + course + "]";
}
 
 
}
