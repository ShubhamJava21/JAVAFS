package variables;

public class Student1 
{
	  int a=10;
	  public void m1()
	{
	  System.out.println("M1 Method called");
	   int b=20;
	  System.out.println(b);	  
	  }

}
