package variables;

public class Emp 
{
  int Eid=101;
  String Ename="Shubham";
  
  public void Salary()
  {
	  System.out.println("Shubhams Salary=200000");
  }
}
