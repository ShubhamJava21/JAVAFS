package variables;

public class TestEmp 
{
 public static void main(String[] args)
 {
	Emp e=new Emp();
	e.Salary();
	System.out.println("Shubhams Emp id: "+e.Eid);
	System.out.println("Shubhams Emp Name: "+e.Ename);
	TestEmp Te=new TestEmp();
	Te.Designation();	
}
 public void Designation()
	{
		System.out.println("Shubham Worked As Full Stack Java Developer");
	}
}