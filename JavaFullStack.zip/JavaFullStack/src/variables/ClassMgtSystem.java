package variables;

import methods.Student;

public class ClassMgtSystem 
{
	  int cid=101;
	  int fid=1001;
	  String cname="Java F.S";
	  String fname="Nilesh Sir";

	  public void DisplayCourse()
	{
	   ClassMgtSystem cs=new ClassMgtSystem();
	   System.out.println(cs.cid);
	   System.out.println(cs.fid);
	   System.out.println(cs.cname);
	   System.out.println(cs.fname);
	  
	  }
	public void DisplayStudentyDetails()
	{
	  int sid=102;
	  String sname="SHUBHAM";
	  String address="Pimpri";
	 System.out.println(sid+" "+sname+" "+address+" ");
	  
	  }
	 public static void main(String[] args)
	{
	 ClassMgtSystem cs1=new ClassMgtSystem();
	  cs1.DisplayCourse();
	  cs1.DisplayStudentyDetails();
	  Student s=new Student();
	  s.StudentName();
	  s.StudentResult();
	  s.StudentContact();
	}

}
