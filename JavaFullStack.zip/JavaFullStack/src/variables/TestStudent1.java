package variables;

public class TestStudent1 
{
	public static void main(String[] args)
	{
	 System.out.println("Main Method called");
	 Student1 S1=new Student1();
	 System.out.println(S1.a);
	  S1.m1();    
	}
}
