package typeCasting;

public class NarrowingCasting 
{
  public static void main(String[] args) 
  {
	double d=345.89;
	
	int i=(int)d; //while converting to narrow have to write datatype infront 
	
	System.out.println(d);
	System.out.println(i);
	
	short s=(short) i;
	byte b=(byte)i;
	System.out.println(s);
	System.out.println(b);
	
	int i1=97;
	char c=(char)i1;
	System.out.println(c);
	
	char c1='a';
	
	int j=c1;
	System.out.println(j);
	
	int i3=4444;
	
	byte b4=(byte)i3;
	System.out.println(b4);
  }
}
