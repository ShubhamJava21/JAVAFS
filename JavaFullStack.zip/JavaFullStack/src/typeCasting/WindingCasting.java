package typeCasting;

public class WindingCasting 
{
 public static void main(String[] args) 
 {
	int i=127;
	
	double d=i;
	System.out.println(i);
	System.out.println(d);
	
	long l=i;
	System.out.println(l);
	
	byte b=99;
	short s=b;
	int j=b;
	long l1=b;
	
	float f=s;
	System.out.println(b);
	System.out.println(s);
	System.out.println(j);
	System.out.println(l1);
	System.out.println(f);
 }
}
