package typeCasting;

public class Practice 
{
	public static void main(String[] args) 
	{
		
	   byte b=12;
	   short s=b;
	   System.out.println(s);
	   
	   int i=b;
	   System.out.println(i);
	   
	   long l=b;
	   System.out.println(l);
	   
	   float f=12.8f;
	   double d=f;
	   System.out.println(d);
	   
	

     }
}
