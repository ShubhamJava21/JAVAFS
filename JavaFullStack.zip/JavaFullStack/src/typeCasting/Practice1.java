package typeCasting;

public class Practice1 
{
   public static void main(String[] args) 
   {
	 int i=4567;
	 short s=(short) i;
	 System.out.println(s);
	 
	 byte b=(byte) i;
	 System.out.println(b);
	 
	 char c=(char) i;
	 System.out.println(c);
	 
	 long l=345567l;
//	 int i1=3456;
	 short v=(short) l;
	 System.out.println(v);
	 
   }
}
