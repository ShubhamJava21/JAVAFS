package returnTypeEx;

public class TestFS 
{
  public Father addFatherDetails()
  {
	  Father F=new Father();
	  F.FathId=2;
	  F.FathName="Ashok";
	  F.FathAdd="Pimpri";
	  F.FathBuss="Firm";
	  F.FathMobile=1234567890l;
	  return F;
	  
  }
  public Son addSonDetails()
  {
	  Son S=new Son();
	  S.SonId=1;
	  S.SonName="Shubham";
	  S.SonAdd="Pimpri";
	  S.SonBuss="Software Engg";
	  S.SonMobile=2433126242743l;
	  return S;
  }
   public static void main(String[] args)
   {
	 TestFS Tf=new TestFS();
	 Father ft=Tf.addFatherDetails();
	 System.out.println(ft.FathId+" "+ft.FathName+" "+ft.FathAdd+" "+ft.FathBuss+" "+ft.FathMobile);
      Son st =Tf.addSonDetails();
      System.out.println(st.SonId+" "+st.SonName+" "+st.SonAdd+" "+st.SonBuss+" "+st.SonMobile);
   }
}
