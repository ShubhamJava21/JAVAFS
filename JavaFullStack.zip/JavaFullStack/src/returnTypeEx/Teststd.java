package returnTypeEx;

public class Teststd 
{
  public Student addStudentDetails()
  {
	  Student St=new Student();
	  St.StudId=101;
	  St.StudName="Shubham";
	  St.StudEmail="Abc@123";
	  St.StudAdd="Pune";
	  St.StudMobile=1234567890l;
	  return St;
  }
  public Student1 addStudent1Details()
  {
	  Student1 St1=new Student1();
	  St1.Stud1Id=102;
	  St1.Stud1Name="Swapnil";
	  St1.Stud1Email="Abc@123";
	  St1.Stud1Add="Pimpri";
	  St1.Stud1Mobile=4561237890l;
	  return St1;
  }
   public static void main(String[] args)
   {
	Teststd ts=new Teststd();
	Student std=ts.addStudentDetails();
	System.out.println(std.StudId+" "+std.StudName+" "+std.StudEmail+" "+std.StudAdd+" "+std.StudAdd+" "+std.StudMobile);
	Student1 std1=ts.addStudent1Details();
	System.out.println(std1.Stud1Id+" "+std1.Stud1Name+" "+std1.Stud1Email+" "+std1.Stud1Add+" "+std1.Stud1Mobile);
   }
  
}
