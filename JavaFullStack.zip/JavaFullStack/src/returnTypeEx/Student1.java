package returnTypeEx;

public class Student1
{
	 int Stud1Id;
	 String Stud1Name;
	 String Stud1Email;
	 String Stud1Add;
	 long Stud1Mobile; 
}
