package returnTypeEx;

public class Son 
{
 int SonId;
 String SonName;
 String SonAdd;
 long SonMobile;
 String SonBuss;
}
