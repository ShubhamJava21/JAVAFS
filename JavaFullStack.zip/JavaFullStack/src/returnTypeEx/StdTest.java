package returnTypeEx;

public class StdTest
{
  public Std addStdDetails()
  {
	  Std S=new Std();
	  S.RollNo=121;
	  S.Name="Shubham";
	  S.Address="Pimpri";
	  S.mobile=82536437357l;
	  S.div='A';
	  S.Addhar=15434362536537l;
	  S.Email="Abc@123";
	  S.Pan="123GPF";
	  S.per=89.9f;
	  S.Resispass=true;
	  return S;
  }
  public static void main(String[] args) 
  {
	StdTest st=new StdTest();
	Std D=st.addStdDetails();
	System.out.println(D.Name+" "+D.RollNo+" "+D.Address+" "+D.div+" "+D.Addhar+" "+D.Email+" "+D.per+" "+D.mobile+" "+D.RollNo);
  }
}
