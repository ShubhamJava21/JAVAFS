package returnTypeEx;

public class Student 
{
int StudId;
 String StudName;
 String StudEmail;
 String StudAdd;
 long StudMobile;
}
