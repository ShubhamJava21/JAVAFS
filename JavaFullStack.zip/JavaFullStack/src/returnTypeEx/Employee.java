package returnTypeEx;

public class Employee 
{
  int EId;
  String EName;
  Float EmpSal;
  
}
