package returnTypeEx;

public class DemoClass 
{
  public void m1()
  {
	  System.out.println("Method M1 Called");
  }
  public int m2()
  {
	  int RollNo=20;
	  return RollNo;
  }
  public String m3()
  {
	  return "Sarvesh";
  }
  public boolean m4()
  {
	  return true;
  }
  public char m5()
  {
	  return 'A';
  }
  public Float m6()
  {
	  return 10.5f;
  }
  
  public Employee addEmployeeDetails()
  {
	  Employee e=new Employee();
	  e.EId=11;
	  e.EName="Shubham";
	  e.EmpSal=89000.90f;
	  return e;		  
  }
  public Compony addComponyDetails()
  {
	  Compony com=new Compony();
	  com.ComId=21;
	  com.CompName="Infy";
	  return com;
  }
  public static void main(String[] args) 
  {
	DemoClass D=new DemoClass();
	Employee Emp=D.addEmployeeDetails();
	System.out.println(Emp.EId+" "+Emp.EName+" "+Emp.EmpSal);
	Compony Com=D.addComponyDetails();
	System.out.println(Com.ComId+" "+Com.CompName);
	D.m1();
	int i=D.m2();
	System.out.println(i);
	String S=D.m3();
	System.out.println(S);
	boolean b =D.m4();
	System.out.println(b);
	char c=D.m5();
	System.out.println(c);
	float f=D.m6();
	System.out.println(f);
  }
}
