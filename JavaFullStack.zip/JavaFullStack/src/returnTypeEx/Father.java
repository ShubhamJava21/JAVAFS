package returnTypeEx;

public class Father 
{
 int FathId;
 String FathName;
 String FathAdd;
 long FathMobile;
 String FathBuss;
}
