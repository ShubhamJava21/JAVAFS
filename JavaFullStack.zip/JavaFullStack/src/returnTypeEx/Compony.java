package returnTypeEx;

public class Compony 
{
 int ComId;
 String CompName;
}
