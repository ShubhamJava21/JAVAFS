package returnTypeEx;

public class Std 
{
	short RollNo;
	 char div;
	 String Name;
	 float per;
	 String Email;
	 String Address;
	 long mobile;
	 long Addhar;
	 String Pan; 
	 boolean Resispass;
}
