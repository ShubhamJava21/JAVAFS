package accessModifiers2;

import accessModifiers.ProEx;

public class TestProEx extends ProEx
{
  public TestProEx(int Empid, String EmpName, String EmpAddress, long EmpMobile, char EmpBG) {
		super(Empid, EmpName, EmpAddress, EmpMobile, EmpBG);
		// TODO Auto-generated constructor stub
	}

public static void main(String[] args) 
  {
	    TestProEx em=new TestProEx(101,"Shubham","Pimpri",8794647l,'O');
		System.out.println("Emp info:" +em.id+" "+em.Name+" "+em.Address+" "+em.Mobile+" "+em.BG);
		TestProEx em1=new TestProEx(102,"Saurabh","Psaud",9894647l,'O');
		System.out.println("Emp info:"+em1.id+" "+em1.Name+" "+em1.Address+" "+em1.Mobile+" "+em1.BG);	
	
  }
}
