package accessModifiers2;

import accessModifiers.ProtectEx;

public class TestProtect extends ProtectEx
{
  public static void main(String[] args)
  {
	TestProtect tp=new TestProtect();
	tp.n1();
	System.out.println(tp.c);
   }
}
