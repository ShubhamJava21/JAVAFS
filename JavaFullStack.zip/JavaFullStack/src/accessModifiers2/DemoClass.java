package accessModifiers2;

public class DemoClass 
{
 public static void main(String[] args)
 {
//	DefaultAM dt=new DefaultAM();
//	System.out.println(d.did);
//	d.m1();
 }
}
