package accessModifiers2;

import accessModifiers.Student;

public class TestStd 
{
  public static void main(String[] args) 
  {
	Student s=new Student();
	s.RollNo=231;
	s.Name="Shubham";
	s.Address="Pimpri";
	s.Mobile=29837373l;
	s.Grade='A';
	System.out.println("Student Information: "+s.RollNo+" "+s.Name+" "+s.Address+" "+s.Mobile+" "+s.Grade);
//	s.m1();
//	s.m2();    //Both are private & Default in another access modifier
	
  }
}
