package finalKeyword;

public class Tests1 
{
  public static void main(String[] args)
  {
	//s1.fid=200;  //final key error
	Sample1 s1=new Sample1();
	System.out.println(s1.fid);
	s1.m1();
	s1.m3();
	s1.m2(100, 200);
//	@Override 
//	public void m2()
//	{
//		
//	}
	
	//cant override m1();
  }
}
