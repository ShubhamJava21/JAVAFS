package finalKeyword;

public class Test2 
{
  public static void main(String[] args)
  {
	Sample2 s2=new Sample2();
	s2.m1();
	System.out.println(s2.sid+" "+s2.sname+" "+s2.sAdd);
	
	//m1 cant able to override m1
	//s2.sid=89; //final key error
  }
}
