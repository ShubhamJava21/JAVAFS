package finalKeyword;

public class Sample1 
{
   final int fid=10;
   
   public final void m1() 
   {
	System.out.println("M1 method of Sample1");

   }
     public void m2(final int i, final int j) 
     {
    	 //int i=200 //final key error
		System.out.println(i+" "+j);
	 }
   
   public void m3() 
   {
	System.out.println("--M2 method of sample1--");
   }
   
} 
