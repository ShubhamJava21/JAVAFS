package finalKeyword;

public class Sample2 
{
 final int sid=21;
 final String sname="Shubham";
 final String sAdd="Pimpri";
 
 public final void m1() 
  {
	System.out.println(sid+" "+sname+" "+sAdd);

  }
 
}
