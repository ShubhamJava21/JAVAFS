package componyMgtSys;

public class Tester 
{
	int Tid;
	String Tname;
	int TSalary;
	Developer D=new Developer();
}
