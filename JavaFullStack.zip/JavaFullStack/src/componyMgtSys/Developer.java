package componyMgtSys;

public class Developer
{
 int Did;
 String Dname;
 int DSalary;
}
