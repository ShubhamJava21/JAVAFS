package componyMgtSys;

public class TeamLead 
{
	int TLid;
	String TLname;
	int TLSalary;
	Tester T=new Tester();
}
