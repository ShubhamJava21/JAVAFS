package componyMgtSys;

public class Manager 
{
	int Mid;
	String Mname;
	int MSalary;
  TeamLead Tl=new TeamLead();
  
  public static void main(String[] args) 
  {
	Manager M=new Manager();
	M.Mid=101;
	M.Mname="Shubham";
	M.MSalary=500000;
	M.Tl.TLid=102;
	M.Tl.TLname="Swapnil";
	M.Tl.TLSalary=400000;
	M.Tl.T.Tid=103;
	M.Tl.T.Tname="Saurabh";
	M.Tl.T.TSalary=100000;
	M.Tl.T.D.Did=104;
	M.Tl.T.D.Dname="Suraj";
	M.Tl.T.D.DSalary=350000;
	
System.out.println("Manager Id: "+M.Mid+" "+"Manager Name: "+M.Mname+" "+"Manager Salary: "+M.MSalary);
System.out.println("TeamLead Id: "+M.Tl.TLid+" "+"TeamLead Name: "+M.Tl.TLname+" "+"TeamLead Salary: "+M.Tl.TLSalary);	
System.out.println("Tester Id: "+M.Tl.T.Tid+" "+"Tester Name: "+M.Tl.T.Tname+" "+"Tester Salary: "+M.Tl.T.TSalary);	
System.out.println("Developer Id: "+M.Tl.T.D.Did+" "+"Developer Name: "+M.Tl.T.D.Dname+" "+"Developer Salary: "+M.Tl.T.D.DSalary);	
  }
}
