package componyMgtSys;

public class TestComponyMgtSys {

}
