package arrayIterator;

public class Compony 
{
 public Employee[] addEmpDetails() 
 {
	Employee emp=new Employee();
	emp.setEmpid(11);
	emp.setEmpname("SHUBHAM");
	emp.setEmpno(3837397393l);
	emp.setEmpadd("PIMPRI");
	Employee emp1=new Employee();
	emp1.setEmpid(12);
	emp1.setEmpname("SHRIKANT");
	emp1.setEmpno(39784393l);
	emp1.setEmpadd("PIMPRI");
	Employee emp2=new Employee();
	emp2.setEmpid(13);
	emp2.setEmpname("TUSHAR");
	emp2.setEmpno(739348764l);
	emp2.setEmpadd("CHINCHWAD");
	Employee emp3=new Employee();
	emp3.setEmpid(14);
	emp3.setEmpname("SATTYAS");
	emp3.setEmpno(973734893l);
	emp3.setEmpadd("PUNE");
	
	Employee[] arrayOfEmp={emp,emp1,emp2,emp3};
	return arrayOfEmp;
	
 }
}
