package arrayIterator;

public class Father 
{
 int fid;
 String fname;
 long fno;
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public long getFno() {
	return fno;
}
public void setFno(long fno) {
	this.fno = fno;
}
 
}
