package arrayIterator;

public class Son 
{
  int sid;
  String sname;
  long sno;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public long getSno() {
	return sno;
}
public void setSno(long sno) {
	this.sno = sno;
}
  
}
