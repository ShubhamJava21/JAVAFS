package arrayIterator;

public class Organization 
{
 public static void main(String[] args) 
 {
	 Compony com=new Compony();
	 Employee[] cm=com.addEmpDetails();
	 for(Employee em:cm)
	 {
		 System.out.println(em.getEmpid()+" "+em.getEmpname()+" "+em.getEmpno()+" "+em.getEmpadd());
	 }
	
 }
}
