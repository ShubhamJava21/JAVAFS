package arrayIterator;

public class Example2 
{
 public static void main(String[] args) 
 {
	int[] arr= {101,201,301,401,501,601,701,801,901,1001};
	for(int array:arr)
	{
		System.out.println(array);
	}
	String[] arr1= {"Shubham","Swapnil","Saurabh","Sattyass"};
	for(String arraySt:arr1)
	{
		System.out.println(arraySt);
	}
	char[] arr2= {'A','B','C','D','E','F','G','H'};
	for(char arrayCh:arr2)
	{
		System.out.println(arrayCh);
	}
	float[] arr3= {12.23f,54.89f,67.90f,89.89f,67.87f};
	for(float arrayFlt:arr3)
	{
		System.out.println(arrayFlt);
	}
	boolean[] arr4= {true,false};
	for(boolean arrayofBln:arr4)
	{
		System.out.println(arrayofBln);
	}
	
 }
}
