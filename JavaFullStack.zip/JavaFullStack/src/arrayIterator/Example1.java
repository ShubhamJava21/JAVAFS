package arrayIterator;

public class Example1 
{
 public static void main(String[] args) 
 {
	String[] strArray= {"abc","pqr","xyz","mnp","jkl"};
	System.out.println(strArray[0]);
	
	for(int i=0;i < strArray.length;i++)
	{
		System.out.println(strArray[i]);
	}
	System.out.println("---Foreach loop----");
	for(String s: strArray)
	{
		System.out.println(s);
	}
}
}
