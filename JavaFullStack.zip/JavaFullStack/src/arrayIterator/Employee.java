package arrayIterator;

public class Employee 
{
 int empid;
 String empname;
 long empno;
 String empadd;
public int getEmpid() 
{
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public long getEmpno() {
	return empno;
}
public void setEmpno(long empno) {
	this.empno = empno;
}
public String getEmpadd() {
	return empadd;
}
public void setEmpadd(String empadd) {
	this.empadd = empadd;
}
 
 
}
