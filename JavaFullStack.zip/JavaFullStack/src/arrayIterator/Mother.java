package arrayIterator;

public class Mother
{
 int mid;
 String mname;
 long mno;
public int getMid() {
	return mid;
}
public void setMid(int mid) {
	this.mid = mid;
}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public long getMno() {
	return mno;
}
public void setMno(long mno) {
	this.mno = mno;
}
 
}
