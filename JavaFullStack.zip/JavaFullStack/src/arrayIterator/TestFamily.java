package arrayIterator;

public class TestFamily 
{
 public static void main(String[] args) 
 {
	Family fam=new Family();
	Father[] f1=fam.addFatherDetails();
	for(Father fm:f1)
	{
		System.out.println("Father Details: "+fm.getFid()+" "+fm.getFname()+" "+fm.getFno());
	}
	Mother[] f2=fam.addMotherDetails();
	for(Mother mm:f2)
	{
		System.out.println("Mother Details: "+mm.getMid()+" "+mm.getMname()+" "+mm.getMno());
	}
	Son[] f3=fam.addSonDetails();
	for(Son sn:f3)
	{
		System.out.println("Sons Details: "+sn.getSid()+" "+sn.getSname()+" "+sn.getSno());
	}
	
 }
}
