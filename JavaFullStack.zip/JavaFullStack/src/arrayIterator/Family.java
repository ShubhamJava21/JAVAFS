package arrayIterator;

public class Family 
{
  public Father[] addFatherDetails()
  {
	  Father f=new Father();
	  f.setFid(01);
	  f.setFname("Ashok");
	  f.setFno(948894789);
	  Father[] arrayofFather= {f};
	  return arrayofFather;
  }
  public Mother[] addMotherDetails()
  {
	  Mother m=new Mother();
	  m.setMid(02);
	  m.setMname("REKHA");
	  m.setMno(893739873);
	  
	  Mother[] arrayofMother= {m};
	  return arrayofMother;
  }
  public Son[] addSonDetails() 
  {
	Son s=new Son();
	s.setSid(03);
	s.setSname("SHUBHAM");
	s.setSno(984764846);
	
	Son[] arrayofSon= {s};
	return arrayofSon;
  }
}
