package singlelevelinheritance;

public class TestEmp 
{
  public static void main(String[] args) 
  {
	 Emp e=new Emp();
	 e.Name("Infosys");
	 e.Name1("Shubham");
	 e.id(1202);
	 e.id1(121);
	 e.Address("Hinjewadi");
	 e.Address1("Pimpri");
	 e.Salary1(20000000);
	 
System.out.println("Compony & One Emp Information: \n"+"Compony Addr: \n"+e.id+" \n"+"Emp Address: "+e.id1+" \n"+"Compony Name: "+e.Name+" \n"+"Emp Name: "+e.Name1+" \n"+"Compony Address: "+e.Address+" \n"+"Emp Address: "+e.Address1+" \n"+"Emp Salary: "+e.Salary1);
  }
}
