package singlelevelinheritance;

public class TestStudent 
{
  public static void main(String[] args) 
  {
	Student s=new Student();
	s.setColgId(11011);
	s.setId(161);
	s.setName("Jspm");
	s.setName("Shubham");
	s.setAddress("Pimpri");
	s.setFees(100000);
	s.setMobile(278363763l);
	System.out.println(s.getId()+" "+s.getAddress()+" "+s.getFees()+" "+s.getMobile()+" "+s.getName()+" "+s.getColgId());
  }
}
