package singlelevelinheritance;

public class College 
{
   int colgId;
   String Name;
   String Address;
   int Fees;
   long Mobile;
public int getColgId() 
{
	return colgId;
}
public void setColgId(int clgId) 
{
	colgId = clgId;
}
public String getName() 
{
	return Name;
}
public void setName(String Clgname) 
{
	Name = Clgname;
}
public String getAddress() 
{
	return Address;
}
public void setAddress(String Clgaddress) 
{
	Address = Clgaddress;
}
public int getFees() 
{
	return Fees;
}
public void setFees(int Clgfees) 
{
	Fees = Clgfees;
}
public long getMobile() 
{
	return Mobile;
}
public void setMobile(long Clgmobile) 
{
	Mobile = Clgmobile;
}
}
