package singlelevelinheritance;

public class A 
{
 int i=10;
 
 public void m1()
 {
	 System.out.println("M1 Method of class A");
 }
}
