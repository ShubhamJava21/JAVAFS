package singlelevelinheritance;

public class Compony 
{
 int id;
 String Name;
 String Address;
 
 public int id(int CompId) 
 {
	 id=CompId;
	 return id;
 }
 public String Name(String Comname)
 {
	 Name=Comname;
	 return Name;
 }
 public String Address(String ComAddress)
 {
	 Address=ComAddress;
	 return Address;
 }
}
