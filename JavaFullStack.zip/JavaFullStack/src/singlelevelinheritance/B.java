package singlelevelinheritance;

public class B extends A 
{
  int j=20;
  
  public void m2()
  {
	  System.out.println("M2 method from Class B");
  }
  
  public static void main(String[] args)
  {
	 B b=new B();
	 b.m1();
	 b.m2();
	 System.out.println(b.i);
	 System.out.println(b.j);
  }
}
