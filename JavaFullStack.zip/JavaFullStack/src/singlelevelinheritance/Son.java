package singlelevelinheritance;

public class Son extends Father
{
	 public void Bike()
	 {
		 System.out.println("Vespa Byk");
	 }
	 public void Laptop() 
	 {
		System.out.println("HP"); 
	 }
	 public static void main(String[] args) 
	 {
		Son s=new Son();
		s.Home();
		s.Car();
		s.BankBal();
		s.Bike();
		s.Laptop();
	 }
}
