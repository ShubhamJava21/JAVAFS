package singlelevelinheritance;

public class Emp extends Compony
{
  int id1;
  String Name1;
  String Address1;
  int Salary1;
  
  public int id1(int EmpId) 
  {
	  id1=EmpId;
	  return id1;
  }
  public String Name1(String EmpName)
  {
	  Name1=EmpName;
	  return Name1;			  
  }
  public String Address1(String EmpAdd) 
  {
	Address1=EmpAdd;
	return Address1;
  }
  public int Salary1(int EmpSal)
  {
	  Salary1=EmpSal;
	  return Salary1;
  }
}
