package singlelevelinheritance;

public class Student extends College 
{
	int id;
	String Name;
	String Address;
	public int getId() 
	{
		return id;
	}
	public void setId(int Stdid)
	{
		id = Stdid;
	}
	public String getName() 
	{
		return Name;
	}
	public void setName(String Stdname) 
	{
		Name = Stdname;
	}
	public String getAddress() 
	{
		return Address;
	}
	public void setAddress(String Stdaddress) 
	{
		Address = Stdaddress;
	}
	
	
	

}
