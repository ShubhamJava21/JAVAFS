package singlelevelinheritance;

public class Father 
{
  public void Home()
  {
	  System.out.println("Grand 3BHK House");
  }
  public void Car()
  {
	  System.out.println("Range Rover");
  }
  public void BankBal()
  {
	  System.out.println("40lacs");
  }
}
