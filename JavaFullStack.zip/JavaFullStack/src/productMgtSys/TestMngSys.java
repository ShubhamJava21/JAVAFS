package productMgtSys;

public class TestMngSys
{

public Product addProductDetails()
 {
	Product P=new Product();
	 P.ProdId=101;
	 P.ProdName="ABC";
	 return P;
 }
 public Order addOrderDetails()
 {
	 Order Od=new Order();
	 Od.OrdId=102;
	 Od.OrdName="XYZ";
	 Od.OrdDate="25Jan2025";
	 Od.OrdPrice=5600;
	 return Od;
	 
 }
 public Customer addCustomerDetails()
 {
	 Customer Cs=new Customer();
	 Cs.CustId=104;
	 Cs.CustName="REW";
	 Cs.CustAdd="Pune";
	 Cs.CustMobile=12345667890l;
	 Cs.CustEmail="qwer@123";
	 return Cs;
 }
 
  public static void main(String[] args)
  {
	TestMngSys Test=new TestMngSys();
	Order Or=Test.addOrderDetails();
	System.out.println("OrderId: "+Or.OrdId+ "OrderName:"+Or.OrdName+ "OrderDate:"+Or.OrdDate+"OrderPrice: "+Or.OrdPrice);
	
	Customer Cs=Test.addCustomerDetails();
	System.out.println("CustomerId: "+Cs.CustId+  "CustomerName: "+Cs.CustName+ "CustomerAdd: "+Cs.CustAdd+  "CustomerEmail: "+Cs.CustEmail+ "Customer Mobile: "+Cs.CustMobile);
	
	Product Pd=Test.addProductDetails();
	System.out.println("ProductId: "+Pd.ProdId+ "ProductName: "+Pd.ProdName);
  }
}
