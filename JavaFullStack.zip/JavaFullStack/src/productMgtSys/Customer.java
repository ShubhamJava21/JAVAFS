package productMgtSys;

public class Customer 
{
 int CustId;
 String CustName;
 String CustAdd;
 String CustEmail;
 long CustMobile;
}
