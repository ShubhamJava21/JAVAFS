package productMgtSys;

public class Order 
{
 int OrdId;
 String OrdName;
 String OrdDate;
 int OrdPrice;
}
