package productMgtSys;

public class Product 
{
 int ProdId;
 String ProdName;
 
}
