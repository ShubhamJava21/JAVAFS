package debuggLogicalPrg;

public class A 
{
  int x=10;
  int y;
  
  public A m1()
  {
	  A a1=new A();
	  a1.x=100;
	  a1.y=200;
	  a1.x=1000;
	  a1.y=2000;
	  A a3=new A();
	  a3.x=9;
	  a3.y=7;
	  return a3;
  }
   public static void main(String[] args) 
   {
	 A a=new A();
	 System.out.println(a.x);
	 System.out.println(a.y);
	 A a2=a.m1();
	 System.out.println(a2.x);
	 System.out.println(a2.y);
   }
}
