package covariantReturntypeCasting;

public class P 
{
  int i=20;
  public void m1() 
  {
	System.out.println("Method m1() of Clss P");
  }
  
}
