package covariantReturntypeCasting;

public class College 
{
  String name;
  String Address;
  
  public void m1() 
  {
	System.out.println(name+" "+Address);
  }
 
  
  
}
