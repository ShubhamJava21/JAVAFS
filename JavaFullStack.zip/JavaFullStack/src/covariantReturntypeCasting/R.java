package covariantReturntypeCasting;

public class R extends Q 
{
	int k=50;
	
	public void m3()
	{
	  System.out.println("Method m3() of class R");	

	}

}
