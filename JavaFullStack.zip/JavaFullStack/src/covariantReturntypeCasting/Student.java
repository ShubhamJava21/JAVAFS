package covariantReturntypeCasting;

public class Student extends Professor
{
  String name2;
  String Address2;
  public void m3()
  {
	  System.out.println(name2+" "+Address2);
  }
  
  
}
