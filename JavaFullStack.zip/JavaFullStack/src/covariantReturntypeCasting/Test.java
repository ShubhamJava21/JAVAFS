package covariantReturntypeCasting;

public class Test
{
    public College testMethod() 
    {
    	Student st=new Student();
    	  st.name="J.S.P.M";
    	  st.Address="Tathawade";
    	  st.name1="Nilesh";
    	  st.Address1="Akurdi";
    	  st.name2="Shubham";
    	  st.Address2="Pimpri";
    	  System.out.println(st.name+" "+st.Address);
    	  System.out.println(st.name1+" "+st.Address1);
    	  System.out.println(st.name2+" "+st.Address2);
    	  return st;
	}
    public static void main(String[] args) 
    {  
//      Student st=new Student();
//  	  st.name="J.S.P.M";
//  	  st.Address="Tathawade";
//  	  st.name1="Nilesh";
//  	  st.Address1="Akurdi";
//  	  st.name2="Shubham";
//  	  st.Address2="Pimpri";
//  	  System.out.println(st.name+" "+st.Address);
//  	  System.out.println(st.name1+" "+st.Address1);
//  	  System.out.println(st.name2+" "+st.Address2);
  	  
	   System.out.println("--Covarient Return Type--");
	   Test t=new Test();
	   Student st1=(Student) t.testMethod();
//	   st1.m1();
//	   st1.m2();
//	   st1.m3();
	   System.out.println(st1);
	}
}
