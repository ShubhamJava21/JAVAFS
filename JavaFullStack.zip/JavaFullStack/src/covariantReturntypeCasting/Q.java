package covariantReturntypeCasting;

public class Q extends P
{
 int j=20;
 
 public void m2()
 {
	System.out.println("Method m2() of Class Q");

}
}
