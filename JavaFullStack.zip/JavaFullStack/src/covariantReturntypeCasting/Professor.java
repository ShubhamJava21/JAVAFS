package covariantReturntypeCasting;

public class Professor extends College
{
	String name1;
	String Address1;
	
	public void m2() 
	{
		System.out.println(name1+" "+Address1);
	}
	
	
	
	

}
