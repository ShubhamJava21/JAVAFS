package covariantReturntypeCasting;

public class TestClass 
{
	public P TestMethod()
	{
//		P p=new P();
//		Q q=new Q();
		R r=new R();
		
		return r;
		//return p;
		//return q;
	}
 public static void main(String[] args) 
 {
	TestClass tc=new TestClass();
//	   P  p=tc.TestMethod();
//	   p.m1();
//	   System.out.println(p.i);
	   
//	  Q q=tc.TestMethod();
//	  q.m1();
//	  q.m2();
//	  System.out.println(q.i);
//	  System.out.println(q.j);
	  
	 R r=(R)tc.TestMethod();
	 r.m1();
	 r.m2();
	 r.m3();
	 System.out.println(r.i);
	 System.out.println(r.j);
	 System.out.println(r.k);
 }
}
