package constructorChainingThisSuper;

public class A 
{
  A(int i)
  {
	this(55,56,88);
	System.out.println(999);
  }
  A(int i, int j)
  {
	  System.out.println(333);
  }
  A(int i,int j,int k)
  {
	  this(55,66,77,88);
	  System.out.println(444);
  }
  A(int i,int m,int n,int l)
  {
	  System.out.println(111);
  }
}
