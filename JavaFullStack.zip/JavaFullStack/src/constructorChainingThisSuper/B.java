package constructorChainingThisSuper;

public class B extends A
{
  B()
  {
	  this(55);
	  System.out.println(555);
  }
  B(int i)
  {
	  this(45.f,4567l);
	  System.out.println(666);
  }
  B(float f, long l)
  {
	 this("Ravi");
	 System.out.println(555);
  }
  B(String str)
  {
	  super(888);
	  System.out.println(777);
  }
  public static void main(String[] args)
  {
	B b=new B();
  }
}
