package constructorChainingThisSuper;

public class Sample1 
{
  Sample1()
  {
	  this(452.f);
	  System.out.println("Parent Constructor");
  }
  Sample1(float f)
  {
	 System.out.println("1 Parameter Constructor"); 
  }
}
