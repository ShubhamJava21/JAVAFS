package constructorChainingThisSuper;

public class Sample2 extends Sample1 
{
  Sample2()
  {
	  this(55);
	  System.out.println("Child Constructor");
  }
  Sample2(int i)
  {
	  this(102,true);
	  System.out.println("Integer Para Constructor");
  }
  Sample2(int i,boolean flag)
  {
	  super();
	  System.out.println("2 Para Constructor");
  }
  public static void main(String[] args)
  {
	Sample2 s2=new Sample2();
	
}
}
