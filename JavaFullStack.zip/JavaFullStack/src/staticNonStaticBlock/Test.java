package staticNonStaticBlock;

public class Test 
{
  static
  {
	 System.out.println("Static Block...");
  }
  
  {
	  System.out.println("NonStatic Block");
  }
  
  public Test()
  {
	 System.out.println("Constructor Call");  
  }
   
  public static void main(String[] args) 
  {
	System.out.println("Main Method called");
	Test t=new Test();
	Test t1=new Test();
  }
  
  
}
