package studentmgtSysWithArray;

public class University 
{
 public static void main(String[] args) 
 {
	College cl=new College();
	Student[] st=cl.addStudent();
	for(Student s:st)
	{
		System.out.println(s.getSid()+" "+s.getSname()+" "+s.getAddress());
	}
 }
}
