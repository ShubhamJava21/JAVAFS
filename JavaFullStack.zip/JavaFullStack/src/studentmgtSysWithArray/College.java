package studentmgtSysWithArray;

public class College 
{
  public Student[] addStudent()
  {
	  Student std=new Student();
	  std.setSid(101);
	  std.setSname("Shubham");
	  std.setAddress("Pimpri");
	  Student std1=new Student();
	  std1.setSid(102);
	  std1.setSname("Swapnil");
	  std1.setAddress("Pimpri");
	  Student std2=new Student();
	  std2.setSid(103);
	  std2.setSname("Saurabh");
	  std2.setAddress("PSaud");
	  Student std3=new Student();
	  std3.setSid(104);
	  std3.setSname("Akash");
	  std3.setAddress("PSaud");
	  Student std4=new Student();
	  std4.setSid(105);
	  std4.setSname("Satyyas");
	  std4.setAddress("Pune");
	  
	  Student[] arrayofStudent= {std,std1,std2,std3,std4};
		return arrayofStudent;
  }
}
