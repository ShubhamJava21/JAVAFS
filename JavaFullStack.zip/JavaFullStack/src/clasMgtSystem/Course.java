package clasMgtSystem;

public class Course 
{
 int cid;
 String cname;
}
