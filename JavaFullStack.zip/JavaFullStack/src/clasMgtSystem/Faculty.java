package clasMgtSystem;

public class Faculty 
{
 int fid;
 String fname;
 Course c=new Course();
}
