package clasMgtSystem;

public class Student 
{
 int sid;
 String sname;
 Batch b=new Batch();
 
 public static void main(String[] args)
 {
	 Student s=new Student();
	 s.sid=101;
	 s.sname="Shubham";
	 s.b.bid=11;
	 s.b.bname="B55";
	 s.b.f.fid=30;
	 s.b.f.fname="NileshSir";
	 s.b.f.c.cid=21;
	 s.b.f.c.cname="EXponent";
	 
	 System.out.println("Student id: "+s.sid);
	 System.out.println("Student Name: "+s.sname);
	 System.out.println("Batch id: "+s.b.bid);
	 System.out.println("Batch Name: "+s.b.bname);
	 System.out.println("Faculty id: "+s.b.f.fid);
	 System.out.println("Faculty Name: "+s.b.f.fname);
	 System.out.println("Class id: "+s.b.f.c.cid);
	 System.out.println("Class Name: "+s.b.f.c.cname);
	 
	
 }
}
