package empMgtSysConstructorMethodOverriding;

public class Manager extends Emp
{
    int TmSize;
	public Manager(int Empid, String Empname, int EmpSalary,int TeamSize) 
	{
		super(Empid, Empname, EmpSalary);
		// TODO Auto-generated constructor stub
		TmSize=TeamSize;
	}
	@Override
	public void displayEmpDetails()
	{
		System.out.println("---Manager Details---");
		// TODO Auto-generated method stub
		super.displayEmpDetails();
		System.out.println(TmSize);
	}

}
