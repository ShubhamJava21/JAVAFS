package empMgtSysConstructorMethodOverriding;

public class Tester extends Manager 
{
    int noBugs;
	public Tester(int Empid, String Empname, int EmpSalary, int TeamSize,int nooBugs) 
	{
		super(Empid, Empname, EmpSalary, TeamSize);
		// TODO Auto-generated constructor stub
		noBugs=nooBugs;
	}
	@Override
	public void displayEmpDetails() 
	{
		System.out.println("---Tester Details---");
		// TODO Auto-generated method stub
		super.displayEmpDetails();
		System.out.println(noBugs);
	}

}
