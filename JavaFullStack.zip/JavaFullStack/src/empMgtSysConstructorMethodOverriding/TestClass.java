package empMgtSysConstructorMethodOverriding;

public class TestClass 
{
 public static void main(String[] args) 
 {
	System.out.println("---Employee Details---");
	Emp e=new Emp(12, "Shubham", 12000000);
	System.out.println(e.id+" "+e.name+" "+e.Salary);
	
	System.out.println("--Manager Details---");
	Manager m=new Manager(31, "Nilesh", 1200000, 16);
	System.out.println(m.id+" "+m.name+" "+m.Salary+" "+m.TmSize);
	
	System.out.println("---Developer Details---");
	Developer d=new Developer(41, "Shubham", 13000000, 16, "Java");
	System.out.println(d.id+" "+d.name+" "+d.Salary+" "+d.TmSize+" "+d.ProgLang);
	
	System.out.println("--Tester Details---");
	Tester t=new Tester(51, "Saurabh", 1100000, 16, 300);
	System.out.println(t.id+" "+t.name+" "+t.Salary+" "+t.TmSize+" "+t.noBugs);
 }
}