package empMgtSysConstructorMethodOverriding;

public class Emp 
{
	  int id;
	  String name;
	  int Salary;
	 public Emp(int Empid, String Empname, int EmpSalary)
	   {
		 id=Empid;
		 name=Empname;
		 Salary=EmpSalary;
	   }
	 public void displayEmpDetails()
	 {
		 System.out.println(id+" "+" "+name+" "+Salary);
	 }
}
