package empMgtSysConstructorMethodOverriding;

public class Developer extends Manager
{
    String ProgLang;
	public Developer(int Empid, String Empname, int EmpSalary, int TeamSize,String ProgramingLang) 
	{
		super(Empid, Empname, EmpSalary, TeamSize);
		// TODO Auto-generated constructor stub
	     ProgLang=ProgramingLang;
	}
	@Override
	public void displayEmpDetails() 
	{
		System.out.println("---Developer Details---");
		// TODO Auto-generated method stub
		super.displayEmpDetails();
		System.out.println(ProgLang);
	}
	

}
