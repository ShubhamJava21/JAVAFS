package toStringMethodEx;

public class Student 
{
 int RollNo;
 String Name;
 
 public String toString()
 {
	 System.out.println("Student information: "+RollNo+" "+Name);
	return Name;
 }
 
 public static void main(String[] args)
 {
	Student s=new Student();
	s.RollNo=21;
	s.Name="Shubham";
	System.out.println(s.RollNo+" "+s.Name);
	System.out.println(s.toString());
 }
}
