package datatypes;

public class Employee 
{
	 short EmpId=21;
	 char EmpSec='A';
	 String EmpName="Shubham";
	 float EmpSal= 98.4500f;
	 String EmpEmail= "Abc12345@gmail.com";
	 String EmpAddress="Pimpri";
	 long Empmobile=9518999923l;
	 long EmpAddhar=34624365635373537l;
	 String EmpPan="345634LPG"; 
	 boolean EmpIsPerm=true;
	 String EmpBloodGroup="O+";
	 String EmpClient="Usa";
	 String EmpProject="Banking";
	 String EmpTL="Nilesh";
	 String EmpMan="Ajay";
	  
	    public static void main(String[] args) 
	    {
	    	Employee em=new Employee();
			System.out.println("Employee Id: "+em.EmpId);
			System.out.println("Employee Section: "+em.EmpSec);
			System.out.println("Employee Name: "+em.EmpName);
			System.out.println("Employee Salary: "+em.EmpSal);
			System.out.println("Employee Email: "+em.EmpEmail);
			System.out.println("Employee Address: "+em.EmpAddress);
			System.out.println("Employee Mobile No: "+em.Empmobile);
			System.out.println("Employee AddharNo: "+em.EmpAddhar);
			System.out.println("Employee PanCardNo: "+em.EmpPan);
			System.out.println("Employee Is Permanant: "+em.EmpIsPerm);
			System.out.println("Employee Blood Group: "+em.EmpBloodGroup);
			System.out.println("Employee Client: "+em.EmpClient);
			System.out.println("Employee Project: "+em.EmpProject);
			System.out.println("Employee Team Lead: "+em.EmpTL);
			System.out.println("Employee Manager: "+em.EmpMan);
			
		}
}
