package datatypes;

public class Family 
{
	 short FamilyNo=111;
	 char famPrabhag='D';
	 String FamName="Shinde";
	 String FamEmail= "Abc12345@gmail.com";
	 String FamAddress="Pimpri";
	 long Fammobile=9518999923l;
	 long FamAddhar=34624365635373537l;
	 String FamPan="345634LPG"; 
	 boolean FamResis=true;
	  
	    public static void main(String[] args) 
	    {
	    	Family fm=new Family();
			System.out.println("Family No: "+fm.FamilyNo);
			System.out.println("Family Prabhag: "+fm.famPrabhag);
			System.out.println("Family Name: "+fm.FamName);
			System.out.println("Family Email: "+fm.FamEmail);
			System.out.println("Family Address: "+fm.FamAddress);
			System.out.println("Family Mobile: "+fm.Fammobile);
			System.out.println("Family AddharNo: "+fm.FamAddhar);
			System.out.println("Family PanCardNo: "+fm.FamPan);
			System.out.println("Family Is Permanant Resident: "+fm.FamResis);
			
			
		}
}
