package datatypes;

public class Student
{
	 short RollNo=127;
	 char div='A';
	 String Name="Shubham";
	 float per= 88.45f;
	 String Email= "Abc12345@gmail.com";
	 String Address="Pimpri";
	 long mobile=9518999923l;
	 long Addhar=34624365635373537l;
	 String Pan="345634LPG"; 
	 boolean Resispass=true;
	  
	    public static void main(String[] args) 
	    {
	    	Student ds=new Student();
			System.out.println("Students RollNo: "+ds.RollNo);
			System.out.println("Students Div: "+ds.div);
			System.out.println("Students Name: "+ds.Name);
			System.out.println("Students Percentage: "+ds.per);
			System.out.println("Students Email: "+ds.Email);
			System.out.println("Students Address: "+ds.Address);
			System.out.println("Students Mobile No: "+ds.mobile);
			System.out.println("Students AddharNo: "+ds.Addhar);
			System.out.println("Students PanCardNo: "+ds.Pan);
			System.out.println("Students Result: "+ds.Resispass);
			
			
		}
}
