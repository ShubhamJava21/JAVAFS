package datatypes;

public class Datatpespractice 
{
  byte b=127;
  short s=2003;
  int i=123456789;
  long l=1234567890;
  float f= 123.45f;
  double d=1234.5678d;
  
  boolean bool=true;
  char c='a';
  
    public static void main(String[] args) 
    {
    	Datatpespractice ds=new Datatpespractice();
		System.out.println(ds.b);
		System.out.println(ds.s);
		System.out.println(ds.i);
		System.out.println(ds.l);
		System.out.println(ds.f);
		System.out.println(ds.d);
		System.out.println(ds.bool);
		System.out.println(ds.c);
		
	}
  
}
