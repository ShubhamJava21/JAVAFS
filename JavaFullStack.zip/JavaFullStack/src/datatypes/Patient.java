package datatypes;

public class Patient
{
	 short PatientId=67;
	 String PatientLastName="Kulkarni";
	 String PatientFirstName="Ronak";
	 String PatEmail= "Abc12345@gmail.com";
	 String PatAddress="Pune";
	 String PatBloodGrp="O+";
	 long Patmobile=9867590542l;
	 long PatAddhar=34624365635373537l;
	 String PatPan="345634LPG"; 
	 boolean PatisNew=true;
	  
	    public static void main(String[] args) 
	    {
	    	Patient P=new Patient();
			System.out.println("Patient Id: "+P.PatientId);
			System.out.println("Patient Last Name: "+P.PatientLastName);
			System.out.println("Patient first Name: "+P.PatientFirstName);
			System.out.println("Patient Email: "+P.PatEmail);
			System.out.println("Patient Address: "+P.PatAddress);
			System.out.println("Patient Blood Group: "+P.PatBloodGrp);
			System.out.println("Patient  Mobile: "+P.Patmobile);
			System.out.println("Patient AddharNo: "+P.PatAddhar);
			System.out.println("Patient PanCardNo: "+P.PatPan);
			System.out.println("Patient Is New: "+P.PatisNew);
			
			
		}
}
