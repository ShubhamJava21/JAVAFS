package famMgtSysParameterizedConstructor;

public class Family
{
  int id;
  String Name;
  String Relation;
  int Age;
  long Mobile;
  
  public Family(int Famid, String FamName, String FamRel, int FamAge, long FamMobile)
  {
	id=Famid;
	Name=FamName;
	Relation=FamRel;
	Age=FamAge;
	Mobile=FamMobile;
	
  }
}
