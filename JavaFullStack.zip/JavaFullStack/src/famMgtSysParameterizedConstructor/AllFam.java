package famMgtSysParameterizedConstructor;

public class AllFam 
{
   public Family addFamilyDetails()
   {
	   Family f=new Family(1,"Ashok","Father",50,957634546l);
       return f;
   }
   public Members addAllFamilyDetails()
   {
	   Family f1=new Family(2,"Rekha","Mother",48,98657454l);
	   Family f2=new Family(3,"Dipanshu","Brother",28,98665354l);
	   Family f3=new Family(4,"Pranali","Sister",18,8757454l);
	   Family f4=new Family(5,"kamal","GrandMother",78,98657454l);
	   
	   Members mem=new Members(f1,f2,f3,f4);
	   return mem;
   }
}
