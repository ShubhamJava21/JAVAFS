package famMgtSysParameterizedConstructor;

public class Members 
{
   Family Memb1;
   Family Memb2;
   Family Memb3;
   Family Memb4;
   
   public Members(Family m1, Family m2, Family m3,Family m4)
   {
	   Memb1=m1;
	   Memb2=m2;
	   Memb3=m3;
	   Memb4=m4;
   }
}
