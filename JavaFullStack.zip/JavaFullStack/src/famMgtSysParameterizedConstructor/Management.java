package famMgtSysParameterizedConstructor;

public class Management 
{
  public static void main(String[] args) 
  {
	 AllFam all=new AllFam();
	 Family f=all.addFamilyDetails();
	 System.out.println(f.id+" "+f.Name+" "+f.Relation+" "+f.Age+" "+f.Mobile);
	 Members fm=all.addAllFamilyDetails();
	 System.out.println(fm.Memb1.id+" "+fm.Memb1.Name+" "+fm.Memb1.Relation+" "+fm.Memb1.Age+" "+fm.Memb1.Mobile);
	 System.out.println(fm.Memb2.id+" "+fm.Memb2.Name+" "+fm.Memb2.Relation+" "+fm.Memb2.Age+" "+fm.Memb2.Mobile);
	 System.out.println(fm.Memb3.id+" "+fm.Memb3.Name+" "+fm.Memb3.Relation+" "+fm.Memb3.Age+" "+fm.Memb3.Mobile);
	 System.out.println(fm.Memb4.id+" "+fm.Memb4.Name+" "+fm.Memb4.Relation+" "+fm.Memb4.Age+" "+fm.Memb4.Mobile);
	             
  }
}
