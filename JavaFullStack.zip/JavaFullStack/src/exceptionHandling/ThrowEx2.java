package exceptionHandling;

public class ThrowEx2 
{
 public static void main(String[] args) 
 {
	int marks=89;
	
	if(marks>=70)
	{
		System.out.println("PASS WITH DISTINCTION");
	}
	else if (marks >=60 && marks <=69) 
	{
		System.out.println("PASS WITH FIRST CLASS");
	}
	else if (marks >=50 && marks <=59)
	{
		System.out.println("PASS WITH HIGHER SECOND CLASS");
	}
	else if (marks >=40 && marks <=49)
	{
		System.out.println("PASS WITH SECOND CLASS");
	}
	else if (marks >=35 && marks <=39) 
	{
		System.out.println("PASS WITH PASSED CLASS");
	}
	else if (marks <=35) 
	{
	 System.out.println("FAIL");
	 throw new MarksValidator("FAIL IN EXAM");
	}
 }
}
