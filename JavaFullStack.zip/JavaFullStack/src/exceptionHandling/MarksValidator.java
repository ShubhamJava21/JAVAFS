package exceptionHandling;

public class MarksValidator extends RuntimeException 
{
	MarksValidator(String res)
	{
		super(res);
	}
}
