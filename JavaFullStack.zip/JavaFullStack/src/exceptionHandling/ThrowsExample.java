package exceptionHandling;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ThrowsExample 
{
 public static void m1() throws FileNotFoundException
 {
	FileOutputStream file=new FileOutputStream("Text.txt");
}
 public static void main(String[] args) 
 {
	try {
		m1();
	} catch (Exception e) 
	{
		System.out.println("FileNotFoundException");
	}
}
}
