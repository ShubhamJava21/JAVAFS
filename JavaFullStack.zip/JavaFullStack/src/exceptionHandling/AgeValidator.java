package exceptionHandling;

public class AgeValidator extends RuntimeException
{
 public AgeValidator(String msg) 
 {
	super(msg);
}
}
