package exceptionHandling;

public class StrEndException extends RuntimeException 
{
	StrEndException(String msg)
	{
		super(msg);
	}
}
