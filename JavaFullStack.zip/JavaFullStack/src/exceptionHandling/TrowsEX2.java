package exceptionHandling;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class TrowsEX2 
{
 public static void m1()throws NullPointerException , ArithmeticException, FileNotFoundException
 {
	String s=null;
	System.out.println(s.charAt(1));
	
	int m=100/0;
	System.out.println(m);
	
	FileOutputStream file=new FileOutputStream("TEXt.txt");
    
 }
 public static void main(String[] args) 
 {
	try {
		m1();
	} catch (Exception e) {
		// TODO: handle exception
	}
}
}
