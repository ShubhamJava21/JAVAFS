package exceptionHandling;

public class Practice1 
{
 public static void main(String[] args) 
 {
			  try {
				  String str=new String();
				  str="SHUBHAM";
				  System.out.println(str.charAt(90));
				try {
					int[] a=new int[5];
					System.out.println(a[10]);
					try {
						 int a1=100/0;
						 System.out.println(a1);
					} catch (Exception e) 
					{
					  System.out.println("AirthmeticException");
					}
					
				} catch (ArrayIndexOutOfBoundsException e) 
				{
					System.out.println("ArrayIndexOutOfBoundsException");
				}
			} catch (StringIndexOutOfBoundsException e) 
			  {
				System.out.println("StringIndexOutOfBoundsException");
			}
 }		
	 
}
