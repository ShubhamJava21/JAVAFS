package exceptionHandling;

public class TryCatchEx 
{
 static 
 {
  try {
	
     } catch (Exception e)
    {
	// TODO: handle exception
   }
 }
 {
	 try {
		
	} catch (Exception e)
	 {
		// TODO: handle exception
	}
 }
 TryCatchEx()
 {
	 try {
		
	} catch (Exception e) {
		// TODO: handle exception
	}
 }
 public void m1() 
 {
	 try {
		
	} catch (Exception e) 
	 {
		// TODO: handle exception
	}
	// TODO Auto-generated method stub

}
 public static void main(String[] args) 
 {
	try {
		
	} catch (Exception e) {
		// TODO: handle exception
	}
 }
}
