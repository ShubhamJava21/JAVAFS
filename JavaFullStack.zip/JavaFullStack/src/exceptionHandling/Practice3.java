package exceptionHandling;


public class Practice3 
{
 private void m1()throws NullPointerException 
 {
	String s="null";
	String s1="ABC";
	System.out.println(s.concat(s1));
 }
 private static void m2()
 {
	String str="null";
	System.out.println(str.isBlank());

 }
 private void m3() 
 {
	String[] arr=new String[4];
	System.out.println(arr[40]);
	throw new StrEndException("STR.txt");
}
 public static void main(String[] args) 
 {
	Practice3 p3=new Practice3();
	p3.m1();
	try {
		m2();
	} catch (NullPointerException e) 
	{
		System.out.println("Excep handled");
	}
	p3.m3();
}
}
