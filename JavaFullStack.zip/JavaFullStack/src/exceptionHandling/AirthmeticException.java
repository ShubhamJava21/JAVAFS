package exceptionHandling;

public class AirthmeticException 
{
 public static void main(String[] args) 
 {
	System.out.println("LINE NO:-1");
	System.out.println("LINE NO:-2");
	System.out.println("LINE NO:-3");
	System.out.println("LINE NO:-4");
	System.out.println("LINE NO:-5");
	try
	{
		int a=10/0;
	}
	catch (Exception e) 
	{
		System.out.println("EXCEPTION-HANDLED");	
	}
	System.out.println("LINE NO:-6");
	System.out.println("LINE NO:-7");
	System.out.println("LINE NO:-8");
	System.out.println("LINE NO:-9");
	System.out.println("LINE NO:-10");
 }
}
