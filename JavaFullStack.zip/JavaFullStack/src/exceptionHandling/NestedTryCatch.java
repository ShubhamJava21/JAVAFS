package exceptionHandling;

public class NestedTryCatch 
{
 public static void main(String[] args) 
 {
	 try {
		 try {
			 try {
				String str="name";
				System.out.println(str.charAt(20));
			} catch (ArrayIndexOutOfBoundsException e) 
			 {
				System.out.println("ARRAY INDEX OUT OF BOUND EXCEPTION HANDLED");
			}
			
		} catch (ArithmeticException e) 
		 {
			System.out.println("Arithmetic Exception HANDLED");
		}
		
	} catch (NullPointerException e)
	 {
		System.out.println("NullPointer Exception HANDLED");
	}catch (Exception e) 
	 {
		System.out.println("GENERIC EXCEPTION HANDLED");
	}
}
}
