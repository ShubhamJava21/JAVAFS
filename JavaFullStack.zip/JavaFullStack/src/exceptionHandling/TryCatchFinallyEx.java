package exceptionHandling;

public class TryCatchFinallyEx 
{
 public int result() 
 {
	  try {
		  System.out.println("HELLO!!!!");
		  System.out.println("HII!!!");
		  System.out.println("BYE!!!");
		  return 100;
		
	} catch (Exception e) 
	  {
		return 1000;
	}finally 
	  {
		System.out.println("HELLO!!!!");
		return 1;
	}
 }
 public static void main(String[] args) 
 {
	 TryCatchFinallyEx t=new TryCatchFinallyEx();
	 int result=t.result();
	 System.out.println(result);
}
}
