package exceptionHandling;

public class ThrowEx 
{
 public static void main(String[] args) 
 {
	int age=15;
	
	if(age >=18)
	{
		System.out.println("ELIGIBLE FOR VOTING");
	}
	else {
		throw new AgeValidator("Not Eligible for Voting");
	}
} 
}
