package exceptionHandling;

public class TryWithMultipleCatch 
{
 public static void main(String[] args) 
 {
	try
	{
		int n=10/0;
		System.out.println(n);
	}catch (NullPointerException e) 
	{
		System.out.println("Null Pointer Exception");
	}catch (ArrayIndexOutOfBoundsException e) 
	{
		System.out.println("ArrayIndexOutOfBoundsException");
	}catch (StringIndexOutOfBoundsException e) 
	{
		System.out.println("StringIndexOutOfBoundsException");
	}catch (Exception e) 
	{
		System.out.println("GENERIC EXCEPTION HANDLED");
	}
}
}
