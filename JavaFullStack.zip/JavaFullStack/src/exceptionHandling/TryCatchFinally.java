package exceptionHandling;

public class TryCatchFinally 
{
 public static void main(String[] args)
 {
	//Database Connection
	//db.open();
	 try {
		 String str=null;
		 System.out.println(str.toLowerCase());
		 System.out.println("LINE-1");
		 System.out.println("LINE-2");
		 //db.close();
		 
	} catch (Exception e) 
	 {
		System.out.println("EXCEPTION HANDLED HERE");
	}finally {
		//db.close();
		System.out.println("DATABASE CLOSED");
	}
 }
}
