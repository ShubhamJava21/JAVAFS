package exceptionHandling;

public class Practice2 
{
  private void m1() 
  {
	int q=123/0;
	System.out.println(q);
  }
  public static void m2() 
  {
	Practice2 p2=new Practice2();
	p2.m1();
  }
  public static void main(String[] args) 
  {
	  try {
		  m2();
	} catch (ArithmeticException e) 
	  {
		System.out.println("Exception handled");
	}
	
  }
}
