package exceptionHandling;



public class MultipleException
{
 public static void main(String[] args) 
 {
	String str[]= {null,"abc","xyz",null,null};
	for (int i = 0; i < str.length+1; i++)
	{
	  try {
		  String string=str[i].toLowerCase() +Integer.parseInt(str[i]);
		
	} catch (NullPointerException e) 
	  {
		System.out.println("NULL VALUES PRESENT "+i);
	  }	catch (NumberFormatException e)
	  {
		System.out.println("Number format Exception occurs");
	   }catch (ArrayIndexOutOfBoundsException e) 
	   {
		System.out.println("ArrayIndexOutOfBoundsException");
	  }
	  catch (Exception e) 
	  {
		System.out.println("GENERIC EXCEPTION HANDLED");
	  }
	}
	
}
}
