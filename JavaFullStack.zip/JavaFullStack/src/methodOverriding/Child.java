package methodOverriding;

public class Child extends Parent
{
  @Override
public void m1() 
  {
	System.out.println("Overrided m1 from Parent to child");
  }
  
  public void m3()
  {
	  System.out.println("Child M3 Method");
  }
  public static void main(String[] args) 
  {
	//inheritance
	//3 different types of Object
	  System.out.println("----Parent Class---");
	  Parent p=new Parent();
	  p.m1();
	  p.m2();  //only parent class methods
	  System.out.println("---Parent Child Mix Object_----");
	  Parent p1=new Child();
	  p1.m1();
	  p1.m2();
	  System.out.println("----Child Class----");
	  Child c=new Child();
	  c.m1();
	  c.m2();
	  c.m3();  //Parent+Override methods +Child Methods 
  }
}
