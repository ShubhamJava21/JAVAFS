package methodOverriding;

public class Father extends GranFather 
{
	@Override
	public void Home() 
	{
		System.out.println("2BHK Fully Furnished flat of father");
	}
	
	@Override
	public void money() 
	{
	 System.out.println("50 lacs ");	
	}
	
	public void Car() 
	{
		System.out.println("Car:Creta");
	}

}
