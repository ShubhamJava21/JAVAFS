package methodOverriding;

public class TestSon 
{
  public static void main(String[] args) 
  {
	Son s=new Son();
	s.Home();
	s.money();
	s.Car();
	
	Father f=new Son();
	f.Home();
	f.money();
	f.Car();
	
	GranFather gf=new Father();
	gf.Home();
	gf.money();
  }
}
