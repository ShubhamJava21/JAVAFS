package methodOverriding;

public class Emp 
{
 int id;
 String Name;
 String Add;
 long Mobile;
 
 public int id() 
 {
	 return id=21; 
 }
 public String Name()
 {
	 return Name="Shubham";
 }
 public String Add()
 { 
	 return Add="Pimpri";
 }
 public long Mobile()
 {
	 return Mobile=8378374834l;
 }
 public String toString() 
 {
	return id+" "+Name+" "+Add+" "+Mobile; 
 }
}
