package methodOverriding;

public class Parent 
{
 public void m1()
 {
	 System.out.println("Parent m1 Method");
 }
 public void m2()
 {
	 System.out.println("Parent m2 Method");
 }
}
