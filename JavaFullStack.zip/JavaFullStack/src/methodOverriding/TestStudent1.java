package methodOverriding;

public class TestStudent1
{
  public static void main(String[] args)
  {
	System.out.println("Overrided Method Class");
	Student1 s1=new Student1();
	s1.RollNo();
	s1.Name();
	s1.Mobile();
	s1.Address();
	s1.College();
	System.out.println(s1.RollNo+" "+s1.Name+" "+s1.Mobile+" "+s1.Address+" "+s1.College);
	
	System.out.println("Simple Methods");
	Student s=new Student();
	s.RollNo();
	s.Name();
	s.Address();
	s.Mobile();
	System.out.println(s.RollNo+" "+s.Name+" "+s.Mobile+" "+s.Address);
  }
}
