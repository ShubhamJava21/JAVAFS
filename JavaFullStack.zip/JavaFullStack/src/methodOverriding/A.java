package methodOverriding;

public class A 
{
 public void m1()
 {
	 System.out.println("M1 method from A class");
 }
 public void m2()
 {
	 System.out.println("M2 method from A class");
 }
 public void m3()
 {
	 System.out.println("M3 method from A class");
 }
}
