package methodOverriding;

public class Student 
{
  int RollNo;
  String Name;
  String Address;
  long Mobile;
  
  public int RollNo() 
  {
	  return RollNo=21;
  }
  public String Name()
  {
	  return Name="Shubham";
  }
  public String Address()
  {
	 return Address="Pimpri"; 
  }
  public long Mobile()
  {
	  return Mobile=3837487483l;
  }
}
