package methodOverriding;

public class GranFather
{
  public void Home() 
  {
	System.out.println("Old House Of GrandFather");  
  }
  public void money()
  {
	  System.out.println("30 lacs");
  }

}
