package methodOverriding;

public class TestEmp 
{
  public static void main(String[] args) 
  {
	Emp1 e1=new Emp1();
	e1.id();
	e1.Name(); 
	e1.Add();
	e1.Mobile();
	System.out.println(e1.toString());
	
	Emp e=new Emp();
	e.id();
	e.Name();
	e.Mobile();
	e.Add();
	System.out.println(e.toString());
  }
  
}
