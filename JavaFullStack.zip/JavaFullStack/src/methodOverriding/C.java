package methodOverriding;

public class C extends B 
{
 @Override
public void m2() 
 {
	System.out.println("M2 Overrided Again in Class C");
}
  @Override
	public void m4() 
  {
	 System.out.println("M4 Overrided Again in Class C");	
	}
  public void m6()
  {
	  System.out.println("M6 method of Class c");
  }
}
