package methodOverriding;

public class Student1 extends Student
{
	String College;
  @Override
	public int RollNo() 
    {
		return RollNo=31;
	}
  
   @Override
	public String Name() 
   {
	 return Name="Saurabh";
	}
   
   @Override
	public String Address() 
    {
		return Address="Pune";
	}
   @Override
	public long Mobile() 
   {
		return Mobile=8978648644l;
	}
   public String College()
   {
	   return College="J.S.P.M";
   }
}
