package methodOverriding;

public class Son extends Father
{
   @Override
public void Home() 
   {
	System.out.println("RowHouse 5BHK ");
  }
   
   @Override
	public void money() 
   {
		System.out.println("1 crore");
	}
	
   @Override
	public void Car() 
    {
	  System.out.println("Car:BMW");	
	}
}
