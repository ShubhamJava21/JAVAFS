package methodOverriding;

public class B extends A
{
  @Override
public void m2() 
  {
	System.out.println("M2 Overrided Method Class B");
  }
  
  @Override
	public void m3() 
  {
		System.out.println("M3 overrided Method in Class B");
	}
  public void m4()
  {
	  System.out.println("M4 Method from Class B");
  }
  public void m5()
  {
	  System.out.println("M5 Method from Class B");
  }
  
}
