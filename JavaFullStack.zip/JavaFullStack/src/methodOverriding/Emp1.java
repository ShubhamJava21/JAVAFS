package methodOverriding;

public class Emp1 extends Emp 
{
  @Override
public int id() 
  {
	return id=212;
  }
  @Override
	public String Name() 
   {
		return Name="Saurabh";
	}
  @Override
	public String Add() 
   {
		return Add="Pune";
	}
   @Override
	public long Mobile() 
   {
	 return Mobile=9749748083l;	
	}
   
    public String toString()
    {
    	return id+" "+" "+Name+" "+Add+" "+" "+Mobile;
    }
}
