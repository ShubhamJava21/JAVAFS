package empMgtSysParameterizedConst;

public class Emp 
{
 int id;
 String name;
 String address;
 int Salary;
   public Emp(int Empid, String Empname, String Empaddress, int EmpSalary)
   {
	 id=Empid;
	 name=Empname;
	 address=Empaddress;
	 Salary=EmpSalary;
   }
}
