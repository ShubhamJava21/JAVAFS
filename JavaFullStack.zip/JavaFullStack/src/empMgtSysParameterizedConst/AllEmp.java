package empMgtSysParameterizedConst;

public class AllEmp 
{
  Emp em1;
  Emp em2;
  Emp em3;
  Emp em4;
  
  public AllEmp(Emp emp1, Emp emp2 ,Emp emp3, Emp emp4)
  {
	  em1=emp1;
	  em2=emp2;
	  em3=emp3;
	  em4=emp4;
  }
}
