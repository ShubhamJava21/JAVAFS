package empMgtSysParameterizedConst;

public class Management 
{
 public static void main(String[] args) 
 {
	 Compony c=new Compony();
	 AllEmp em1=c.addEmpDetails();
	 System.out.println(em1.em1.id+" "+em1.em1.name+" "+em1.em1.address+" "+em1.em1.Salary);
	 System.out.println(em1.em2.id+" "+em1.em2.name+" "+em1.em2.address+" "+em1.em2.Salary);
	 System.out.println(em1.em3.id+" "+em1.em3.name+" "+em1.em3.address+" "+em1.em3.Salary);
	 System.out.println(em1.em4.id+" "+em1.em4.name+" "+em1.em4.address+" "+em1.em4.Salary);
	 
 }
}
