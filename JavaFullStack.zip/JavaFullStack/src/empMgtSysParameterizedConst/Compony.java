package empMgtSysParameterizedConst;

public class Compony 
{
   public AllEmp addEmpDetails()
   {
	   Emp e1=new Emp(101,"Shubham","Pimpri",128363);
	   Emp e2=new Emp(102,"Swapnil","Pune",16474);
	   Emp e3=new Emp(103,"Saurabh","Pimpri",17637);
	   Emp e4=new Emp(104,"Satyajeet","Pune",16574);
	   
	   AllEmp all=new AllEmp(e1, e2,e3,e4);
	   return all;
   }
}
