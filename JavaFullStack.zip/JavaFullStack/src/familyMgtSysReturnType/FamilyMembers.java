package familyMgtSysReturnType;

public class FamilyMembers 
{
  Family Father=new Family();
  Family Mother=new Family();
  Family Brother=new Family();
  Family Sister=new Family();
}
