package familyMgtSysReturnType;

public class FamilyBook 
{
  public static void main(String[] args) 
  {
	AllFamily af=new AllFamily();
	FamilyMembers all=af.AddFamilyDetails();
	System.out.println("*******Family 1st Member*******");
	System.out.println(all.Father.MemberId+" "+all.Father.MemberName+" "+all.Father.MemberRelation+" "+all.Father.MemberMobile+" "+all.Father.MemberBday);
	System.out.println("*******Family 2nd Member*******");
	System.out.println(all.Mother.MemberId+" "+all.Mother.MemberName+" "+all.Mother.MemberRelation+" "+all.Mother.MemberMobile+" "+all.Mother.MemberBday);
	System.out.println("*******Family 3rd Member*******");
	System.out.println(all.Brother.MemberId+" "+all.Brother.MemberName+" "+all.Brother.MemberRelation+" "+all.Brother.MemberMobile+" "+all.Brother.MemberBday);
	System.out.println("*******Family 4th Member*******");
	System.out.println(all.Sister.MemberId+" "+all.Sister.MemberName+" "+all.Sister.MemberRelation+" "+all.Sister.MemberMobile+" "+all.Sister.MemberBday);
  
  }
}
