package familyMgtSysReturnType;

public class Family 
{
  int MemberId;
  String MemberName;
  String MemberRelation;
  long MemberMobile;
  String MemberBday;
  
}
