package familyMgtSysReturnType;

public class AllFamily 
{
  public FamilyMembers AddFamilyDetails()
  {
	  FamilyMembers Fm=new FamilyMembers();
	  Fm.Father.MemberId=01;
	  Fm.Father.MemberName="Ashok";
	  Fm.Father.MemberRelation="Father";
	  Fm.Father.MemberMobile=123456789l;
	  Fm.Father.MemberBday="22Oct1972";
	  
	  Fm.Mother.MemberId=02;
	  Fm.Mother.MemberName="Rekha";
	  Fm.Mother.MemberRelation="Mother";
	  Fm.Mother.MemberMobile=256343624624l;
	  Fm.Mother.MemberBday="19June1973";
	  
	  Fm.Brother.MemberId=03;
	  Fm.Brother.MemberName="Dipanshu";
	  Fm.Brother.MemberRelation="Brother";
	  Fm.Brother.MemberMobile=165425243873l;
	  Fm.Brother.MemberBday="18Feb2000";
	  
	  Fm.Sister.MemberId=04;
	  Fm.Sister.MemberName="Pranali";
	  Fm.Sister.MemberRelation="Sister";
	  Fm.Sister.MemberMobile=13232424242l;
	  Fm.Sister.MemberBday="25Dec2002";
	  
	  return Fm;
	  
  }
}
