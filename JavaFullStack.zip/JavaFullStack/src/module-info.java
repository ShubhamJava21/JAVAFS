/**
 * 
 */
/**
 * 
 */
module JavaFullStack {
}