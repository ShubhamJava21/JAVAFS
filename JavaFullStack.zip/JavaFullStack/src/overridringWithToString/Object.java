package overridringWithToString;

public class Object extends Product
{
  public static void main(String[] args) 
  {
	Product p=new Product();
	p.pid=21;
	p.pname="Shubham";
	p.price=89800.90;
	System.out.println(p.toString());
	
	Product p1=new Product();
	p1.pid=12;
	p1.pname="Akash";
	p1.price=894.90;
	System.out.println(p1);
	
  }
}
