package overridringWithToString;

public class Product 
{
	 int pid;
	 String pname;
	 double price;
	 
	 @Override
	public String toString() 
	 {
		return pid+" "+pname+" "+price;
	}

}
