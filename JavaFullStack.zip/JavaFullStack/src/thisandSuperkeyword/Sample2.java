package thisandSuperkeyword;

public class Sample2 extends Sample1
{
   int x=500;
   int y=1000;
   
	public void m1() 
	{
		System.out.println("M1 method from Child Class");
	}
	public void m2() 
	{
	  System.out.println(super.x+" "+super.y);
	  super.m1();
	  System.out.println("M2 method from child class");
	  this.m1();
	}
	
	public static void main(String[] args)
	{
		 Sample2 s2=new Sample2();
		 System.out.println(s2.x);
		 System.out.println(s2.y);
		 s2.m2();
		 s2.m1();	 
		 
	}
			
}
