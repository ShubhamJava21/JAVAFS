package thisandSuperkeyword;

public class Sample1 
{
 int x=10;
 int y=30;
 
 public void m1()
 {
	System.out.println("Parent Class Method");
 }
}
