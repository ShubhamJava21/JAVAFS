package onlineShoppingSystem;

public class Groceries extends Product
{
 @Override
void displayDetails()
 {
	 System.out.println("Groceries Product Details: Rice");
	
 }
 @Override
	void calculateShippingCost()
 {
	 System.out.println("Clothing Shipping Cost: $35");
	}
}
