package onlineShoppingSystem;

public class Electronics extends Product
{
  @Override
void displayDetails()
  {
    System.out.println("Electronics Product Details:Washing Machine");
 }
  @Override
	void calculateShippingCost() 
  {
	  System.out.println("Washing Machine Shipping Cost: $15");
	}
}
