package onlineShoppingSystem;

public class Clothing extends Product
{
  @Override
void displayDetails() 
  {
	  System.out.println("Clothing Product Details : T-Shirt");
 }
  @Override
	void calculateShippingCost()
  {
	  System.out.println("T-Shirt Shipping Cost: $25");
		
	}
}
