package onlineShoppingSystem;

public class Admin 
{
 public static void main(String[] args) 
 {
	 System.out.println("----Product Details----");
	 Product p4=new Product();
	 p4.displayDetails();
	 p4.calculateShippingCost();
	 System.out.println("----Electronics & Product Details----");
	 Product p=new Electronics();
	 p.displayDetails();
	 p.calculateShippingCost();
	 System.out.println("----Clothing & Product Details---");
	 Product p1=new Clothing();
	 p1.displayDetails();
	 p1.calculateShippingCost();
	 System.out.println("---Groceries & Product Details---");
	 Product p2=new Groceries();
	 p2.displayDetails();
	 p2.calculateShippingCost();
	 	 
}
}
