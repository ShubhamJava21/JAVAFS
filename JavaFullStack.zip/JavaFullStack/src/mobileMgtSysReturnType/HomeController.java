package mobileMgtSysReturnType;

public class HomeController 
{
  public static void main(String[] args) 
  {
	MobileShopee Ms=new MobileShopee();
	AllMobile all=Ms.getMobileDetails();
	System.out.println("***Mobile Details***");
	System.out.println(all.Iphone.MobCompony+" "+all.Iphone.MobPrice+" "+all.Iphone.MobDis);
	System.out.println(all.Samsung.MobCompony+" "+all.Samsung.MobPrice+" "+all.Samsung.MobDis);
	System.out.println(all.Oppo.MobCompony+" "+all.Oppo.MobPrice+" "+all.Oppo.MobDis);
	    
  }
}
