package mobileMgtSysReturnType;

public class AllMobile 
{
  Mobile Iphone=new Mobile();
  Mobile Samsung=new Mobile();
  Mobile Oppo=new Mobile();
  
}
