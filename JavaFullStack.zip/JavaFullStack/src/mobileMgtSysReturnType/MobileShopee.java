package mobileMgtSysReturnType;

public class MobileShopee 
{
  public AllMobile getMobileDetails(){
	  {
 
   AllMobile all=new AllMobile();
   all.Iphone.MobCompony="Iphone";
   all.Iphone.MobPrice=150000;
   all.Iphone.MobDis=25.90f;
   
   all.Samsung.MobCompony="Samsung";
   all.Samsung.MobPrice=70000;
   all.Samsung.MobDis=20.90f;
   
   all.Oppo.MobCompony="Oppo";
   all.Oppo.MobPrice=50000;
   all.Oppo.MobDis=40.90f;
   
   return all;
   
	  } 
}
}