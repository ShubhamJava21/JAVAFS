package mobileMgtSysReturnType;

public class Mobile 
{
  String MobCompony;
  int MobPrice;
  float MobDis;
}
