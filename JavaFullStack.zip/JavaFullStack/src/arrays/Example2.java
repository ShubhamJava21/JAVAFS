package arrays;

public class Example2 
{
 public static void main(String[] args)
 {
	double[] arrayOfDouble= {123.54,342.54,343.4};
	System.out.println(arrayOfDouble.length);
	
	double d=arrayOfDouble[2];
	System.out.println(d);
 }
}
