package arrays;

public class ProductDetails 
{
   public Order[] addOrder()
   {
	Order ord=new Order();
	ord.setOid(101);
	ord.setOname("ABC");
	ord.setOdate("12Jan");
	Order ord1=new Order();
	ord1.setOid(102);
	ord1.setOname("XYZ");
	ord1.setOdate("13Jan");
	Order ord2=new Order();
	ord2.setOid(103);
	ord2.setOname("PQR");
	ord2.setOdate("14Jan");
	
	Order[] arrayofOrder= {ord,ord1,ord2};
	return arrayofOrder;
   }
   public Product[] addProduct()
   {
	Product prd=new Product();
	prd.setPid(231);
	prd.setPname("Iphone");
	prd.setPrice(12345);
	Product prd1=new Product();
	prd1.setPid(241);
	prd1.setPname("SAMSUNG");
	prd1.setPrice(56345);
	Product prd2=new Product();
	prd2.setPid(251);
	prd2.setPname("VIVO");
	prd2.setPrice(1345);
	
	Product[] arrayofProduct = {prd,prd1,prd2};
	return arrayofProduct;   
   }
   public Customer[] addCustomer() 
   {
	   Customer cst=new Customer();
		cst.setName("Shubham");
		cst.setEmail("adsgfsjhjd");
		cst.setContact(974589658);
		Customer cst1=new Customer();
		cst1.setName("Saurabh");
		cst1.setEmail("gfugfjbcfjhf");
		cst1.setContact(95076897);
		Customer cst2=new Customer();
		cst2.setName("Swapnil");
		cst2.setEmail("eughdfhjgdfjhcf");
		cst2.setContact(876484674);
		
		Customer[] arrayofCustomer = {cst,cst2,cst1};
		return arrayofCustomer;  
   }
}
