package arrays;

public class Prodct 
{
 int pid;
 String pname;
 double price;
public Prodct(int pid, String pname, double price) 
{
	super();
	this.pid = pid;
	this.pname = pname;
	this.price = price;
}

 public Prodct[] addProductDetails()
 {
	 Prodct prodct = new Prodct(101,"ABC",23.87);
	 Prodct prodct1 = new Prodct(102,"BC",43.87);
	 Prodct prodct2 = new Prodct(103,"AC",21.87);
	 Prodct prodct3 = new Prodct(104,"AB",53.87);
	 
	 Prodct[] arrayOfProduct= {prodct,prodct1,prodct2,prodct3};
	 return arrayOfProduct;
	 
	 
 }
}
