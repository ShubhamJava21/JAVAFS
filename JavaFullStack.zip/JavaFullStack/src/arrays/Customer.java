package arrays;

public class Customer 
{
 private int contact;
 private String email;
 private String name;
public int getContact() {
	return contact;
}
public void setContact(int contact) {
	this.contact = contact;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
