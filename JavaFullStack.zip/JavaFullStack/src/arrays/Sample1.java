package arrays;

public class Sample1 
{
  public static void main(String[] args) 
  {
	int[] arr=new int[5];
	arr[0]=123;
	arr[1]=432;
	arr[2]=234;
	arr[3]=908;
	arr[4]=232;
	System.out.println(arr.length);
	
	String[] arr1= {"Shubham","Swapnil","Saurabh","Akash"};
	String array=arr1[2];
	System.out.println(array);
	
  }
}
