package arrays;

public class OnlineShopping 
{
  public static void main(String[] args)
  {
	ProductDetails pd=new ProductDetails();
	System.out.println("---Order Details----");
	Order[] arrayOrder=pd.addOrder();
	Order ord=arrayOrder[2];
	System.out.println(ord.getOid()+" "+ord.getOname()+" "+ord.getOdate());
	System.out.println("---Product Details----");
	Product[] arrayProduct=pd.addProduct();
	Product ptr=arrayProduct[2];
	System.out.println(ptr.getPid()+" "+ptr.getPname()+" "+ptr.getPrice());
	System.out.println("---Customer Details----");
	Customer[] arrayCustomer=pd.addCustomer();
	Customer ctr=arrayCustomer[2];
	System.out.println(ctr.getName()+" "+ctr.getEmail()+" "+ctr.getContact());
	
 }
}