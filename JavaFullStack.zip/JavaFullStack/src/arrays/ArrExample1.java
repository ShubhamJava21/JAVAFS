package arrays;

public class ArrExample1 
{
 public static void main(String[] args) 
 {
	int[] arrayOfInt=new int[5];
	
	arrayOfInt[0]=10;
	arrayOfInt[1]=20;
	arrayOfInt[2]=30;
	arrayOfInt[3]=40;
	arrayOfInt[4]=50;
	
	System.out.println(arrayOfInt.length);
	
	boolean[] arrayOfBoolean=new boolean[3];
	arrayOfBoolean[1]=true;
	System.out.println(arrayOfBoolean[1]);
	
  }
}
