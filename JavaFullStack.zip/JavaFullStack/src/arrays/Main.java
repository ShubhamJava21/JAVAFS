package arrays;

public class Main 
{
 public static void main(String[] args) 
 {
	Prodct prodct=new Prodct(0,null,0.0);
	
	Prodct[] arrayProdct=prodct.addProductDetails();
	
	Prodct ptr=arrayProdct[0];
	System.out.println(ptr.pid+" "+ptr.pname+" "+ptr.price);
	
}
}
