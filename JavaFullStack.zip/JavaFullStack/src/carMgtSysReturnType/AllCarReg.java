package carMgtSysReturnType;

public class AllCarReg 
{
  Car BMW=new Car();
  Car RangeRover=new Car();
  Car Fortuner=new Car();
  Car Mercedes=new Car();
  Car RollsRoyce=new Car();
}
