package carMgtSysReturnType;

public class Car 
{
  int carid;
  String Carname;
  int CarCap;
  int CarPrice;
  String CarMo;
}
