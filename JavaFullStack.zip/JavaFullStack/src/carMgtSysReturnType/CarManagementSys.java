package carMgtSysReturnType;

public class CarManagementSys 
{
 public static void main(String[] args)
 {
	AllCars ac=new AllCars();
	AllCarReg all=ac.AddCarDetails();
	System.out.println("******BMW Car******");
	System.out.println("BMW Quatation: \n"+"1)ChacieNo: "+all.BMW.carid+"  \n"+"2)Car: "+all.BMW.Carname+"  \n"+"3)Model No: "+all.BMW.CarMo+"  \n"+"4)Seating Capacity: "+all.BMW.CarCap+"  \n"+"5)Car On road Price: "+all.BMW.CarPrice);
	System.out.println("******RangeRover Car******");
	System.out.println("RangeRover Quatation: \n"+"1)ChacieNo: "+all.RangeRover.carid+"  \n"+"2)Car: "+all.RangeRover.Carname+"  \n"+"3)Model No: "+all.RangeRover.CarMo+"  \n"+"4)Seating Capacity: "+all.RangeRover.CarCap+"  \n"+"5)Car On road Price: "+all.RangeRover.CarPrice);
	System.out.println("******Fortuner Car******");
	System.out.println("Fortuner Quatation: \n"+"1)ChacieNo: "+all.Fortuner.carid+"  \n"+"2)Car: "+all.Fortuner.Carname+"  \n"+"3)Model No: "+all.Fortuner.CarMo+"  \n"+"4)Seating Capacity: "+all.Fortuner.CarCap+"  \n"+"5)Car On road Price: "+all.Fortuner.CarPrice);
	System.out.println("******Mercedes Car******");
	System.out.println("Mercedes Quatation: \n"+"1)ChacieNo: "+all.Mercedes.carid+"  \n"+"2)Car: "+all.Mercedes.Carname+"  \n"+"3)Model No: "+all.Mercedes.CarMo+"  \n"+"4)Seating Capacity: "+all.Mercedes.CarCap+"  \n"+"5)Car On road Price: "+all.Mercedes.CarPrice);
	System.out.println("******Mercedes Car******");
	System.out.println("Mercedes Quatation: \n"+"1)ChacieNo: "+all.Mercedes.carid+"  \n"+"2)Car: "+all.Mercedes.Carname+"  \n"+"3)Model No: "+all.Mercedes.CarMo+"  \n"+"4)Seating Capacity: "+all.Mercedes.CarCap+"  \n"+"5)Car On road Price: "+all.Mercedes.CarPrice);
	System.out.println("******RollsRoyce Car******");
	System.out.println("RollsRoyce Quatation: \n"+"1)ChacieNo: "+all.RollsRoyce.carid+"  \n"+"2)Car: "+all.RollsRoyce.Carname+"  \n"+"3)Model No: "+all.RollsRoyce.CarMo+"  \n"+"4)Seating Capacity: "+all.RollsRoyce.CarCap+"  \n"+"5)Car On road Price: "+all.RollsRoyce.CarPrice);
	
	
 }
}
