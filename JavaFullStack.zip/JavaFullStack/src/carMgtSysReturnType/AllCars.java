package carMgtSysReturnType;

public class AllCars 
{
  public AllCarReg AddCarDetails()
  {
	  AllCarReg c=new AllCarReg();
	  c.BMW.carid=456;
	  c.BMW.Carname="BMW";
	  c.BMW.CarCap=7;
	  c.BMW.CarMo="XM";
      c.BMW.CarPrice=50000000;
      
      c.Fortuner.carid=342;
	  c.Fortuner.Carname="Fortuner";
	  c.Fortuner.CarCap=7;
	  c.Fortuner.CarMo="GR-S";
      c.Fortuner.CarPrice=5500000;
      
      c.Mercedes.carid=654;
	  c.Mercedes.Carname="Mercedes";
	  c.Mercedes.CarCap=7;
	  c.Mercedes.CarMo="Maybach";
      c.Mercedes.CarPrice=55000000;
      
      c.RangeRover.carid=453;
	  c.RangeRover.Carname="RangeRover";
	  c.RangeRover.CarCap=7;
	  c.RangeRover.CarMo="SV";
      c.RangeRover.CarPrice=498000000;
      
      c.RollsRoyce.carid=674;
	  c.RollsRoyce.Carname="RollsRoyce";
	  c.RollsRoyce.CarCap=7;
	  c.RollsRoyce.CarMo="Phantom";
      c.RollsRoyce.CarPrice=69800000;
      
      return c;
     
  }
}
