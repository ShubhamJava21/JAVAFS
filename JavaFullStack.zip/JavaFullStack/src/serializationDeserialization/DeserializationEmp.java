package serializationDeserialization;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializationEmp 
{
 public static void main(String[] args) throws IOException, ClassNotFoundException 
 {
	FileInputStream File=new FileInputStream("EmployeeDetails.txt");
	ObjectInputStream obj=new ObjectInputStream(File);
	Employee emp=(Employee) obj.readObject(); 
	System.out.println(emp);
 }
}
