package serializationDeserialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationEmp 
{
 public static void main(String[] args) throws IOException 
 {
	Employee emp=new Employee();
	emp.setEid(101);
	emp.setEname("SHUBHAM");
	emp.setEaddress("PIMPRI");
	emp.seteDesignation("JAVA DEVELOPER");
	emp.seteAcno("1202");
	emp.setEpassword("ABC@123");
	
	FileOutputStream File=new FileOutputStream("EmployeeDetails.txt");
	ObjectOutputStream obj=new ObjectOutputStream(File);
	obj.writeObject(emp);
	System.out.println("Object Serialized");
 }
}
