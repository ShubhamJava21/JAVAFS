package studentMgtSysReturnType;

public class AllStd 
{
  Student Satya=new Student(); 
  Student Vivek=new Student();
  Student Rohan=new Student();
}
