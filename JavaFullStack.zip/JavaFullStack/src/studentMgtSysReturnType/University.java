package studentMgtSysReturnType;

public class University 
{
  public static void main(String[] args) 
  {
	College cl=new College();
	Student a=cl.addStudDetails();
	System.out.println(a.id+" "+a.name+" "+a.Address+" "+a.div);
	
	AllStd a1=cl.addAllStdDetails();
	System.out.println(a1.Satya.id+" "+a1.Satya.name+" "+a1.Satya.Address+" "+a1.Satya.div);
	System.out.println(a1.Rohan.id+" "+a1.Rohan.name+" "+a1.Rohan.Address+" "+a1.Rohan.div);
	System.out.println(a1.Vivek.id+" "+a1.Vivek.name+" "+a1.Vivek.Address+" "+a1.Vivek.div);
	    
  }
}
