package studentMgtSysReturnType;

public class College 
{
  public Student addStudDetails()
  {
   Student Std=new Student();
   Std.id=11;
   Std.name="Shubham";
   Std.Address="Pimpri";
   Std.div='a';
   return Std;
}  
  public AllStd addAllStdDetails()
  {
  AllStd all=new AllStd();
  all.Satya.id=12;
  all.Satya.name="Sattya";
  all.Satya.Address="Pune";
  all.Satya.div='A';
  
  all.Vivek.id=13;
  all.Vivek.name="Vivek";
  all.Vivek.Address="Pune";
  all.Vivek.div='B';
  
  all.Rohan.id=14;
  all.Rohan.name="Rohan";
  all.Rohan.Address="Pimpri";
  all.Rohan.div='A';
  
  return all;
  
} 
  
}
