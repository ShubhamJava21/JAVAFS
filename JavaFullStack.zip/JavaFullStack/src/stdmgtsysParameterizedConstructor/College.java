package stdmgtsysParameterizedConstructor;

public class College 
{
   public Student addStudentDetails()
   {
	   Student s=new Student(101,"Shubham","Pimpri",'A');
	   return s;
   }
   public AllStd addAllStudentDetails()
   {  
	   Student s1=new Student(102,"Saurabh","Pimpri",'A');
	   Student s2=new Student(103,"Swapnil","Pimpri",'A');
	   Student s3=new Student(104,"Rohan","Pimpri",'B');
	   AllStd all=new AllStd(s1,s2,s3);
	   return all;
   }
}
