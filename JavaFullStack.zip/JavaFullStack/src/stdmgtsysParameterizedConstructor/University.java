package stdmgtsysParameterizedConstructor;


public class University 
{
	public static void main(String[] args) 
	  {
		 College cl=new College();
		 Student st=cl.addStudentDetails();
		 System.out.println(st.id+" "+st.name+" "+st.Address+" "+st.div);
		 
		 AllStd st1=cl.addAllStudentDetails();
		System.out.println(st1.stud1.id+" "+st1.stud1.name+" "+st1.stud1.div+" "+st1.stud1.Address);
		System.out.println(st1.stud2.id+" "+st1.stud2.name+" "+st1.stud2.div+" "+st1.stud2.Address);
		System.out.println(st1.stud3.id+" "+st1.stud3.name+" "+st1.stud3.div+" "+st1.stud3.Address);
		    
	  }
	}


