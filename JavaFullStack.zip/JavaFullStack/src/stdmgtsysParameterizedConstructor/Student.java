package stdmgtsysParameterizedConstructor;

public class Student
{ 
	int id;
    String name;
    String Address;
    char div;
	public Student(int Stdid, String Stdname, String StdAddress, char Stddiv)
	  {
		  id=Stdid;
		  name=Stdname;
		  Address=StdAddress;
		  div=Stddiv;	  
	  }
	
}
