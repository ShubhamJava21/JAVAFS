package stdmgtsysParameterizedConstructor;

public class AllStd 
{
	  Student stud1;
	  Student stud2;
	  Student stud3;
	  public AllStd(Student s1,Student s2,Student s3)
	  {
		stud1=s1;
		stud2=s2;
		stud3=s3;		
	  }
}