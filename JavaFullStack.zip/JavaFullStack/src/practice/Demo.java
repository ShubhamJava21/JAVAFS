package practice;

public class Demo 
{
 static int i=1000;
 
 static 
 {
	System.out.println(i); 
 }
 public static void m1(int i)
 {
	System.out.println(i);
 }
  void m1(float f)
  {
	 Demo d1=new Demo();
	 d1.i=1000;
	 System.out.println(d1.i);
  }
}
