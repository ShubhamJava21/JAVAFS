package practice;

public class Test extends Demo
{
 public static void main(String[] args) 
 {
	Test t=new Test();
	t.m1(10);
	Demo d1=new Test();
	System.out.println(d1.i);
	System.out.println(i);
	Demo d2=new Demo();
	System.out.println(d2.i);
 }
}
