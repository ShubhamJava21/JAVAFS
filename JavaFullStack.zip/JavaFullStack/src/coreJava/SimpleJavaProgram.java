package coreJava;

public class SimpleJavaProgram 
{
  public static void main(String[] args) 
  {
	System.out.println("First Java Program");
  }
}
