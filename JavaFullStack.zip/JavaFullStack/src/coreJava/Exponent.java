package coreJava;

public class Exponent
{
	 public static void main(String[] args)
	{
	 System.out.println("Its New Beginning With Exponent Keep Faith on Nilesh Sir Now you are at right place");
	}
}
