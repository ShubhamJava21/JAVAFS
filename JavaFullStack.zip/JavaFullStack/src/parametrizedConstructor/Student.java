package parametrizedConstructor;

public class Student 
{
 int id;
 String name;
 String address;
 long contact;
 double per;
 char grade;
 
 public Student(int Stdid , String Stdname, String Stdaddress, long Stdcontact, double Stdper, char Stdchar)
 {
	 id=Stdid;
	 name=Stdname;
	 address=Stdaddress;
	 contact=Stdcontact;
	 per=Stdchar;
	 grade=Stdchar;
 }
 public static void main(String[] args)
 {
	 Student s=new Student(10,"Shubham","Pimpri",983736376l,99.90d,'A');
	 System.out.println("Student Information: "+s.id+" "+s.name+" "+s.address+" "+s.contact+" "+s.per+" "+s.grade);
 }
}
