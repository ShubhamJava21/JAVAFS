package parametrizedConstructor;

public class Emp 
{
   int id;
   String name;
   String Address;
   String Designation;
   int Salary;

   public Emp(int Empid,String Empname,String EmpAdd,String EmpDes,int EmpSal)
   {
	 id=Empid;
	 name=Empname;
	 Address=EmpAdd;
	 Designation=EmpDes;
	 Salary=EmpSal;
   }
   
   public static void main(String[] args) 
   {
	 Emp e=new Emp(101,"Shubham","Pimpri","Software Dev",2100000);
	 System.out.println(e.id+" "+e.name+" "+e.Address+" "+e.Designation+" "+e.Salary);
	 Emp e1=new Emp(102,"Saurabh","PSaud","Software Dev",1000000);
	 System.out.println(e1.id+" "+e1.name+" "+e1.Address+" "+e1.Designation+" "+e1.Salary);
   
   }
}
