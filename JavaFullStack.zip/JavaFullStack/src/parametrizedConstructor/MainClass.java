package parametrizedConstructor;

public class MainClass
{
 public static void main(String[] args)
 {
	Student s=new Student(101, "Shubham", "pune" , 8946746455l, 78.98,'A');
	System.out.println(s.id+" "+s.name+" "+s.address+" "+s.contact+" "+s.per+" "+s.grade);
	Student s1=new Student(102, "Saurabh", "pune" , 787846455l, 88.98,'A');
	System.out.println(s1.id+" "+s1.name+" "+s1.address+" "+s1.contact+" "+s1.per+" "+s1.grade);
 
 }
}
