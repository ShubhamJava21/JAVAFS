package parametrizedConstructor;

public class Logic
{
  public Logic()
  {
	  System.out.println("Default Constructor Called");
  }
  public Logic(int i)
  {
	  System.out.println("Single Param Constructor Called");
  }
  public Logic(int i,String s)
  {
	  System.out.println("Double Param Constructor Called");
  }
  public Logic(int i,String s,boolean b,char c, long l)
  {
	  System.out.println("Five Param Constructor Called");
  }
  public static void main(String[] args) 
  {
	Logic logic=new Logic();
	Logic logic1=new Logic(10);
	Logic logic2=new Logic(10,"Shubham");
	Logic logic3=new Logic(10,"Shubham",true,'A',12345836l);
	
	
  }
}
