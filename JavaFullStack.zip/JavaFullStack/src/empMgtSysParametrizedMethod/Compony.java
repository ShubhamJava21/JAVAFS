package empMgtSysParametrizedMethod;

public class Compony 
{
	
	public void displayEmpDetails(Employee e) 
	{
		System.out.println(e.id+" "+e.name+" "+e.salary);
	}
	
	public void displayAllEmpDetails(AllEmp ae) 
	{
		System.out.println(ae.Swapnil.id+" "+ae.Swapnil.name+" "+ae.Swapnil.salary);
		System.out.println(ae.Saurabh.id+" "+ae.Saurabh.name+" "+ae.Saurabh.salary);
		System.out.println(ae.Suraj.id+" "+ae.Suraj.name+" "+ae.Suraj.salary);
	}
	public static void main(String[] args) 
	{

		  Department dep=new Department();
		  dep.addEmployeeDetails();
		  dep.addAllEmployeeDetails();
		}
}
