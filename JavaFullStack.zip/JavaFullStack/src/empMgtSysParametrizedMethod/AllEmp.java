package empMgtSysParametrizedMethod;


public class AllEmp 
{
	Employee Swapnil=new Employee();
	Employee Saurabh=new Employee();
	Employee Suraj=new Employee();
}
