package empMgtSysParametrizedMethod;

public class Department 
{
	public void addEmployeeDetails()
	 {
		 Employee e=new Employee();
		 e.id=11;
		 e.name="Shubham";
		 e.salary=200000;
		 
		 Compony c=new Compony();
		c.displayEmpDetails(e);
	 }
	  public void addAllEmployeeDetails()
	  {
		  AllEmp all=new AllEmp();
		  all.Swapnil.id=12;
		  all.Swapnil.name="Swapnil";
		  all.Swapnil.salary=150000;
		  
		  all.Saurabh.id=13;
		  all.Saurabh.name="Saurabh";
		  all.Saurabh.salary=250000;
		  
		  all.Suraj.id=14;
		  all.Suraj.name="Suraj";
		  all.Suraj.salary=150000;
	
         Compony c=new Compony();
         c.displayAllEmpDetails(all);
	  }
}
