package empMgtSysParametrizedMethod;

public class Employee 
{
	 int id;
	 String name;
	 int salary;
}
