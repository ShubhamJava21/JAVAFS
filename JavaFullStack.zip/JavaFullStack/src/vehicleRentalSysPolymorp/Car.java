package vehicleRentalSysPolymorp;

public class Car extends Vehicle
{
  @Override
public void calculateRentalPrice(float f) 
  {
	System.out.println("Car Rental Price is 800 rs per hour");
  }
}
