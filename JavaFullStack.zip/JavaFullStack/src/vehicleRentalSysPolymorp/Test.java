package vehicleRentalSysPolymorp;

public class Test 
{
 public static void main(String[] args) 
 {
	Vehicle v=new Vehicle();
	v.BookVehicle(1);
	v.BookVehicle(1, 24);
	v.BookVehicle("Pune");
	
	Vehicle v1=new Car();
	v1.BookVehicle(2);
	v1.BookVehicle(2, 48);
	v1.BookVehicle("Pimpri");
	
	Vehicle v2=new Bike();
	v2.BookVehicle(3);
	v2.BookVehicle(3, 72);
	v2.BookVehicle("Chinchwad");
	
	System.out.println(v);
  }
}
