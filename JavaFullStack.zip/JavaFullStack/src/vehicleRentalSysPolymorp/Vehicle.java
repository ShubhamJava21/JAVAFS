package vehicleRentalSysPolymorp;

public class Vehicle 
{
 public void BookVehicle(int i)
 {
	System.out.println("BookVehicleBy Days: ");
  }
  public void BookVehicle(int i, int h)
 {
	System.out.println("BookVehicleBy Days*hours: ");
	
  }
  public void BookVehicle(String s)
  {
 	System.out.println("BookVehicleBy Location: ");
   }
  
  public void calculateRentalPrice(float f) 
   {
	System.out.println("Rental Price rs per hour");

   }
  
}
