package vehicleRentalSysPolymorp;

public class Bike extends Vehicle 
{
 @Override
public void calculateRentalPrice(float f) 
 {
	System.out.println("Bike Rental Price is 100 rs per hours");
}
}
