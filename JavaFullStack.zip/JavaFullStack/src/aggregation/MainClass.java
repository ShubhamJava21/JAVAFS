package aggregation;

public class MainClass 
{
  public static void main(String[] args) 
  {
	Address address=new Address();
	address.setLadr("PUNE");
	address.setPadr("MUMBAI");
	address.setPincode("411017");
	
	Stdent std=new Stdent();
	std.setSid(21);
	std.setName("Santosh");
	std.setAddress(address);
	
	Stdent std1=new Stdent();
	std1.setSid(31);
	std1.setName("Ajay");
	std1.setAddress(address);
	
	Stdent std2=new Stdent();
	std2.setSid(41);
	std2.setName("Atul");
	std2.setAddress(address);
	
	System.out.println(std.getSid()+" "+std.getName()+" "+std.getAddress().getLadr()+" "+std.getAddress().getPadr()+" "+std.getAddress().getPincode());
	System.out.println(std1.getSid()+" "+std1.getName()+" "+std1.getAddress().getLadr()+" "+std1.getAddress().getPadr()+" "+std1.getAddress().getPincode());
	System.out.println(std2.getSid()+" "+std2.getName()+" "+std2.getAddress().getLadr()+" "+std2.getAddress().getPadr()+" "+std2.getAddress().getPincode());
	    
  }
}
