package aggregation;

public class Father 
{
  int fid;
  String fname;
  String frel;
  long fmob;
  Family fam;
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getFrel() {
	return frel;
}
public void setFrel(String frel) {
	this.frel = frel;
}
public long getFmob() {
	return fmob;
}
public void setFmob(long fmob) {
	this.fmob = fmob;
}
public Family getFam() {
	return fam;
}
public void setFam(Family fam) {
	this.fam = fam;
}
  
}
