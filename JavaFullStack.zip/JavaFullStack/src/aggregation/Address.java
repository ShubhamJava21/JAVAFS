package aggregation;

public class Address 
{
  private String ladr;
  private String padr;
  private String pincode;
public String getLadr() {
	return ladr;
}
public void setLadr(String ladr) {
	this.ladr = ladr;
}
public String getPadr() {
	return padr;
}
public void setPadr(String padr) {
	this.padr = padr;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}
  
}
