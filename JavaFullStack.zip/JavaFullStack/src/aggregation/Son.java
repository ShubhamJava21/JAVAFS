package aggregation;

public class Son 
{
	  int sid;
	  String sname;
	  String srel;
	  long smob;
	  Mother moth;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSrel() {
		return srel;
	}
	public void setSrel(String srel) {
		this.srel = srel;
	}
	public long getSmob() {
		return smob;
	}
	public void setSmob(long smob) {
		this.smob = smob;
	}
	public Mother getMoth() {
		return moth;
	}
	public void setMoth(Mother moth) {
		this.moth = moth;
	}
	  
}
