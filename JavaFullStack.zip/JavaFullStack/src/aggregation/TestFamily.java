package aggregation;

public class TestFamily 
{
 public static void main(String[] args)
 {
	Family f=new Family();
	f.setFid(101);
	f.setFname("Shinde");
	f.setfAdd("Pimpri");
	
	Father f1=new Father();
	f1.setFid(01);
	f1.setFname("Ashok");
	f1.setFrel("Father");
	f1.setFmob(8974848497l);
	f1.setFam(f);
	
	Mother m=new Mother();
	m.setMid(02);
	m.setMname("Rekha");
	m.setMrel("Mother");
	m.setMmob(909378373l);
	m.setFath(f1);
	
	Son s=new Son();
	s.setSid(03);
	s.setSname("Shubham");
	s.setSrel("Son");
	s.setSmob(9887489744l);
	s.setMoth(m);
	
	System.out.println(s.getMoth().getFath().getFam().getFid()+" "+s.getMoth().getFath().getFam().getFname()+" "+s.getMoth().getFath().getFam().getfAdd());
	System.out.println(s.getMoth().getFath().getFid()+" "+s.getMoth().getFath().getFname()+" "+s.getMoth().getFath().getFrel()+" "+s.getMoth().getFath().getFmob());
    System.out.println(s.getMoth().getMid()+" "+s.getMoth().getMname()+" "+s.getMoth().getMrel()+" "+s.getMoth().getMmob());
    System.out.println(s.getSid()+" "+s.getSname()+" "+s.getSrel()+" "+s.getSmob());
 }
}
