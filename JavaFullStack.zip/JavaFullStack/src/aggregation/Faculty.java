package aggregation;

public class Faculty 
{
 int fid;
 String fname;
 Course c;
public int getFid() 
{
	return fid;
}
public void setFid(int fid)
{
	this.fid = fid;
}
public String getFname() 
{
	return fname;
}
public void setFname(String fname) 
{
	this.fname = fname;
}
public Course getC() 
{
	return c;
}
public void setC(Course c) 
{
	this.c = c;
}
}
