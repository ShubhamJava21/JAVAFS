package aggregation;

public class Main 
{
 public static void main(String[] args) 
 {
	Course c=new Course();
	c.setCid(101);
	c.setCname("java");
     
	Faculty f=new Faculty();
	f.setFid(123);
	f.setFname("Nilesh");
	f.setC(c);
	
	Batch b=new Batch();
	b.setBid(55);
	b.setBname("JavaFS");
	b.setF(f);
	
	Student s=new Student();
	s.setSid(345);
	s.setSname("Shubham");
	s.setB(b);
	System.out.println("---All Class ids--");
	System.out.println(s.getB().getF().getC().getCid()+" "+s.getB().getF().getC().getCname()+" "+s.getB().getBname());
	System.out.println(s.getB().getF().getFid()+" "+s.getB().getF().getFname()+" "+s.getB().getBname());
	System.out.println(s.getB().getBid()+" "+s.getB().getBname());
	System.out.println("--All class names--");
	System.out.println(s.getB().getF().getC().getCname());
	System.out.println(s.getB().getF().getFname());
	System.out.println(s.getB().getBname());
	
	
 }
}
