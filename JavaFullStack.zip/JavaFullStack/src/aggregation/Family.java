package aggregation;

public class Family 
{
 private int fid;
 private String fname;
 private String fAdd;
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getfAdd() {
	return fAdd;
}
public void setfAdd(String fAdd) {
	this.fAdd = fAdd;
}
 
}
