package aggregation;

public class Batch 
{
 int bid;
 String bname;
 Faculty f;
public int getBid() 
{
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
public Faculty getF() {
	return f;
}
public void setF(Faculty f) {
	this.f = f;
}
 
}
