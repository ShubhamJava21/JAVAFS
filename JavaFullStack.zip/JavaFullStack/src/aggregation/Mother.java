package aggregation;

public class Mother 
{
	  int mid;
	  String mname;
	  String mrel;
	  long mmob;
	  Father fath;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMrel() {
		return mrel;
	}
	public void setMrel(String mrel) {
		this.mrel = mrel;
	}
	public long getMmob() {
		return mmob;
	}
	public void setMmob(long mmob) {
		this.mmob = mmob;
	}
	public Father getFath() {
		return fath;
	}
	public void setFath(Father fath) {
		this.fath = fath;
	}
	  
}
