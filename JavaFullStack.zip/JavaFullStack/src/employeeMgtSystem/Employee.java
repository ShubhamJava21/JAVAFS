package employeeMgtSystem;

public class Employee 
{
 int id;
 String name;
 int salary;
}
