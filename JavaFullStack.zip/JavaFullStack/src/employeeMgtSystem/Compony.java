package employeeMgtSystem;

public class Compony 
{
	public static void main(String[] args) {
		
  Department dep=new Department();
  Employee em=dep.addEmployeeDetails();
  System.out.println(em.id+" "+em.name+" "+em.salary);
  
    
  AllEmployee em1=dep.addAllEmployeeDetails();
  System.out.println(em1.Swapnil.id+" "+em1.Swapnil.name+em1.Swapnil.salary);
  System.out.println(em1.Saurabh.id+" "+em1.Saurabh.name+em1.Saurabh.salary);
  System.out.println(em1.Suraj.id+" "+em1.Suraj.name+em1.Suraj.salary);
  
}
}