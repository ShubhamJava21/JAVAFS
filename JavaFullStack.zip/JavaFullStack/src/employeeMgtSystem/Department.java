package employeeMgtSystem;

public class Department 
{
 public Employee addEmployeeDetails()
 {
	 Employee e=new Employee();
	 e.id=11;
	 e.name="Shubham";
	 e.salary=200000;
	 return e;
 }
  public AllEmployee addAllEmployeeDetails()
  {
	  AllEmployee all=new AllEmployee();
	  all.Swapnil.id=12;
	  all.Swapnil.name="Swapnil";
	  all.Swapnil.salary=150000;
	  
	  all.Saurabh.id=13;
	  all.Saurabh.name="Saurabh";
	  all.Saurabh.salary=250000;
	  
	  all.Suraj.id=14;
	  all.Suraj.name="Suraj";
	  all.Suraj.salary=150000;
	  return all;

  }
}
