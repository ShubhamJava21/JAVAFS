package employeeMgtSystem;


public class AllEmployee
{
	Employee Swapnil=new Employee();
	Employee Saurabh=new Employee();
	Employee Suraj=new Employee();
  
}
