package defaultConstructor;

public class Student 
{
  public int rollNo=10;
  public String Name="ABC PQR";
  
  public Student()
  {
	  System.out.println("Default Constuctor called");
  }
  public void m1()
  {
	  System.out.println("M1 method from Student called");
  }
}
