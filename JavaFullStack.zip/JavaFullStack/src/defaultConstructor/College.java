package defaultConstructor;

public class College 
{
 public static void main(String[] args)
 {
	System.out.println("Application Started");
	
	Student S=new Student();
	System.out.println(S.rollNo);
	System.out.println(S.Name);
	S.m1();
	
	//Student S1=new Student(); for printing default constructor;
 }
}
