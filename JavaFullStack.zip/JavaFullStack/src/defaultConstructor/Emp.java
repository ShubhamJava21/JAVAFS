package defaultConstructor;

public class Emp 
{
 public int empId;
 public String EmpName;
 
 public Emp()
 {
	 System.out.println("Default Constructor Called");
 }
  public void m1()
  {
	  int empId=101;
	  String EmpName="Shubham";
	  
  }
 
 public static void main(String[] args)
 {
	 Emp e=new Emp();
	 e.m1();
	
 }
}
