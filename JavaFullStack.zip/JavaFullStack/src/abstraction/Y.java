package abstraction;

public abstract class Y implements X
{
	@Override
	public void m1() 
	{
		System.out.println("M1 implemented in Y");
	}

	@Override
	public void m2() 
	{
		System.out.println("M2 implemented in Y");
			
	}

  
}
