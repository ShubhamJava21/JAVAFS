package abstraction;

public interface C  extends B
{
  public void m3();
}
