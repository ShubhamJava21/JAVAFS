package abstraction;

public class TestInter implements C
{
	@Override
	public void m2() 
	{
		System.out.println("M2 method From B Interface");
	}

	@Override
	public void m1() 
	{
		System.out.println("M1 method From A Interface");	
	}

	@Override
	public void m3() 
	{
		System.out.println("M3 method From C Interface");	
	}
	public void m4()
	{
		System.out.println("M4 method from TestClass");
	}
	public static void main(String[] args) 
	{
		 A a=new TestInter();
		 a.m1();
		 B b=new TestInter();
		 b.m1();
		 b.m2();
		 C c=new TestInter();
		 c.m1();
		 c.m2();
		 c.m3();
	}
}
