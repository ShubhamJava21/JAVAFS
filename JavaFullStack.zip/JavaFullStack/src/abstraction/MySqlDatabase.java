package abstraction;

public class MySqlDatabase implements MyDatabase
{
	@Override
	public void commit() 
	{
		System.out.println("Commit:MySqlDatabase");
	}

	@Override
	public void rollback()
	{
		System.out.println("rollback:MySqlDatabase");
	}

}
