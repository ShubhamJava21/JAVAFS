package abstraction;

public class TestSample extends Sample1
{
	@Override
	public void m1() 
	{
		System.out.println("M1 Method From Concrete Class");
	}

	@Override
	void m3() 
	{
		System.out.println("M3 Method From Concrete Class");
	}

	@Override
	void m5() 
	{
		System.out.println("M5 Method From Concrete Class");
	}
	public static void main(String[] args) 
	{
//		Sample1 s1=new Sample1();
//		s1.m1();
//		s1.m3();
//		s1.m5();
		System.out.println(Sample1.x);
		System.out.println(Sample1.m);
		TestSample ts=new TestSample();
		ts.m1();
		ts.m2();
		ts.m3();
		ts.m4();
		ts.m5();
		System.out.println(Sample1.x);
		System.out.println(Sample1.m);
	}

}
