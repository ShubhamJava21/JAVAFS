package abstraction;

public class ReadFile implements fileOperation {

	@Override
	public void file() 
	{
	 System.out.println("Read File FileOperation");	
	}

}
