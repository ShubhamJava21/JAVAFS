package abstraction;

public interface fileOperation 
{
  public abstract void file();
}
