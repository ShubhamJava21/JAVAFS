package abstraction;

public class Z extends Y 
{
	@Override
	public void m3() 
	{
		System.out.println("M3 method implemnted in Z");
	}

	@Override
	public void m4()
	{
		System.out.println("M4 method implemented in Z");
	}
	public static void main(String[] args)
	{
		X x=new Z();
		x.m1();
		x.m2();
		x.m3();
		x.m4();
		
	}

}
