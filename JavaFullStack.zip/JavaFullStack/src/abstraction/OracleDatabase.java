package abstraction;

public class OracleDatabase implements MyDatabase
{
	@Override
	public void commit() 
	{
		System.out.println("Commit:OracleDatabase");
		
	}

	@Override
	public void rollback() 
	{
		System.out.println("rollback:OracleDatabase");
		
	}

}
