package abstraction;

public interface MyDatabase 
{
  public void commit();
  public void rollback();
  
}
