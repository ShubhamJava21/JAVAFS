package abstraction;

public class TestDemo extends Demo2
{
	@Override
	void m6() 
	{
		System.out.println("m6 method ");
	}

	@Override
	void m7() 
	{
	  System.out.println("M7 metgod");	
	}

	@Override
	void m8() 
	{
		 System.out.println("M8 metgod");
	}

	@Override
	public void m1() 
	{
		 System.out.println("M1 metgod");
	}

	@Override
	void m3() 
	{
		 System.out.println("M3 metgod");
	}

	@Override
	void m5()
	{
		 System.out.println("M5 metgod");
	}
 
}
