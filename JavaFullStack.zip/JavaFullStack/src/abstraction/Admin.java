package abstraction;

public class Admin
{
 public static void main(String[] args) 
 {
	 fileOperation fo=new ReadFile();
	 fo.file();
	 fileOperation fo1=new WriteFile();
	 fo1.file();
	 fileOperation fo2=new DeleteFile();
	 fo2.file();
}
}
