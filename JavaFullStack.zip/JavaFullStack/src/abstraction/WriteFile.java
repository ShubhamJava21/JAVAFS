package abstraction;

public class WriteFile implements fileOperation
{

	@Override
	public void file() 
	{
		System.out.println("Write File FileOperation");
	}

}
