package abstraction;

public interface B extends A
{
  public void m2();
}
