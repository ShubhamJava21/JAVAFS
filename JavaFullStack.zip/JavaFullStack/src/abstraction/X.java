package abstraction;

public interface X 
{
	public abstract void m1();
	public abstract void m2();
	public abstract void m3();
	public abstract void m4();
 
}
