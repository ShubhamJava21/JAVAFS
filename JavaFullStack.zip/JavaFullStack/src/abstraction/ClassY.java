package abstraction;

public class ClassY implements InterFaceI
{

	@Override
	public void m1() 
	{
		System.out.println("M1 Implemented in classX");	
	}

	@Override
	public void m2() 
	{
		System.out.println("M2 Implemented in classY");
	
	}

}
