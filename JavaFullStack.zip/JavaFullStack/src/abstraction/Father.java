package abstraction;

public class Father implements Family{

	@Override
	public void Name() 
	{
		System.out.println("Name: AShok");
	}

	@Override
	public void Relation() 
	{
	  System.out.println("Rel: Father");	
	}

	@Override
	public void Mobile()
	{
		System.out.println("Mobile: 9849764874");
	}

}
