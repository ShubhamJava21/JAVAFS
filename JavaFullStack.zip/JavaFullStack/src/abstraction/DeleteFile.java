package abstraction;

public class DeleteFile implements fileOperation {

	@Override
	public void file() 
	{
		System.out.println("Delete File FileOperation");
	}

}
