package abstraction;

public abstract class Demo
{
  public void m1() 
  {
	System.out.println("Complete Method m1/Non-Abstract Method");
  }
  public void m2() 
  {
	System.out.println("Complete Method m2/Non-Abstract Method");
  }
  public abstract void m3();
  public abstract void m4();
  public abstract void m5();
 

}
