package abstraction;

public class Test extends Demo
{
	@Override
	public void m3() 
	{
		System.out.println("M3 Method Completed");
	}

	@Override
	public void m4()
	{
		System.out.println("M4 Method Completed");
	}

	@Override
	public void m5() 
	{
		System.out.println("M5 Method Completed");
	}
  public static void main(String[] args)
  {
	Test t=new Test();
	t.m1();
	t.m2();
	t.m3();
	t.m4();
	t.m5();
  }
}
