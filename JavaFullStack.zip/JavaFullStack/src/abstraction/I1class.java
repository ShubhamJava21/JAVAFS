package abstraction;

public class I1class implements I1
{
  static int x=200;
  
  public static void main(String[] args)
  {
	System.out.println(I1.x);
	System.out.println(I1class.x);
	System.out.println(x);
	
	I1 i1=new I1class();
	System.out.println(i1.x);
  }
}
