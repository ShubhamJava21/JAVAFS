package abstraction;

public interface I1 
{
  int x=100;
}
