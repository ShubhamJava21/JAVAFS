package abstraction;

public class TestFam 
{
 public static void main(String[] args) 
 {
	Family f=new Father();
	f.Name();
	f.Relation();
	f.Mobile();
	
	Family f1=new Mother();
	f1.Name();
	f1.Relation();
	f1.Mobile();
 }
}
