package abstraction;

public interface A 
{
  public void m1();
}
