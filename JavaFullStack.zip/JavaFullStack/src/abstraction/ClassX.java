package abstraction;

public class ClassX implements InterFaceI
{

	@Override
	public void m1()
	{
		System.out.println("M1 Implemented in class");
	}

	@Override
	public void m2() 
	{
		System.out.println("M2 Implemented in class");
	
		
	}

}
