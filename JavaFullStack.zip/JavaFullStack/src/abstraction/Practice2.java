package abstraction;

public interface Practice2 extends Practice 
{
  @Override
default int m1(int i)
  {
	return i;
  }
  @Override
	default String m2(String s) 
  {
		return s;
	}
  @Override
	default float m3(float f)
    {
		return f;
	}
}
