package abstraction;

public abstract class Demo1 
{
	static int x=90;
	static String m="Shubham";
 public abstract void m1();
 public static void m2() 
 {
	System.out.println("M2 method From Sample1"); 
 }
 abstract void m3();
 public static void m4() 
 {
	System.out.println("M4 method from Sample1"); 
 }
 abstract void m5();
}
