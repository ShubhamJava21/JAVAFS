package abstraction;

public class Mother implements Family 
{
	@Override
	public void Name() 
	{
		System.out.println("Name: Rekha");
	}

	@Override
	public void Relation() 
	{
	  System.out.println("Rel: Mother");	
	}

	@Override
	public void Mobile() 
	{
		System.out.println("Mob:9588958589");
	}

}
