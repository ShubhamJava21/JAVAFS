package abstraction;

public interface Practice 
{
  public int m1(int i);
  public String m2(String s);
  public float m3(float f);
}
