package abstraction;

public class MangoDB implements MyDatabase
{
	@Override
	public void commit() 
	{
		System.out.println("Commit:MangoDBDatabase");
	}

	@Override
	public void rollback() 
	{
		System.out.println("rollback:MangoDBDatabase");	
	}
    public static void main(String[] args) 
    {
		MyDatabase dta=new MySqlDatabase();
		dta.commit();
		dta.rollback();
		MyDatabase dta1=new OracleDatabase();
		dta1.commit();
		dta1.rollback();
		MyDatabase dta2=new MangoDB();
		dta2.commit();
		dta2.rollback();	
	}
}
