package abstraction;

public class TestPractice implements Practice2
{
 public static void main(String[] args) 
 {
	
	 TestPractice tp=new TestPractice();
//	  tp.m1(12*12);
//	  tp.m2("Welcome");
//	  tp.m3(123.4f);
	  System.out.println(tp.m1(12*12));
	  System.out.println(tp.m2("Welcome"));
	  System.out.println(123.45f);
 }
}
