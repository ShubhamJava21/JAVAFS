package abstraction;

public abstract  class Demo2 extends Demo1
{
	 int v=10;
	 int s=90;
	abstract void m6();
	abstract void m7();
	abstract void m8();
	
}
