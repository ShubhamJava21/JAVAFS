package abstraction;

public interface InterFaceI 
{ 
  int x=100;   //by default public static final
  public static final int y=200;
  
  public abstract void m1();
  
  void m2();  //By default public abstract
}
