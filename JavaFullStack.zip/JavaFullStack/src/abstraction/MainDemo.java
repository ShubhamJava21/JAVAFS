package abstraction;

public class MainDemo extends TestDemo
{
  public static void main(String[] args) 
  {
	MainDemo md=new MainDemo();
	md.m1();
	md.m2();
	md.m3();
	md.m4();
	System.out.println(md.x);
	md.m5();
	md.m6();
	md.m7();
	md.m8();
	System.out.println(md.s);
	System.out.println(md.v);
  }
}
