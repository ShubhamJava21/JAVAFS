package abstraction;

public interface Family 
{
 public abstract void Name();
 public abstract void Relation();
 public abstract void Mobile();
}
