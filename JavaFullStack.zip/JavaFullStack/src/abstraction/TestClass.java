package abstraction;

public class TestClass 
{
	public static void main(String[] args) 
	{
		 InterFaceI i=new ClassX();
	     i.m1();
	     i.m2();
	     System.out.println(InterFaceI.x);
	     System.out.println(InterFaceI.y);
	     
	     InterFaceI i1=new ClassY();
	     i1.m1();
	     i1.m2();
	     System.out.println(InterFaceI.x);
	     System.out.println(InterFaceI.y);
		
		}
  
  
}
