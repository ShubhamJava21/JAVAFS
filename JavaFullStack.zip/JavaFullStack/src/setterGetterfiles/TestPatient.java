package setterGetterfiles;

public class TestPatient 
{
 public static void main(String[] args) 
 {
	Patient p=new Patient();
	p.setId(89);
	p.setName("XYZ");
	p.setAddress("POR");
	p.setAdvice("IUOU");
	p.setBG('A');
	p.setDate("YUIOYU");
	p.setMobile(3546353635l);
	System.out.println(p.getId()+" "+p.getName()+" "+p.getMobile()+" "+p.getAddress()+" "+p.getAdvice()+" "+p.getBG()+" "+p.getDate());
 }
}
