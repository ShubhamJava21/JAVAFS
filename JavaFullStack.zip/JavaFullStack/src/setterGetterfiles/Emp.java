package setterGetterfiles;

public class Emp 
{
	private int id;
	private String name;
	private String Address;
	private int Salary;
	private long mobile;
	private String Designation;
	
	public void setId(int StdId)
	{
		id=StdId;
	}
	public int getId()
	{
		return id;
	}
	public void setName(String StdName) 
	{
		name=StdName;
	}
	public String getName()
	{
		return name;
	}
	public void setAddress(String StdAdd)
	{
		Address=StdAdd;
	}
	public String getAddress() 
	{
		return Address;
	}
	public void setSalary(int StdSal)
	{
		Salary=StdSal;
	}
	public int getSalary()
	{
		return Salary;
	}
	public void setMobile(int StdMobile)
	{
		mobile=StdMobile;
	}
	public long getmobile()
	{
		return mobile;
	}
	public void setDesignation(String StdDesig)
	{
		Designation=StdDesig;
	}
	public String getDesignation()
	{
		return Designation;
	}
	

	

}
