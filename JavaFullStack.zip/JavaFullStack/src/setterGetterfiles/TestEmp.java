package setterGetterfiles;

public class TestEmp 
{
 public static void main(String[] args)
 {
	Emp e=new Emp();
	e.setId(101);
	e.setName("Shubham");
	e.setAddress("Pimpri");
	e.setSalary(5000000);
	e.setMobile(986576473);
	e.setDesignation("Software Developer");
	
	System.out.println(e.getId()+" "+e.getName()+" "+e.getAddress()+" "+e.getmobile()+" "+e.getSalary()+" "+e.getDesignation());
 
	Emp e1=new Emp();
	e1.setId(1012);
	e1.setName("Saurabh");
	e1.setAddress("Psaud");
	e1.setSalary(5000000);
	e1.setMobile(974587657);
	e1.setDesignation("Software Developer");
	
	System.out.println(e1.getId()+" "+e1.getName()+" "+e1.getAddress()+" "+e1.getmobile()+" "+e1.getSalary()+" "+e1.getDesignation());
 
 }
}
