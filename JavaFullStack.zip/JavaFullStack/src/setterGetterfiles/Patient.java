package setterGetterfiles;

public class Patient 
{
	  private int id;
	  private String name;
	  private String Address;
	  private long mobile;
	  private String Advice;
	  private char BG;
	  private String Date;
	public int getId() 
	{
		return id;
	}
	public void setId(int Patid) 
	{
		id = Patid;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String Patname) 
	{
		name = Patname;
	}
	public String getAddress() 
	{
		return Address;
	}
	public void setAddress(String Pataddress) 
	{
		Address = Pataddress;
	}
	public long getMobile() 
	{
		return mobile;
	}
	public void setMobile(long Patmobile) 
	{
		mobile = Patmobile;
	}
	public String getAdvice()
	{
		return Advice;
	}
	public void setAdvice(String Patadvice) 
	{
		Advice = Patadvice;
	}
	public char getBG() 
	{
		return BG;
	}
	public void setBG(char PatBG)
	{
		BG = PatBG;
	}
	public String getDate() 
	{
		return Date;
	}
	public void setDate(String PatDate) 
	{
		Date = PatDate;
	}
}
