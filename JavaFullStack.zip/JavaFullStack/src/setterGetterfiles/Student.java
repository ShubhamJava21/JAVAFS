package setterGetterfiles;

public class Student
{
  private int RollNo;
  private String name;
  private String Address;
  private long mobile;
  private float per;
  
  public void setRollN0(int StdRollNo) 
  {
	RollNo=StdRollNo;  
  }
  public int getRollNo()
  {
	 return RollNo; 
  }
  public void setName(String Stdname)
  {
	  name=Stdname;
  }
  public String getName()
  {
	  return name;
  }
  public void setAddress(String StdAddress)
  {
	  Address=StdAddress;
  }
  public String getAddress()
  {
	  return Address;
  }
  public void setMobile(long StdMobile)
  {
	  mobile=StdMobile;
  }
  public long getMobile()
  {
	  return mobile;
  }
  public void setPer(float StudPer)
  {
	  per=StudPer;
  }
  public float getPer()
  {
	  return per;
  }
  
}
