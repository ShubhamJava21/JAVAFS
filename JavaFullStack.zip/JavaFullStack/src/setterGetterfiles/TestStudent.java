package setterGetterfiles;

public class TestStudent 
{
  public static void main(String[] args) 
  {
	Student s=new Student();
	s.setRollN0(101);
	System.out.println("Student RollNo: "+s.getRollNo());
	s.setName("Shubham");
	System.out.println("Student Name: "+s.getName());
	s.setAddress("Pimpri");
	System.out.println("Student Address: "+s.getAddress());
	s.setMobile(23847484l);
	System.out.println("Student Mobile: "+s.getMobile());
	s.setPer(98.99f);
	System.out.println("Student Percentage: "+s.getPer());
  }	
 
}
