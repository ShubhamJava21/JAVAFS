package multilevelInheritance;

public class Son extends Father
{
  int sid=30;
  
  public void m3()
  {
	  System.out.println("M3 Method fron Son");
  }
  
  public static void main(String[] args) 
  {
	 Son s=new Son();
	 s.m1();
	 s.m2();
	 s.m3();
	 System.out.println(s.sid);
	 System.out.println(s.fid);
	 System.out.println(s.gid);
	 
	 System.out.println("Father Called");
	 Father f=new Father();
	 f.m1();
	 f.m2();
	 System.out.println(f.fid);
	 System.out.println(f.gid);      //Son can't be called
	 
	 System.out.println("Grandfather Called");
	 GrandFather gf=new GrandFather();
	 gf.m1();
	 System.out.println(gf.gid);
  }
}
