package multilevelInheritance;

public class Developer extends Manager
{
  int id1;
  String name1;
  int Salary1;
  
public int getId1() 
{
	return id1;
}
public void setId1(int Devid1) 
{
	id1 = Devid1;
}
public String getName1() 
{
	return name1;
}
public void setName1(String Devname1) 
{
	name1 = Devname1;
}
public int getSalary1() 
{
	return Salary1;
}
public void setSalary1(int Devsalary1) 
{
	Salary1 = Devsalary1;
}
  
}
