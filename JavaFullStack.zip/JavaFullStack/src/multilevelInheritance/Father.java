package multilevelInheritance;

public class Father extends GrandFather 
{
  int fid=67;
  
  public void m2()
  {
	  System.out.println("M2 method from Father");
  }
  
}
