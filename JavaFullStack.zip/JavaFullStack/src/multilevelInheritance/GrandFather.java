package multilevelInheritance;

public class GrandFather
{
 int gid=88;
 
 public void m1()
 {
	 System.out.println("M1 method from GrandFather");
 }
}
