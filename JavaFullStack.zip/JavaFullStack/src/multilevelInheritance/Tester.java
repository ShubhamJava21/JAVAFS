package multilevelInheritance;

public class Tester extends Developer 
{
  int id2;
  String Name2;
  int salary2;
  
public int getId2() 
{
	return id2;
}
public void setId2(int Testid2)
{
	id2 = Testid2;
}
public String getName2()
{
	return Name2;
}
public void setName2(String Testname2)
{
	Name2 = Testname2;
}
public int getSalary2() 
{
	return salary2;
}
public void setSalary2(int Testsalary2) 
{
	salary2 = Testsalary2;
}
  
}
