package multilevelInheritance;

public class Manager 
{
  int id;
  String name;
  int Salary;
public int getId() 
{
	return id;
}
public void setId(int Mangid) 
{
	id = Mangid;
}
public String getName() 
{
	return name;
}
public void setName(String Mangname) 
{
	name = Mangname;
}
public int getSalary() 
{
	return Salary;
}
public void setSalary(int Mangsalary) 
{
	Salary =Mangsalary;
}
}
