package multilevelInheritance;

public class TestTester 
{
 public static void main(String[] args) 
 {
	Tester t=new Tester();
	t.id=101;
	t.id1=201;
	t.id2=301;
	t.name="Nilesh";
	t.name1="Shubham";
	t.Name2="Abhay";
	t.Salary=500000;
	t.Salary1=400000;
	t.salary2=250000;
	
	System.out.println("Manager Details: "+t.getId()+" "+t.name+" "+t.Salary);
	System.out.println("Developer Details: "+t.getId1()+" "+t.getName1()+" "+t.getSalary1());
	System.out.println("Tester Details: "+t.getId2()+" "+t.getName2()+" "+t.getSalary2());
 }
}
