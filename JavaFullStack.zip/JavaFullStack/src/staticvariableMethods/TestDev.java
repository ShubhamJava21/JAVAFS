package staticvariableMethods;

public class TestDev 
{
	static String DBG="O";
 public static void main(String[] args) 
 {
	 Developer d1=new Developer();
	 d1.Did=123;
	 d1.Dname="Sawapnil";
	 Developer.m1();
	 System.out.println(d1.Did+" "+d1.Dname+" "+Developer.DCompony+" "+Developer.DProject);
	 d1.m2();
	 System.out.println(DBG);
	 System.out.println(TestDev.DBG);
	 
	 Developer.m1();
//	 Developer.m2(); //Nonstatic method
 }
}
