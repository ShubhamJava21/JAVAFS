package staticvariableMethods;

public class Emp 
{
  int eid;
  String eName;
  String eAdd;
  static String collAdd="Tathawade";
  private static void m1() 
  {
   System.out.println(Emp.collAdd);
  }
  public static void main(String[] args) 
  {
	Emp e=new Emp(); 
	e.eid=111;
	e.eName="Shubham";
	e.eAdd="Pimpri";
	Emp.m1();
	System.out.println(e.eid+" "+e.eName+" "+e.eAdd+" "+Emp.collAdd); //Static variable
	
	Emp e1=new Emp(); 
	e1.eid=112;
	e1.eName="Saurabh";
	e1.eAdd="Psaud";
	Emp.m1();
	System.out.println(e1.eid+" "+e1.eName+" "+e1.eAdd+" "+Emp.collAdd); //Static variable
	
  
  }
  
}
