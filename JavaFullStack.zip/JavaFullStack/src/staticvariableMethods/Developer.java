package staticvariableMethods;

public class Developer 
{
  int Did;
  String Dname;
  static String DProject="Investment Banking";
  static String DCompony="Infosys";
  
  public static void m1() 
  {
	System.out.println(Developer.DProject+" "+Developer.DCompony);
  }
  public void m2()
  {
	  System.out.println("--Non-Static Method--");
  }
  public static void main(String[] args) 
  {
	Developer d=new Developer();
	d.Did=101;
	d.Dname="Shubham";
	Developer.m1();
	System.out.println(d.Did+" "+d.Dname);
	
	d.Did=102;
	d.Dname="Saurabh";
	System.out.println(d.Did+" "+d.Dname);
	
	d.m2();      //non static call by Object
//	Developer.m2(); //NonStatic method
	
  }
}
