package staticvariableMethods;

public class Student 
{
  int sid;
  String sname;
  static String CollegeName="J.S.P.M"; //static for reuse variable
  
  public static void m1() 
  {
//	System.out.println(sid+" "+sname+" "+CollegeName);
  }
  public static void main(String[] args) 
  {
	Student s=new Student();
	s.sid=101;
	s.sname="Shubham";
	System.out.println(Student.CollegeName);
	System.out.println(s.sid+" "+s.sname+" "+Student.CollegeName);
	
	Student s1=new Student();
	s1.sid=102;
	s1.sname="Saurabh";
	System.out.println(s1.sid+" "+s1.sname+" "+Student.CollegeName); //we can directly use
  }
}
