package stringfunctions;

public class Practice 
{
 public static void main(String[] args)
 {
	String s1="@1234abcd@@    ";
	System.out.println(s1.trim());
 
    String s2="My name is lakhan";
    System.out.println(s2.substring(2));
    System.out.println(s2.substring(5));
    System.out.println(s2.substring(2, 10));
 
    String s3="MY FAMILY IS MY FAMILY IS MY FAMILY IS";
    String[] array1=s3.split("IS");
    for(String s:array1) 
    {
    	System.out.println(s);
    }
    String[] array2=s3.split("MY");
    for(String s10:array2) 
    {
    	System.out.println(s10);
    }
    
    System.out.println(s3.startsWith("MY"));
    System.out.println(s3.endsWith("IS"));
 }   
}
