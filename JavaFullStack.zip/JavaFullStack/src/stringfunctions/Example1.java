	package stringfunctions;
	
	public class Example1 
	{
	 public static void main(String[] args) 
	 {
		String s="WELCOME TO THE STRING SESSION";
		System.out.println(s);
		String s1=new String("WELCOME TO THE STRING SESSION");
		System.out.println(s1);
		System.out.println(s1.length());
		String Lower=s1.toLowerCase();
		System.out.println(Lower);
		String oldClgName="J.S.P.M";
		System.out.println(oldClgName.toLowerCase());
		String newClgName="OXFORD";
		System.out.println(newClgName.toLowerCase());
		if(oldClgName.equals(newClgName))
		{
			System.out.println("BOTH STRINGS ARE SAME");
		}
		else
		{
			System.out.println("BOTH STRINGS ARE DIFFERENT");
		}
		char ch=oldClgName.charAt(2);
		System.out.println(ch);
		
		char[] arraychar=oldClgName.toCharArray();
		for(char c: arraychar)
		{
			System.out.println(c);
		}
		
		char[] array1char=newClgName.toCharArray();
		for(char c1: array1char)
		{
			System.out.println(c1);
		}
		int[] A= {1,2,3,4,5,6,7,8,9};
		System.out.println(A.length);
	  }
	}
