package stringfunctions;

public class TrimSubStringEx
{
 public static void main(String[] args) 
 {
	String uName=" abc123 ";
	uName=uName.trim();
	System.out.println(uName);
 
	String s5="Hii to Welcome to String split to methods";
	String s6=s5.substring(5);
	System.out.println(s6);
	
	String s10="Hii to Welcome to String split to methods";
	String s7=s10.substring(10);   //substring will delete the spaces you given
	System.out.println(s7);
	System.out.println(s10.substring(3,10));
	System.out.println(s10.substring(1,10));
	
	//split
	System.out.println("------Split function----");
	String[] array1=s10.split("to");
	for(String string:array1)
	{
		System.out.println(string);
	}
	System.out.println(array1.length);
	System.out.println(s10.length());
	
	//split2
	System.out.println("_-----Split example------_");
	String s22="My name is My father name is My mother name is";
	String[] array2=s22.split("My");
	for(String s:array2)
	{
		System.out.println(s);
	}
	String[] array3=s22.split("is");
	for(String s1:array3)
	{
		System.out.println(s1);
	}
	
	//start with//end with 
	System.out.println(s22.startsWith("Hii"));
	System.out.println(s22.endsWith("Hiiiii"));
	System.out.println(s22.endsWith("is"));
	
 } 
 
}
