package polymorphismMethodOverriding;

public class Parent 
{
 public void m1() 
 {
	System.out.println("Parent m1 method");
 }
 public void m2(Parent i) 
 {
	System.out.println("Parent m2 method");
 }
 public int m3() 
 {
	System.out.println("Parent m3 method");
	return 10;
 }
 public Parent m4() 
 {
	System.out.println("Parent m4 method");
	return new Parent();
 }
 final void m5() 
 {
	System.out.println("Parent m5 method");
 }
 private void m6() 
 {
	System.out.println("Parent Private method");
 }
 public static void m7()
 { 
	 System.out.println("Parent Static method");
 }
}
