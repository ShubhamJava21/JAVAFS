package polymorphismMethodOverriding;

public class Mother extends Family
{
 @Override
public void Name() 
 {
	System.out.println("Name: Rekha");
 }
 @Override
	public void Relation()
    {
		System.out.println("Relation : Mother");
	}
  @Override
	public void Age()
    {
		System.out.println("Age: 49");
	}
  @Override
	public void Mobile() 
    {
		System.out.println("Mobile:8958598696");
	}
}
