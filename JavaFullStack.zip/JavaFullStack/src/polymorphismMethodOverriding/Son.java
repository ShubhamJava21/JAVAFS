package polymorphismMethodOverriding;

public class Son extends Family
{
	@Override
	public void Name()
	{
		System.out.println("Name: Shubham");
	}
	@Override
	public void Relation() 
	{
		System.out.println("Relation: Son");
	}
	@Override
	public void Age()
	{
		System.out.println("Age: 30");
	}
	@Override
	public void Mobile()
	{
		System.out.println("Mobile: 9957857589");
	}
  
}
