package polymorphismMethodOverriding;

public class Father extends Family
{
 @Override
public void Name() 
 {
	System.out.println("Name: Ashok");
 }
 @Override
	public void Relation() 
    {
		System.out.println("Relation :Father");
	}
 @Override
	public void Age() 
   {
		System.out.println("Age: 50");
	}
 @Override
	public void Mobile() 
   {
		System.out.println("Mobile: 98759758759");
	}
}
