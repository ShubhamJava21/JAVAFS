package polymorphismMethodOverriding;

public class Test 
{
  public static void main(String[] args) 
  {
	System.out.println("---FATHERS Details----");
	Family f=new Father();
	f.Name();
	f.Relation();
	f.Age();
	f.Mobile();
	System.out.println("---MOTHERS Details----");
	Family f1=new Mother();
	f1.Name();
	f1.Relation();
	f1.Age();
	f1.Mobile();
	System.out.println("---SON'S Details----");
	Family f2=new Son();
	f2.Name();
	f2.Relation();
	f2.Age();
	f2.Mobile();
  }
}
