package polymorphismMethodOverriding;

public class Sample1 
{
 public void m1(int i ,int j) 
 {
	System.out.println(i+j);
 }
 public void m2(int i ,int j,int k) 
 {
	System.out.println(i+j+k);
 }
 public void m3(int i ,int j,int k,int l) 
 {
	System.out.println(i*j*k*l);
 }
}
