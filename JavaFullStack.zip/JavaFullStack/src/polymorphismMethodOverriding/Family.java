package polymorphismMethodOverriding;

public class Family 
{
 public void Name() 
 {
	System.out.println("Family Name:");
 }
 public void Relation() 
 {
	System.out.println("Relation:");
 }
 public void Age() 
 {
	System.out.println("Person Age:");
 }
 public void Mobile() 
 {
	System.out.println("Mobile:");
 }
}
