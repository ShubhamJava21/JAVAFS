package polymorphismMethodOverriding;

public class Child extends Parent
{
  @Override
public void m1() 
  {
	System.out.println("Overrided m1 method of child class");
  }
  @Override
	public void m2(Parent i)
  {
		System.out.println("----Overrided m2 Method----");
	}
  @Override
	public int m3() 
  {
		System.out.println("Overrided m3 method");
		return 20;
	}
  @Override
	public Parent m4()
  {
		Child c=new Child();
		return c;
	}
//  public void m5() 
//  {
//	super.m5();  //final method in parent
//  }
//   private void m6() 
//   {
//	// TODO Auto-generated method stub //Private method in Parent
//
//  }
  public static void m7()
  {
	System.out.println("Child Static Method");
 }
  public static void main(String[] args) 
  {
	Parent p=new Child();
	p.m1();
	p.m2(p);
	p.m3();
	p.m4();
	p.m5();
	Parent.m7();
	
  }
}
