package polymorphismMethodOverriding;

public class Sample2 extends Sample1
{
 @Override
public void m1(int i, int j) 
 {
	super.m1(i, j);
 }
 @Override
	public void m2(int i, int j, int k)
  {
		super.m2(i, j, k);
	}
 @Override
	public void m3(int i, int j, int k, int l) 
   {
		super.m3(i, j, k, l);
	}
   public static void main(String[] args) 
   {
	 Sample1 s1=new Sample1();
	 s1.m1(123, 143);
	 s1.m2(109, 209, 309);
	 s1.m3(234, 3435, 5645, 54735);
	 System.out.println("---------");
	 Sample2 s2=new Sample2();
	 s2.m1(123, 143);
	 s2.m2(1234, 2324, 938);
	 s2.m3(1234, 3450, 8790, 1000);
	 System.out.println("-----------");
	 Sample1 s3=new Sample2();
	 s3.m1(123, 143);
	 s3.m2(109, 209, 309);
	 s3.m3(234, 3435, 5645, 54735);
   }
}
