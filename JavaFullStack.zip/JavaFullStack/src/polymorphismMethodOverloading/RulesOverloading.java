package polymorphismMethodOverloading;

public class RulesOverloading 
{
	public void m1(int i) 
	{
		System.out.println("M1 Method with Single Parameter and simple method");
	}
	public static void m1(int i,int j) 
	{
		System.out.println("M1 Method with two param & Static Method");
	}
	public static int m1(int a,int b,int c) 
	{
		System.out.println("M1 Method with three param & Return type Method");
		return 10;
	}
	protected final void m1(String s) 
	{
		System.out.println("M1 Method with Single Parameter and Protected & Final");
	}
	private void m1(char c) 
	{
		System.out.println("Private method Single parameter");
	}
	public static void main(String[] args) 
	{
	 RulesOverloading r=new RulesOverloading();
	 r.m1(10);
	 r.m1("ZXC");
	 r.m1('A');
	 RulesOverloading.m1(10, 10, 10);
	 main(90);
	}
	public static void main(int args) 
	{
	  System.out.println("We can add 2 Main method by overloading but Param diff");	
	}

}
