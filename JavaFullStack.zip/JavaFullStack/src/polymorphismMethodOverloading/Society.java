package polymorphismMethodOverloading;

public class Society 
{
  public void name(String s)
  {
	System.out.println("Society Name:GokulDham Society");
  }
  public void name(String s,int i)
  {
	System.out.println("Society Name:GokulDham Society,Society No:101");
  }
  public int name(int r)
  {
	System.out.println("Society Name:GokulDham Society,Society No:101");
	return 10;
  }
  protected int name(int r,int x)
  {
	System.out.println("Society Name:GokulDham Society,Society No:101");
	return 1000;
  }
  protected static int name(int r,int x,int s)
  {
	System.out.println("Society Name:GokulDham Society,Society No:101");
	return 1777;
  }
  public static void main(String[] args) 
  {
	Society s=new Society();
	s.name(101);
	s.name("Gokuldham Society");
	s.name("GK", 00);
	Society.name(110, 210, 230);
  }
  
}
