package polymorphismMethodOverloading;

public class MethodOverloading 
{
   public void m1() 
   {
	 System.out.println("M1 method without Parameter");
   }
   public void m1(int i) 
   {
	 System.out.println("M1 method with one Parameter");
   }
   public void m1(int i,int j) 
   {
	 System.out.println("M1 method with Two Parameter");
   }
   public void m1(String s,int j) 
   {
	 System.out.println("M1 method with String Parameter");
   }
   public static void main(String[] args) 
   {
	MethodOverloading m=new MethodOverloading();
	m.m1();
	m.m1(101);
	m.m1(101, 102);
	m.m1("XYZ", 10);
   }
}
