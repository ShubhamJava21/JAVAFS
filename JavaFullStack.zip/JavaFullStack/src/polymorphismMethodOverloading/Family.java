package polymorphismMethodOverloading;

public class Family
{
  public void sirname(String s) 
  {
	System.out.println("Gada Family");
  }
  public void sirname(String s,int i) 
  {
	System.out.println("Gada Family");
  }
  public static String sirname(String a,String b) 
  {
	System.out.println("Gada Family");
	return a;
  }
  public final void sirname(int i,int j) 
  {
	System.out.println("Gada Family");
  }
  public static void main(String[] args) 
  {
	Family f=new Family();
	f.sirname("Gada");
	f.sirname(101, 201);
	f.sirname("Gada", 1000);
	Family.sirname("Gada", "Mehta");
	Family.sirname("Gada", "Mehta");
	main("Shinde");
  }
  public static void main(String s) 
  {
	System.out.println("Shinde Family");
  }
  
  
}
