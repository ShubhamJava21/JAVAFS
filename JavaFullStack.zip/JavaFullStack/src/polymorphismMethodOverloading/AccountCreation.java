package polymorphismMethodOverloading;

public class AccountCreation 
{
  public void createAccount(int i) 
  {
	System.out.println("Saving Account");
   }
  public void createAccount(int i,int j) 
  {
	System.out.println("Current Account");
   }
  public void createAccount(int i,int j,int k) 
  {
	System.out.println("Joint Account");
   }
  public static void main(String[] args) 
  {
	  AccountCreation ac=new AccountCreation();
	  ac.createAccount(101);
	  ac.createAccount(10, 10);
	  ac.createAccount(10,10, 10);
  }
}
