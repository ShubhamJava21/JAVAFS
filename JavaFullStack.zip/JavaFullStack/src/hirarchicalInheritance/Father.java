package hirarchicalInheritance;

public class Father extends Grandfather 
{
 int fid=68;
 
 public void m2()
 {
	 System.out.println("---Father method--");
 }
}
