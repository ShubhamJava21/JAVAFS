package hirarchicalInheritance;

public class Grandfather 
{
  int gid=80;
  
  public void m1()
  {
	  System.out.println("---Grandfather Method----");
  }
}
