package hirarchicalInheritance;

public class Son extends Grandfather
{
 int sid=30;
 public void m3()
 {
	 System.out.println("---Son CValled---");
 }
 public static void main(String[] args) 
 {	
   Son s=new Son();
   s.m1();
   s.m3();
   System.out.println(s.gid);
   System.out.println(s.sid);
   
   System.out.println("Father Called");
   
   Father f=new Father();
   f.m1();
   f.m2();
   System.out.println(f.fid);
   System.out.println(f.gid);
   
   System.out.println("Grandfather called");
   Grandfather gf=new Grandfather();
   gf.m1();
   System.out.println(gf.gid);
		   
}
}