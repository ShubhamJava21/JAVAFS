package methods;

public class Ecommerce
{
	  public void DisplayProducts()
	{
	  System.out.println("Mobile-Iphone");
	  System.out.println("Laptop-Hp");
	  System.out.println("Gloceries"); 

	  }
	public void Addtocart()
	{
	  Ecommerce em=new Ecommerce();
	   em.DisplayProducts();
	  }
	public void UserInformation()
	{
	  Ecommerce em=new Ecommerce();
	   em.DisplayProducts();
	   em.Addtocart();
	   System.out.println("Shubham");
	   System.out.println("Pimpri");
	  }

	 public static void main(String[] args)
	{
	 System.out.println("Welcome to Ecommerce ");
	 Ecommerce em=new Ecommerce();
	 em.DisplayProducts();
	 em.Addtocart();
	em.UserInformation();
	}
}
