package methods;

public class Employee
{
	  public void DisplayComponyDetails()
	{
	  System.out.println("101 Infosys Pune");
	  }
	public void DisplayEmployeeDetails()
	{
	  System.out.println("Shubham Infosys Pune 9518999923");
	  }

	 public static void main(String[] args)
	{
	 System.out.println("Welcome to Emplyoee Details ");
	    Employee em=new Employee();
	     em.DisplayComponyDetails();
	     em.DisplayEmployeeDetails();
	}

}
