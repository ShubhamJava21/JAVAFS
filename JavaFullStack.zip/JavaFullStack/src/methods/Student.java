package methods;

public class Student
{
	  public void StudentName()
	{
	  System.out.println("Shubham");
	  }
	public void StudentResult()
	{
	  System.out.println("Passed with First Class With Distinction");
	  }
	public void StudentContact()
	{
	  System.out.println("9518999923");
	  }


}
