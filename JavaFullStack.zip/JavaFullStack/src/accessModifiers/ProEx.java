package accessModifiers;

public class ProEx 
{
	 protected int id;
	 protected String Name;
	 protected String Address;
	 protected long Mobile;
	 protected char BG;
	 
	 protected ProEx(int Empid,String EmpName,String EmpAddress,long EmpMobile,char EmpBG)
	 {
		 id=Empid;
		 Name=EmpName;
		 Address=EmpAddress;
		 Mobile=EmpMobile;
		 BG=EmpBG;
	 }
	public static void main(String[] args)
	{
		ProEx em=new ProEx(101,"Shubham","Pimpri",8794647l,'O');
		System.out.println("Emp info:" +em.id+" "+em.Name+" "+em.Address+" "+em.Mobile+" "+em.BG);
		ProEx em1=new ProEx(102,"Saurabh","Psaud",9894647l,'O');
		System.out.println("Emp info:"+em1.id+" "+em1.Name+" "+em1.Address+" "+em1.Mobile+" "+em1.BG);	
	}
}
