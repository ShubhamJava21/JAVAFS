package accessModifiers;

public class DefaultAM 
{
	int did=900;
	
	DefaultAM()
	{
		
	}
	
	void m1()
	{
		System.out.println("----Default Method---");
	}
	
	public static void main(String[] args) 
	{
		DefaultAM d=new DefaultAM();
		System.out.println(d.did);
		
		d.m1();
	}

}
