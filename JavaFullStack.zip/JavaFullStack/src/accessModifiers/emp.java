package accessModifiers; 

public class emp 
{
	 int id;
	 String Name;
	 String Address;
	 long Mobile;
	 char BG;
	 
	 emp(int Empid,String EmpName,String EmpAddress,long EmpMobile,char EmpBG)
	 {
		 id=Empid;
		 Name=EmpName;
		 Address=EmpAddress;
		 Mobile=EmpMobile;
		 BG=EmpBG;
	 }
	 void m1()
	{
	    System.out.println("Private Access Modi.....");
	}
	void m2()
	{
		System.out.println("Default Access Modifier");
	}
	public static void main(String[] args)
	{
		emp em=new emp(101,"Shubham","Pimpri",8794647l,'O');
		System.out.println("Emp info:" +em.id+" "+em.Name+" "+em.Address+" "+em.Mobile+" "+em.BG);
		emp em1=new emp(102,"Saurabh","Psaud",9894647l,'O');
		System.out.println("Emp info:"+em1.id+" "+em1.Name+" "+em1.Address+" "+em1.Mobile+" "+em1.BG);
		em.m1();
		em.m2();	
	}
 
}
