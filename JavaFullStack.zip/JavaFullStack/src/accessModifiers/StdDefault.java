package accessModifiers;

public class StdDefault 
{
	 int RollNo;
	 String Name;
	 String Address;
	 long Mobile;
	 char Grade;
	
	 void m1()
	{
	    System.out.println("Private Access Modi.....");
	}
	void m2()
	{
		System.out.println("Default Access Modifier");
	}
	public static void main(String[] args)
	{
		StdDefault sd=new StdDefault();
		sd.m1();
		sd.m2();
		sd.RollNo=121;
		sd.Name="Shubham";
		sd.Address="Pimpri";
		sd.Mobile=9387363763l;
		sd.Grade='A';
		System.out.println("Student Information: "+sd.RollNo+" "+sd.Name+" "+sd.Address+" "+sd.Mobile+" "+sd.Grade);
	}
}
