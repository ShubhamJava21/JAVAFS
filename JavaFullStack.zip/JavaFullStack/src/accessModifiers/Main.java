package accessModifiers;

public class Main 
{
 public static void main(String[] args) 
 {
//	PrivateAM pt=new PrivateAM();
//	System.out.println(pt.pid);
//	pt.m1();
	 
	 DefaultAM dt=new DefaultAM();
	 System.out.println(dt.did);
	 dt.m1();
 }
}
