package accessModifiers;

public class PrivateAM 
{
 private int pid=200;     //within the class
 
 private PrivateAM()
 {
	 
 }
 public void m1()
 {
	 System.out.println("m1 method called");
	 System.out.println("----400linesofcode---");
	 m2();
 }
 private void m2()
 {
	 System.out.println("----200linesofcodes--");
 }
 public static void main(String[] args) 
 {
	PrivateAM p=new PrivateAM();
	System.out.println(p.pid);
	p.m1();
	p.m2();
	
 }
 
}
