package accessModifiers;

public class Student
{
	public int RollNo;
	public String Name;
	public String Address;
	public long Mobile;
	public char Grade;
	
	private void m1()
	{
	    System.out.println("Private Access Modi.....");
	}
	void m2()
	{
		System.out.println("Default Access Modifier");
	}
	public static void main(String[] args)
	{
		Student s=new Student();
		s.m1();
		s.m2();
		s.RollNo=121;
		s.Name="Shubham";
		s.Address="Pimpri";
		s.Mobile=9387363763l;
		s.Grade='A';
		System.out.println("Student Information: "+s.RollNo+" "+s.Name+" "+s.Address+" "+s.Mobile+" "+s.Grade);
	}

}
