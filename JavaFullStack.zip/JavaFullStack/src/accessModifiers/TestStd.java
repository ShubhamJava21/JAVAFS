package accessModifiers;

public class TestStd 
{
 public static void main(String[] args) 
 {
	Student s1=new Student();
	s1.m2();
//	s1.m1();      //Private Method 
	s1.RollNo=21;
	s1.Name="Shubham";
	s1.Address="Pune";
	s1.Mobile=9928727l;
	s1.Grade='A';
	System.out.println(s1.RollNo+" "+s1.Name+" "+s1.Address+" "+s1.Mobile+" "+s1.Grade);
 
//	Student1 st1=new Student1(); //Student1 is private
	
	StdDefault std=new StdDefault();
	std.m1();
	std.m2();
	System.out.println("Student Default information: "+std.RollNo+" "+std.Name+" "+std.Address+" "+std.Mobile+" "+std.Grade);
	std.RollNo=1;
	std.Name="Saurabh";
	std.Address="Pune";
	std.Mobile=38546735l;
	std.Grade='A';
	System.out.println("Student information: "+std.RollNo+" "+std.Name+" "+std.Address+" "+std.Mobile+" "+std.Grade);
	
 }
}
