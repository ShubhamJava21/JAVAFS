package accessModifiers;

public class ProtectEx 
{
	  protected int c;
	  protected ProtectEx()
	  {
		 c=90; 
	  }
	  protected void n1()
	  {
		  System.out.println(c);
	  }
	  public static void main(String[] args)
	  {
		ProtectEx pe=new ProtectEx();
		 pe.n1();
		System.out.println(pe.c);
				
	  }
}
