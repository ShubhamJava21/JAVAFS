package accessModifiers;

public class Student1 
{
	private int RollNo;
	private String Name;
	private String Address;
	private long Mobile;
	private char Grade;
	
	private Student1(int StdRollNo, String StdName, String StdAddress,long StdMobile,char StdGrade)
	{
	 RollNo=StdRollNo;
	 Name=StdName;
	 Address=StdAddress;
	 Mobile=StdMobile;
	 Grade=StdGrade;  
	}
	public static void main(String[] args) 
	{
		Student1 s=new Student1(11,"Shubham","Pimpri",3536546735l,'A');
		System.out.println(s.RollNo+" "+s.Name+" "+s.Address+" "+s.Mobile+" "+s.Grade);
	}
}
