package EmpMgtSysMethodOverriding;

public class Emp 
{
  int id;
  String name;
  int Salary;
  
 
  public int getId() 
  {
	return id;
  }


public void setId(int Empid) 
{
	id = Empid;
}


public String getName() 
{
	return name;
}


public void setName(String Empname) 
{
	name = Empname;
}


public int getSalary() 
{
	return Salary;
}


public void setSalary(int Empsalary) 
{
	Salary = Empsalary;
}


public void displayEmpDetails() 
  {
	 System.out.println("----Emp Details---"); 
  }
}
