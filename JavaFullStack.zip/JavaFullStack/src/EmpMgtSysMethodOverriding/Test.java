package EmpMgtSysMethodOverriding;

public class Test 
{
  public static void main(String[] args) 
  {
	  Developer d=new Developer();
		d.id=21;
		d.name="Shubham";
		d.Salary=98373;
		d.ProggLang="Java";
		d.TeamSize=16;
		
		Tester t=new Tester();
		t.id=31;
		t.name="Saurabh";
		t.noofbugs=98;
		t.Salary=87036;
		t.TeamSize=16;
		
		Manager m=new Manager();
		m.id=41;
		m.name="Nilesh";
		m.Salary=90897;
		m.TeamSize=16;
		
		Emp e=new Emp();
		e.id=51;
		e.name="AAkash";
		e.Salary=878367;
		e.displayEmpDetails();
		
		e.displayEmpDetails();
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
	    m.displayEmpDetails();
		System.out.println(m.getId()+" "+m.getName()+" "+m.getSalary()+" "+m.getTeamSize());
        t.displayEmpDetails();
		System.out.println(t.getId()+" "+t.getName()+" "+t.getNoofbugs()+" "+t.getSalary()+" "+t.getTeamSize());
        d.displayEmpDetails();
		System.out.println(d.getId()+" "+d.getName()+" "+d.getProggLang()+" "+d.getSalary()+" "+d.getTeamSize());
  }
}