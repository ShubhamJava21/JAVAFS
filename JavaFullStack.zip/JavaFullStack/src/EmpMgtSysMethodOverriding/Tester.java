package EmpMgtSysMethodOverriding;

public class Tester extends Manager
{
  int noofbugs;

public int getNoofbugs() 
{
	return noofbugs;
}

public void setNoofbugs(int noofbugs) 
{
	this.noofbugs = noofbugs;
}
  @Override
	public void displayEmpDetails()
  {
	   System.out.println("---Tester Details---");
		System.out.println(noofbugs);
		
	}
	
}

