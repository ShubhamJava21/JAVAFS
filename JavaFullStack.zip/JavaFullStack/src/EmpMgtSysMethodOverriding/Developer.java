package EmpMgtSysMethodOverriding;

public class Developer extends Manager 
{
  String ProggLang;

public String getProggLang() 
{
	return ProggLang;
}

public void setProggLang(String proggLang) 
{
	ProggLang = proggLang;
}
 @Override
	public void displayEmpDetails()
   {
	    System.out.println("---Developer Details---");
		System.out.println(ProggLang);
	}
  
}
