package EmpMgtSysMethodOverriding;

public class Manager extends Emp
{
  int TeamSize;

public int getTeamSize() 
{
	return TeamSize;
}

public void setTeamSize(int teamSize) 
{
	TeamSize = teamSize;
}
  @Override
	public void displayEmpDetails()
   {
	  System.out.println("--Display Manager Details----");
		System.out.println(TeamSize);
	}
}
