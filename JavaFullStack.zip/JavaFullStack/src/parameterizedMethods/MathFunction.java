package parameterizedMethods;

public class MathFunction 
{
    public void Add(Addition ad)
    {
    	System.out.println(ad.a+ad.b);
    }
    public void Sub(Substraction sb)
    {
    	System.out.println(sb.c-sb.d);
    }  
    public static void main(String[] args) 
    {
		 MathFunction mf=new MathFunction();
		 Addition a1=new Addition();
		 a1.a=100;
		 a1.b=20;
		 System.out.println("Addition is: ");
		 mf.Add(a1);
		 
		 Substraction S=new Substraction();
		 S.c=500;
		 S.d=30;
		 System.out.println("Substraction is: ");
		 mf.Sub(S);

	}

}
