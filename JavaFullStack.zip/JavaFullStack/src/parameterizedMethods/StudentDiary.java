package parameterizedMethods;

public class StudentDiary 
{
	  public void AddStudentDetails(Student s1)
	  {
		  System.out.println(s1.StdId+" "+s1.StdName+" "+s1.StdAdd+" "+s1.StdMarks+" "+s1.StdMobile);
	  }
	  public void AddStudent1Details(Student1 S1)
	  {
		  System.out.println(S1.Std1Id+" "+S1.Std1Name+" "+S1.Std1Add+" "+S1.Std1Marks+" "+S1.Std1Mobile);
	  }
	  
  public static void main(String[] args) 
	  {
	StudentDiary sd=new StudentDiary();
	Student s=new Student();
	s.StdId=1;
	s.StdName="Aakash";
	s.StdAdd="Pimpri";
	s.StdMarks=87.64f;
	s.StdMobile=267253753l;
	sd.AddStudentDetails(s);
	
	Student1 s1=new Student1();
	s1.Std1Id=2;
	s1.Std1Name="Satyajeet";
	s1.Std1Add="Pune";
	s1.Std1Marks=97.64f;
	s1.Std1Mobile=5365365753l;
	sd.AddStudent1Details(s1);
	
	
	
  }
}
