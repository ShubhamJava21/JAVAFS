package parameterizedMethods;

public class Student1 
{
	 int Std1Id;
	 String Std1Name;
	 String Std1Add;
	 float Std1Marks;
	 long Std1Mobile;
}
