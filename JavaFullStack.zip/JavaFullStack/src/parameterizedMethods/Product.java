package parameterizedMethods;

public class Product 
{
	int pid;
	String pname;
	double price;
}
