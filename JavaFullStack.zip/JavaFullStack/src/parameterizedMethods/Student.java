package parameterizedMethods;

public class Student 
{
 int StdId;
 String StdName;
 String StdAdd;
 float StdMarks;
 long StdMobile;
}
