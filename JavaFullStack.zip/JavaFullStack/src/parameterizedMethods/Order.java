package parameterizedMethods;

public class Order 
{
  int oid;
  String oname;
}
