package parameterizedMethods;

public class Addition 
{
 int a;
 int b;
}
