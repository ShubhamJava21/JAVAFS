package parameterizedMethods;

public class AdminClass
{
  public void m1()
  {
	  System.out.println("Without Parametr Method");
  }
  public void m2(int i)
  {
	  System.out.println("Single Parametr Method");
	  System.out.println(i);
  }
  public void m3(char c, long l)
  {
	  System.out.println("two Parametr Method");
	  System.out.println(c +" " +l);
  }
  public void m4(int i,float f,boolean b)
  {
	  System.out.println("three Parametr Method");
	  System.out.println(i +" " +f+ " "+b);
  }
  public void m5(char a,char b,char c,char d)
  {
	  System.out.println("four Parametr Method");
  }
  public void m6(byte s,double d)
  {
	  System.out.println("double Parametr Method with byte and double");
	  System.out.println(s);
  }
  public void displayProductDetails(Product p)
  {
	 System.out.println("NonPrimitive Datatype Class"); 
	 System.out.println(p.pid+" "+p.pname+" "+p.price);
  }
  public void displayOrderandProductDetails(Order order,Product product,Product product1)
  {
	System.out.println(order.oid+" "+order.oname);
	System.out.println(product.pid+" "+product.pname+" "+product.price);
	System.out.println(product1.pid+" "+product1.pname+" "+product1.price);
  }
  
  public static void main(String[] args) 
  {
	AdminClass ac=new AdminClass();
	ac.m1();
	ac.m2(1000);
	ac.m3('a', 1374874l);
	ac.m4(10, 123.34f, false);
	ac.m5('a', 'b', 'c', 'd');
	byte b=10;
	ac.m6(b, 10.674);
	
	Product product=new Product();
	product.pid=21;
	product.pname="Bike";
	product.price=87836.90;
	ac.displayProductDetails(product);
	
	Product product1=new Product();
	product1.pid=22;
	product1.pname="Mobile";
	product1.price=87883893.87;
	ac.displayProductDetails(product1);
	
	Order o=new Order();
	o.oid=67;
	o.oname="Abc";
	ac.displayOrderandProductDetails(o, product,product1);
	
  }
  
}
