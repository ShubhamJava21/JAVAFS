package parameterizedMethods;

public class Substraction 
{
 int c;
 int d;
}
