package com.Exponent.ServiceIMPL;

import java.util.Scanner;

import com.Exponent.Entity.User;
import com.Exponent.Service.UserService;
import com.Exponent.UserMange.Vaidation.Validations;

public class UserServiceIMPL implements UserService
{
	User[] u=new User[5];

	@Override
	public void AddUser() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER HOW MANY USERS YOU WANT TO ADD:- ");
		int n=sc.nextInt();
		for(int i=0;i< n;i++)
		{
			User user=new User();
//			System.out.println("ENTER USER ID:- ");
			user.setUid(getValidUID());
//			System.out.println("ENTER USER NAME:- ");
			user.setUname(Validations.validateUserName());
			System.out.println("ENTER USER Address:- ");
			user.setUaddress(sc.next());
//			System.out.println("ENTER USER SALARY:- ");
			user.setUSalray(getValidSalary());
//			System.out.println("ENTER USER GENDER:- ");
			user.setUgender(Validations.validateGender());
//			System.out.println("ENTER USER PH-NO:- ");
			user.setUPhone(Validations.validatePhNo());
			
			u[i]=user;
			System.out.println("-----USER ADDED SUCCESSFULLY------");
		}
	}

	@Override
	public void displayAllUser() 
	{
		System.out.println("----ALL USER DETAILS----");
		for(User user: u)
		{
			if(user!=null)
			{
			System.out.println(user);
			}
		}
	}

	@Override
	public void displaySingleUser() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER USER ID:- ");
		int id=sc.nextInt();
		for(User user: u)
		{
			if(user!= null && user.getUid() == id)
			{
				System.out.println(user);
			}
		}
	}

	@Override
	public void updateUserDetails() 
	{
		User user=new User();
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR USER ID:- ");
		int uid=sc.nextInt();
		boolean flag=true;
		while(flag)
		{
			System.out.println("1: ENTER NEW NAME");
			System.out.println("2: ENTER NEW MOBILE");
			System.out.println("3: ENTER NEW MAIL-ID");
			System.out.println("ENTER CHOICE BETWEEN 1 TO 3 ");
			System.out.println("UPDATE ACCOUNT DETAILS");
			int i1=sc.nextInt();
		switch(i1)
		{
		case 1:
			   System.out.println("ENTER YOUR NEW NAME");
			   String newName=sc.next();
			   user.setUname(newName);
			   System.out.println("YOUR UPDATED NAME= "+" "+newName);
			  break;
		case 2:
			 System.out.println("ENTER YOUR NEW MOBILE NO");
			 String newMoNo=sc.next();
			user.setUPhone(newMoNo);
			 System.out.println("YOUR UPDATED MOBILE NO= "+" "+newMoNo);
			  break;
		case 3:
			System.out.println("ENTER YOUR NEW Address:-");
			String newAdd=sc.next();
			user.setUaddress(newAdd);
			System.out.println("YOUR UPDATED ADDRESS= "+" "+newAdd);
			  break;
		case 4:
			flag=false;
			break;
		default:
			System.out.println("You entered invalid choice please correct choice");
			break;
		}
		}
	}

	@Override
	public void deleteUserDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER THE USER ID:- ");
		int id=sc.nextInt();
		
		int index=0;
		for(int i=0;i<u.length;i++)
		{
			if(u[i]!=null && u[i].getUid()==id)
			{
				index=i;
				break;
			}
		}
		u[index]=null;
		System.out.println("---USER DELETED SUCESSFULLY--");
	}
	public static int getValidUID()
	   {
	   	  Scanner sc=new Scanner(System.in);
	   	  System.out.println("ENTER YOUR USER ID:- ");
	   	  
	   	  int uid;
	   	  try {
	   		  uid=sc.nextInt();
	   	} catch (Exception e)
	   	  {
	   		System.out.println("EXCEPTION HANDLED HERE : PLEASE PROVIDE CORRECT USER ID.");
	   		return getValidUID();
	   	}
	   	  return uid;
	   }
	public static int getValidSalary()
	   {
	   	  Scanner sc=new Scanner(System.in);
	   	  System.out.println("ENTER YOUR SALARY:- ");
	   	  
	   	  int usal;
	   	  try {
	   		  usal=sc.nextInt();
	   	} catch (Exception e)
	   	  {
	   		System.out.println("EXCEPTION HANDLED HERE : PLEASE PROVIDE CORRECT SALARY.");
	   		return getValidSalary();
	   	}
	   	  return usal;
	   }

}
