package com.Exponent.Service;

public interface UserService 
{
	public void AddUser();
	public void displayAllUser();
	public void displaySingleUser();
	public void updateUserDetails();
	public void deleteUserDetails();
	

}
