package com.Exponent.Controller;

import java.util.Scanner;

import com.Exponent.Service.UserService;
import com.Exponent.ServiceIMPL.UserServiceIMPL;


public class UserController
{
	public static void main(String[] args)
	 {
		System.out.println("********WELCOME TO U.M.S********");
		Scanner sc=new Scanner(System.in);
		boolean flag=true;
		UserService user=new UserServiceIMPL();
		while(flag)
		{
			System.out.println("------------------------");
			System.out.println("------------------------");
			System.out.println("1: ADD USER                   |");
			System.out.println("2: DISPLAY ALL DETAILS        |");
			System.out.println("3: DISPLAY SINGLE USER        |");
			System.out.println("4: UPDATE USER DETAILS        |");
			System.out.println("5: DELETE USER DETAILS        |");
			System.out.println("------------------------");
			System.out.println("------------------------");
			
			System.out.println("Please Enter your choice between 1 to 5");
			int ch=sc.nextInt();
			getValidChoice();
			switch(ch)
			{
			case 1:
				user.AddUser();
				break;
			case 2:
				user.displayAllUser();
				break;
			case 3:
				user.displaySingleUser();
				break;
			case 4:
				user.updateUserDetails();
				break;
			case 5:
				user.deleteUserDetails();
				break;
			case 8:
				flag=false;
				break;
			default:
				System.out.println("You entered invalid choice please correct choice");
				break;
				
			}
			
			
		}
	}
	 public static int getValidChoice()
	 {
	 	  Scanner sc=new Scanner(System.in);
	 	  System.out.println("ENTER THE CHOICE:- ");
	 	  
	 	  int ch;
	 	  try {
	 		  ch=sc.nextInt();
	 	} catch (Exception e)
	 	  {
//	 		e.printStackTrace();
	 		System.out.println("EXCEPTION HANDLED HERE:-CHOICE MUST BE AN INTIGER");
	 		return getValidChoice();
	 	}
	 	  return ch;
	 }
}
