package com.Exponent.Entity;

public class User 
{
 private int Uid;
 private String Uname;
 private String Uaddress;
 private int USalray;
 private String Ugender;
 private String UPhone;
@Override
public String toString() {
	return "User [Uid=" + Uid + ", Uname=" + Uname + ", Uaddress=" + Uaddress + ", USalray=" + USalray + ", Ugender="
			+ Ugender + ", UPhone=" + UPhone + "]";
}
public int getUid() {
	return Uid;
}
public void setUid(int uid) {
	Uid = uid;
}
public String getUname() {
	return Uname;
}
public void setUname(String uname) {
	Uname = uname;
}
public String getUaddress() {
	return Uaddress;
}
public void setUaddress(String uaddress) {
	Uaddress = uaddress;
}
public int getUSalray() {
	return USalray;
}
public void setUSalray(int uSalray) {
	USalray = uSalray;
}
public String getUgender() {
	return Ugender;
}
public void setUgender(String ugender) {
	Ugender = ugender;
}
public String getUPhone() {
	return UPhone;
}
public void setUPhone(String uPhone) {
	UPhone = uPhone;
}
 
 
}
