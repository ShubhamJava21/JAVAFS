package com.Exponent.UserMange.Vaidation;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Validations 
{
	public static String validateUserName()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR USER NAME :- ");
		String UName = sc.next();
		boolean flag=true;
		if(Pattern.matches("[A-Za-z]", UName)) 
			{
				flag=false;
			}
		if(!flag)
		{
			System.out.println("Invalid Input");
			return validateUserName();
		}
		return UName;
		
	}
	public static String validateGender()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR GENDER :- ");
		String UGend = sc.next();
		boolean flag=true;
		if(Pattern.matches("^(male|female)$", UGend)) 
			{
				flag=false;
			}
		if(!flag)
		{
			System.out.println("Invalid Input");
			return validateGender();
		}
		return UGend;
		
	}
	public static String validatePhNo()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER YOUR PHONE NO :- ");
		String ph = sc.next();
		boolean flag=true;
		if(Pattern.matches("[0-9]{10}", ph)) 
			{
				flag=false;
			}
		if(!flag)
		{
			System.out.println("Invalid Input");
			return validatePhNo();
		}
		return ph;
		
	}
}
